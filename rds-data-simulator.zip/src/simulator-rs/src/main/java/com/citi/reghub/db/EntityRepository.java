package com.citi.reghub.db;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.citi.reghub.domain.Entity;
@Repository
public interface EntityRepository extends MongoRepository<Entity, String>{
	List<Entity> findBySourceId(String sourceId);
//	List<Entity> findByStream(String stream);
//	List<Entity> findByStreamFlow(String stream, String flow);
}
