package com.citi.reghub.util;

import java.util.List;
import java.util.concurrent.BlockingQueue;

import com.citi.reghub.client.EntityClient;
import com.citi.reghub.domain.Entity;

public class EntityConsumer implements Runnable{

private BlockingQueue<List<Entity>> queue;
    
    public EntityConsumer(BlockingQueue<List<Entity>> q){
        this.queue=q;
    }

    @Override
    public void run() {
        try{
        	List<Entity> entities =  queue.take();
            //consuming messages until exit message is received
            while(!entities.isEmpty()){
	            EntityClient.saveEntity(entities);
	            System.out.println("Consumed " + entities.size() + " enties saved to MongoDB. Waiting for next ... ");
	            entities =  queue.take();
            }
            
            System.out.println("All records were saved to MongoDB.");
        }catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
}