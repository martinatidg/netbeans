package com.citi.reghub.constant;

public enum EntityFields {
	ID("id"), STATUS("status"), REASON("reasonCodes"), STREAM("stream"), FLOW("flow"),
        SOURCE_UID("sourceUId"), SOURCE_ID("sourceId"), SOURCE_STATUS("sourceStatus"), REPORTING_REF("regReportingRef"),
        RECEIVED_TS("receivedTs"), PUBLISHED_TS("publishedTs"), EXECUTION_TS("executionTs"), LAST_UPDATED("lastUpdatedTs"),
        INSTRUCTIONS("instructions");
	
	private String field;
	
	private EntityFields(String field) {
		this.field = field;
	}
	
	public String fieldName() {
		return field;
	}
}
