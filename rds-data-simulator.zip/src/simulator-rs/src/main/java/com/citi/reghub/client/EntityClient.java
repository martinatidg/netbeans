package com.citi.reghub.client;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.citi.reghub.domain.Entity;
import com.citi.reghub.util.Ocean;

public class EntityClient {

	public static List<Entity> saveEntity(List<Entity> entities) {
		RestTemplate rest = new RestTemplate();
		List<Entity> retEntities = new ArrayList<>();

		for (Entity entity : entities) {
			Entity ent = rest.postForObject("http://localhost:8080/entity/save", entity, Entity.class);
			retEntities.add(ent);
		}
		
		return retEntities;
	}

	public static Entity saveEntity(Entity entity) {
		RestTemplate rest = new RestTemplate();
		return rest.postForObject("http://localhost:8080/entity/save", entity, Entity.class);
	}

	public static List<Entity> getEntity(String id) {
		RestTemplate rest = new RestTemplate();
		return rest.getForObject("http://localhost:8080/entitye/{id}", List.class, id);
	}

	public static List<Entity> getEntityEntity(String id) {
		RestTemplate rest = new RestTemplate();
		ResponseEntity<List> res = rest.getForEntity("http://localhost:8080/entity/lastName/{id}", List.class, id);
		HttpHeaders httpdeaders = res.getHeaders();
		List<MediaType> mtype = httpdeaders.getAccept();
		System.out.println("accepted type:");
		for (MediaType m : mtype) {
			System.out.print(m.toString() + ", ");
		}
		System.out.println();

		return res.getBody();
	}

	public static List<Entity> getEntityBySourceId(String sourceId) {
		RestTemplate rest = new RestTemplate();
		ResponseEntity<List> res = rest.getForEntity("http://localhost:8080/entity/xm/{sourceId}", List.class, sourceId);
		HttpHeaders httpdeaders = res.getHeaders();
		List<MediaType> mtype = httpdeaders.getAccept();
		System.out.println("accepted type:");
		for (MediaType m : mtype) {
			System.out.print(m.toString() + ", ");
		}
		System.out.println();

		return res.getBody();
	}

	public void updateEntity(Entity entity) { // throws EntityException {
		RestTemplate rest = new RestTemplate();
		String url = "http://localhost:8080/entity/" + entity.getRegHubId();
		rest.put(URI.create(url), entity);
	}
}
