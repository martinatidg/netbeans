package com.citi.reghub.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.convert.CustomConversions;

import com.citi.reghub.converter.LocalDateTimeToStringConverter;
import com.citi.reghub.converter.StringToLocalDateTimeConverter;
//import com.citi.reghub.db.dao.ProfileRepository;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;

@Configuration
//@EnableMongoRepositories(basePackages="com.citi.reghub.db")
class ApplicationConfig extends AbstractMongoConfiguration {
	@Override
	protected String getDatabaseName() {
		return "simulator";
	}

	@Override
	@Bean //("mongoClient")
	public Mongo mongo() throws Exception {
		return new MongoClient("localhost");
	}

	@Override
	public CustomConversions customConversions() {
		List<Converter> converters = new ArrayList<>();
		converters.add(new LocalDateTimeToStringConverter());
		converters.add(new StringToLocalDateTimeConverter());
		return new CustomConversions(converters);
	}
	
	
}