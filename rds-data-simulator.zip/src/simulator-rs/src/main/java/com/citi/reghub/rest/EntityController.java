package com.citi.reghub.rest;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.citi.reghub.db.EntityRepository;
import com.citi.reghub.domain.Entity;

@RestController
@RequestMapping("/entity")
public class EntityController {
	String myUserName = "yuan";
	String myPassword = "ribi";

	@Autowired
	EntityRepository entityRepository;

	@RequestMapping(value = "/save", method = RequestMethod.POST) //, consumes = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public Entity saveEntity(@RequestBody Entity em) {
		System.out.println("saveEntity: em = " + em);

		return entityRepository.insert(em);
	}

	@RequestMapping(value = "/put", method = RequestMethod.POST) //, consumes = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public Entity updateEntity(@PathVariable String firstName, Entity em) {
//		Entity Entity = new Entity("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803",
//				"90 South Street, Tampa, FL");

		return entityRepository.save(em);
	}

	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<?> getEntity(@RequestParam(value = "firstName") String firstName) {

		List<Entity> emp = entityRepository.findAll();

		if (emp == null || emp.size() < 1) {
			Error error = new Error(4, "Entity [" + firstName + "] not found");
			return new ResponseEntity<Error>(error, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Entity>>(emp, HttpStatus.OK);
	}

	@RequestMapping(value = "/xm/{sourceId}", method = RequestMethod.GET)
	public ResponseEntity<?> getEntityBySourceId(@PathVariable String sourceId) {
		System.out.println("%%%%%%%%%%%%%%%%%%%%getEntityBySourceId(), sourceId = " + sourceId);
		//List<Entity> emp = entityRepository.findAll();
		List<Entity> emp = entityRepository.findBySourceId(sourceId);
		System.out.println("%%%%%%%%%%%%%%%%%%%%getEntityBySourceId(), emp = " + emp.size());

		return new ResponseEntity<List<Entity>>(emp, HttpStatus.OK);
	}

	//
//	@RequestMapping(value = "/{stream}", method = RequestMethod.GET)
//	public ResponseEntity<List<Entity>> getEntityByPath(@PathVariable("stream") String stream) {
//
//		List<Entity> emp = entityRepository.findByStream(stream);
//
//		if (emp == null || emp.size() < 1) {
//			throw new EntityNotFoundException(stream);
//		}
//
//		return new ResponseEntity<List<Entity>>(emp, HttpStatus.OK);
//	}
//
//	@RequestMapping(value = "/{stream}/{flow}", method = RequestMethod.GET) //, produces = "application/xml")
//	public List<Entity> getEntityByLastName(@PathVariable("stream") String stream, @PathVariable("flow") String flow) {
//
//		List<Entity> emp = entityRepository.findByStreamFlow(stream, flow);
//
//		if (emp == null || emp.size() < 1) {
//			throw new EntityNotFoundException("Stream: " + stream + ", Flow: " + flow);
//		}
//
//		return emp;
//	}

//	@ExceptionHandler(EntityNotFoundException.class)
//	public ResponseEntity<Error> EntityNotFound(EntityNotFoundException e) {
//		String key = e.getSearchKey();
//		Error error = new Error(4, "Entity [" + key + "] not found");
//		return new ResponseEntity<Error>(error, HttpStatus.NOT_FOUND);
//	}

	@ExceptionHandler(EntityNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public Error EntityNotFound(EntityNotFoundException e) {
		String key = e.getSearchKey();
		Error error = new Error(4, "Entity [" + key + "] not found");
		return error;
	}
}
