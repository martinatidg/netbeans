package com.citi.reghub.client;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.domain.Entity;

public class EntityClientTest {
	@Test
	public void testGet() {
		List<Entity> ent = EntityClient.getEntityBySourceId("sourceId");
		Assert.assertNotNull("returned is null.", ent);
	}
}
