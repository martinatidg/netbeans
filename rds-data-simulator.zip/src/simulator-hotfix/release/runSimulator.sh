#!/bin/sh
java -jar rds-data-simulator-0.1.0.jar --spring.config.location=settings.properties