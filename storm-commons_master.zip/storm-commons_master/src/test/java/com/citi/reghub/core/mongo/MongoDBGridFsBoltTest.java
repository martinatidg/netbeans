package com.citi.reghub.core.mongo;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.utils.MockTupleHelpers;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Ignore;
import org.junit.Test;

import com.citi.reghub.core.ConvertToMongoMap;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.MongoUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.constants.GlobalProperties;

@Ignore
public class MongoDBGridFsBoltTest {

	@ClassRule
	public static MongoUnitRule mongoUnitRule = new MongoUnitRule();
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	private MongoDBGridFsBolt<Entity> mongoDBGridFsBolt;
	private ConvertToMongoMap toMongoMap;
	
	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}
	
	@Before
	public void setUp(){
		toMongoMap = mock(ConvertToMongoMap.class);
	}
	
	@Test
	public void shouldAckInputTupleSave() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBGridFsBolt = new MongoDBGridFsBolt<>("test", toMongoMap);
		mongoDBGridFsBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(
				new Document().append("_id", new ObjectId())
				.append("fileName", "test")
				.append("extension", "csv")
				.append("content", new byte[10])
			);
		mongoDBGridFsBolt.execute(tuple);
		verify(_collector, times(1)).ack(tuple);
	}
	
	@Test
	public void shouldFailInputTuple() {
		Tuple tuple = null;
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBGridFsBolt = new MongoDBGridFsBolt<>("test", toMongoMap);
		mongoDBGridFsBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(new Document().append("_id", new ObjectId()));
		mongoDBGridFsBolt.execute(tuple);
		verify(_collector, times(1)).fail(tuple);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionWhenConnectionUrlIsMissing() {
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, new HashMap<>());
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBGridFsBolt = new MongoDBGridFsBolt<>("test", toMongoMap);
		mongoDBGridFsBolt.prepare(stormConf, context, _collector);
	}	
		
}
