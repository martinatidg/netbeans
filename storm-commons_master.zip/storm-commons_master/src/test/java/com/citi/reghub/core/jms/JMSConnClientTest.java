/**
 * 
 */
package com.citi.reghub.core.jms;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.constants.GlobalProperties;

/**
 * @author sc54933
 *
 */
@RunWith(JUnit4.class)
public class JMSConnClientTest {

	private static final String PROVIDER_URL = "tibems036-d1.eur.nsroot.net:7036";
	public Map<String,String> config=new HashMap<String,String>();
	JMSConnectionClient jmsClient;

	@Before
	public void setUp(){
		config.put(GlobalProperties.APA_TOPIC_NAME, "EU.REGHUB_TO_GMAX.LSE.TCR");
		config.put(GlobalProperties.APA_USERNAME, "cb2app");
		config.put(GlobalProperties.APA_PWD_KEY, "cb2app");
		config.put(GlobalProperties.APA_JNDI_NAME	, "FTTopicConnectionFactory");
		config.put(GlobalProperties.APA_PROVIDER_URL, PROVIDER_URL);
	}
	
	/**
	 * Test method for {@link com.citi.reghub.core.jms.JMSConnectionClient#JMSConnectionClient(java.util.Map)}.
	 */
	@Test
	public void testJMSConnectionClient() {
		setUp();
		jmsClient=new JMSConnectionClient(config);
		String providerUrl=jmsClient.getConfig().get(GlobalProperties.APA_PROVIDER_URL);
		assertTrue(providerUrl.equals(PROVIDER_URL));
	}

	/**
	 * Test method for {@link com.citi.reghub.core.jms.JMSConnectionClient#initConnection()}.
	 * @throws Exception 
	 */
	@Ignore
	@Test(expected=Test.None.class)
	public void testInitConnection() throws Exception {
		setUp();
		jmsClient=new JMSConnectionClient(config);
		jmsClient.initConnection();
	}

	/**
	 * Test method for {@link com.citi.reghub.core.jms.JMSConnectionClient#sendMessage(java.lang.String)}.
	 * @throws Exception 
	 */
	@Test(expected=Exception.class)
	public void testSendMessage() throws Exception {
		jmsClient=new JMSConnectionClient(config);
		jmsClient.initConnection();
		StringBuilder sb = new StringBuilder();
		jmsClient.sendMessage(sb.toString());
	}

}
