package com.citi.reghub.core.blackbox;

import org.apache.storm.tuple.Tuple;

import com.citi.reghub.core.EnrichmentBolt;

/**
 * This wrapper class registers the extended EnrichmentBolt with the SingletonBoltTestController to 
 * facilitate changing of the enrichment plan as part of LOCAL testing.
 *  
 * @author sk73543
 *
 */
public class EnrichmentBoltTest extends EnrichmentBolt implements EnrichmentChangeInterface {

	private static final long serialVersionUID = 1L;
	
	private static int ID_COUNTER = 0;
	
	private final int    			id;
	private String type;
	
	public EnrichmentBoltTest(String enrichmentPlanName) {
		super(enrichmentPlanName);
		synchronized(EligibilityBoltTest.class) {
			id = ID_COUNTER++;
		}
		SingletonBoltTestController.registerBolt(this);
	}

	public EnrichmentBoltTest(String t, String enrichmentPlanName) {
		super(enrichmentPlanName);
		this.type = t;
		synchronized(EligibilityBoltTest.class) {
			id = ID_COUNTER++;
		}
		SingletonBoltTestController.registerBolt(this);
	}

	public int getID() {
		return this.id;
	}
		
	public String getEnrichmentPlanType() {
		return this.type;
	}
	
	public boolean isEnrichmentPlanType(String eptype) {
		return this.type.equals(eptype);
	}

	public void process(Tuple input) {
		String epn = SingletonBoltTestController.getCurrentEnrichmentPlan(this);
		if (!super.enrichmentPlanName.equals(epn)) {
			System.out.println("Changing Enrichment Bolt Plan Name from ["+super.enrichmentPlanName+"] to ["+epn+"]");
			super.enrichmentPlanName = epn;
			super.enrichmentPlanCurrentLoadTime = 0;
			super.forceRefreshCache = true;
			super.loadEnrichmentPlan();
		}
		super.process(input);
	}
	
	/**
	 * This facilitates black box testing.
	 * 
	 * @param planName
	 */
	public void changeEnrichmentPlan(String eptype, String planName) {
		if (!isEnrichmentPlanType(eptype)) {
			return;
		}
		
		if (super.enrichmentPlanName.equals(planName)) {
			System.out.println("EnrichmentBoltTest: No Change in EnrichmentPlanName ["+planName+"] ... skipping");
			return;
		}
				
		super.enrichmentPlanName = planName;
	}

}
