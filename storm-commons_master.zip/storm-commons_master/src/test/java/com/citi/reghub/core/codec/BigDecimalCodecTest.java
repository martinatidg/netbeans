package com.citi.reghub.core.codec;

import java.math.BigDecimal;

import org.junit.Test;

public class BigDecimalCodecTest extends CodecTestCase {

	@Test
	public void testBigDecimalStringCodec() {
		writeReadCompare(new BigDecimal("99.91"), new BigDecimalCodec());
		writeReadCompare(new BigDecimal(String.valueOf(Long.MAX_VALUE)), new BigDecimalCodec());
		writeReadCompare(new BigDecimal(String.valueOf(Long.MIN_VALUE)), new BigDecimalCodec());
	}

}
