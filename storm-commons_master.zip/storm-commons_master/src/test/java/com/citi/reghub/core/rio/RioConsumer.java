package com.citi.reghub.core.rio;

import com.citi.rio.registry.infra.Environment;
import com.citi.rio.registry.infra.Region;
import com.citi.rio.umb.UmbClientFactory;
import com.citi.rio.umb.payload.Payload.Key;
import com.citi.rio.umb.subscribe.UmbMessageHandler;
import com.citi.rio.umb.subscribe.UmbMessageHandlerFactory;
import com.citi.rio.umb.subscribe.UmbPayloadHandler;
import com.citi.rio.umb.subscribe.UmbSubscriber;
import com.citi.rio.umb.subscribe.exception.MessageHandlerCreationException;
import com.citi.rio.umb.subscribe.payload.IndividualPayload;

import java.util.Map;

public class RioConsumer {

	private Environment rioEnv = Environment.valueOf("DEV");
	private Region rioRegion = Region.valueOf("NAM");
	private String rioClientKey = "159766-SUB_DSP_NA_RRFQ_SNAPPYDATA-001";
	
	public RioConsumer environment(String env){
		rioEnv = Environment.valueOf(env);
		return this;
	}
	
	public RioConsumer region(String region){
		rioRegion = Region.valueOf(region);
		return this;
	}
	
	public RioConsumer subscriptionKey(String key){
		rioClientKey = key;
		return this;
	}

	private UmbSubscriber<IndividualPayload<String>> subscriber;

	private UmbPayloadHandler<String, IndividualPayload<String>> handler;

	@SuppressWarnings("rawtypes")
	public void subscribe(long subscriptionTime) {

		UmbClientFactory clientFactory = new UmbClientFactory(rioEnv, rioRegion);

		subscriber = clientFactory.createSubscriber(rioClientKey, new UmbMessageHandlerFactory<IndividualPayload<String>>() {

			public UmbMessageHandler<IndividualPayload<String>> create(final Map<Key, Object> metaData) throws MessageHandlerCreationException {

				handler = new UmbPayloadHandler<String, IndividualPayload<String>>() {

					public void onPayload(final IndividualPayload<String> payload) {
						System.out.println(payload.getContent());
						payload.commit();
					}

					public void onApplicationError(final IndividualPayload<String> payload, final RuntimeException error) {
						System.out.println("Application Error: " + error);
					}

					public void onConnectionError(final Exception error) {
						System.out.println("Connection Error: " + error);
					}
				};

				return handler;
			}
		});
		
		long currentTime = System.currentTimeMillis();
		long endTime = currentTime+subscriptionTime;
		while(System.currentTimeMillis() < endTime){
			
		}
		subscriber.shutdown();
	}
	
	public static void main(String[] args){
		new RioConsumer().subscribe(10000);
	}
}
