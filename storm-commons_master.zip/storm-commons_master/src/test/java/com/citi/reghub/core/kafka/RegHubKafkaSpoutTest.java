package com.citi.reghub.core.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.kafka.spout.KafkaSpout;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;

public class RegHubKafkaSpoutTest {
	
	/*
	 * Null config reference test
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testNullConfigRefernce() throws Exception {
		RegHubKafkaSpout.builder(null, null, null).build();
	}
	
	/*
	 * Test successful spout creation
	 */
	@Test
	public void testRegHubKafkaSpoutCreation() throws Exception {
		Map<String, String> config = new PropertiesLoader().getProperties("test");
		String sourceKafkaTopics = config.get("kafka.topic.names");
		String sourceStreamName = config.get("topolgy.stream.name");
		
		KafkaSpout spout = RegHubKafkaSpout.builder(sourceKafkaTopics, sourceStreamName, config)
				.setKeyDesClazz(StringDeserializer.class)
				.setValueDesClazz(StringDeserializer.class)
				.build()
				.getSpout();
		
		Assert.assertNotNull("Kafka spout reference should not be null", spout);
	}
	
	/*
	 * Test successful spout creation
	 */
	@Test
	public void testRegHubKafkaSpoutCreationWithMinConfig() throws Exception {
		Map<String, String> config = new HashMap<String, String>();
		String sourceKafkaTopics = "test";
		String sourceStreamName = "test_stream";
		config.put("kafka.commons.bootstrap.servers", "localhost:9092");
		
		KafkaSpout spout = RegHubKafkaSpout.builder(sourceKafkaTopics, sourceStreamName, config)
				.setKeyDesClazz(StringDeserializer.class)
				.setValueDesClazz(StringDeserializer.class)
				.build()
				.getSpout();
		
		Assert.assertNotNull("Kafka spout reference should not be null", spout);
	}
	
	/*
	 * Test kafka spout creation failure by providing incomplete or empty configuration
	 */
	@Test
	public void testKafkaSpoutConfigValidation() {
		Map<String, String> config = new PropertiesLoader().getProperties("test");
		String sourceKafkaTopics = config.get("kafka.topic.names");
		String sourceStreamName = config.get("topolgy.stream.name");
		try {
			config.remove("kafka.spout.max.delay.seconds");
			KafkaSpout spout = RegHubKafkaSpout.builder(sourceKafkaTopics, sourceStreamName, config)
					.setKeyDesClazz(StringDeserializer.class)
					.setValueDesClazz(StringDeserializer.class)
					.build().getSpout();
		} catch (Exception e) {
			Assert.assertTrue("Excpectd KeyNotFoundException", e instanceof IllegalArgumentException);
			Assert.assertTrue("Exception message should contain the missing field", e.getMessage().contains(RegHubKafkaSpout.ERROR_MESSAGE));
		}
	}
}
