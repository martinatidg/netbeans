package com.citi.reghub.core.blackbox;

import org.apache.storm.tuple.Tuple;

import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.EntityMapperBolt;

public class EntityMapperBoltTest extends EntityMapperBolt implements EntityMapperChangeInterface {

	private static final long serialVersionUID = 1L;
	
	private static int ID_COUNTER = 0;
	
	private final int    			id;
	
	public EntityMapperBoltTest(EntityMapper mapper) {
		super(mapper);

		synchronized(EligibilityBoltTest.class) {
			id = ID_COUNTER++;
		}
		
		SingletonBoltTestController.registerBolt(this);
	}

	public int getID() {
		return this.id;
	}
	
	public EntityMapper getEntityMapper() {
		return super.mapper;
	}
	
	public void process(Tuple tuple) {
		EntityMapper em = SingletonBoltTestController.getCurrentEntityMapper(this);
		if (!super.mapper.getClass().getName().equals(em.getClass().getName())) {
			System.out.println("Changing EntityMapper Bolt Mapper from ["+super.mapper.getClass().getName()+"] to ["+em.getClass().getName()+"]");
			super.mapper = em;
		}
		
		super.process(tuple);
	}

		
	/**
	 * This is used to faciliate black box testing.
	 * 
	 * @param mapper
	 */
	public void changeEntityMapper(EntityMapper mapper) {
		super.mapper = mapper;
	}
}
