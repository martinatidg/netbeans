package com.citi.reghub.core;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.StormStreams;


public class TradeStatusTranslationBoltTest {

	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	TradeStatusTranslationBolt boltWithoutTranslation;
	TradeStatusTranslationBolt boltWithTranslation;
	TradeStatusTranslationBolt boltWithTranslationLogic;
	RestClient restClient;

	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		boltWithoutTranslation = new TradeStatusTranslationBolt(new TradeStatusTranslationAbstractFactory() {
			
			@Override
			public TradeStatusTranslator getTranslator(Entity inputEntity) {
				return null;
			}

			@Override
			public void addTranslator(String identifier, TradeStatusTranslator statusTranslator) {
				// TODO Auto-generated method stub
				
			}
		});
		
		boltWithTranslation = new TradeStatusTranslationBolt(new TradeStatusTranslationAbstractFactory() {
			
			@Override
			public TradeStatusTranslator getTranslator(Entity inputEntity) {
				return new TradeStatusTranslator() {
					
					@Override
					public List<Entity> translateTradeStatus(Entity currentEntity, Entity prevEntity) {
						// TODO Auto-generated method stub
						return Arrays.asList(currentEntity);
					}
				};
			}

			@Override
			public void addTranslator(String identifier, TradeStatusTranslator statusTranslator) {
				// TODO Auto-generated method stub
				
			}
		});
		
		restClient = Mockito.mock(RestClient.class);
	}

	@After
	public void tearDown() {
		boltWithoutTranslation.cleanup();
		boltWithTranslation.cleanup();
	}

	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}
	
	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		boltWithoutTranslation.declareOutputFields(declarer);
		verify(declarer, times(3)).declareStream(any(String.class), any(Fields.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldPrepareBolt() {
		Map<Object, Object> configMap = new HashMap<>();
		configMap.put("cache.provider", "hazelcast");
		configMap.put(boltWithoutTranslation.ENTITY_SERVICE_URL_QUERY, "localhost/entity-service/stream={0}+flow={1}+sourceId={2}");
		Map<Object, Object> stormConf = new HashMap<>();
		stormConf.put("topologyConfig", configMap);
		stormConf.put("topology.stream", "stream");
		stormConf.put("topology.flow", "flow");
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithoutTranslation.prepare(stormConf, context, _collector);
		assertNotNull(boltWithoutTranslation.restClient);
		assertNotNull(boltWithoutTranslation.serviceUrl);
		assertEquals("localhost/entity-service/stream={0}+flow={1}+sourceId={2}",boltWithoutTranslation.serviceUrl);
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitInputTupleWithoutTranslation() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithoutTranslation.restClient = restClient;
		boltWithoutTranslation.serviceUrl = "localhost/entity-service/stream=stream+flow=flow+sourceId={2}";
		boltWithoutTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithoutTranslation.serviceUrl, trade.sourceId), Entity.class)).thenReturn(Arrays.asList(trade));
		boltWithoutTranslation.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitInputTupleWithTranslation() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithTranslation.restClient = restClient;
		boltWithTranslation.serviceUrl = "localhost/entity-service/stream=stream+flow=flow+sourceId={2}";
		boltWithTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithTranslation.serviceUrl, trade.sourceId), Entity.class)).thenReturn(Arrays.asList(trade));
		boltWithTranslation.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldEmitExceptionTuple() {
		Entity entity = new EntityBuilder().build();
		entity.sourceStatus = null;
		OutputCollector collector = mock(OutputCollector.class);
		boltWithoutTranslation._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		boltWithoutTranslation.execute(tuple);
		verify(collector, times(2)).emit(any(String.class), any(Values.class));
		verify(collector).emit(StormStreams.EXCEPTION, new Values(entity.regHubId, entity));
	}
	
	@Test
	public void testGetPreviousEntityWhenNoPrevEntityPresentReturnNull() {
		Entity currentTrade = new EntityBuilder().sourceId("tradeId").sourceUid("id1").build();
		Tuple tuple = mockNormalTuple(currentTrade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithTranslation.restClient = restClient;
		boltWithTranslation.serviceUrl = "localhost/entity-service/stream=stream+flow=flow+sourceId={2}";
		boltWithTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithTranslation.serviceUrl, currentTrade.sourceId), Entity.class)).thenReturn(null);
		Entity previousEntity = boltWithTranslation.getPreviousEntity(currentTrade);
		assertNull(previousEntity);
	}
	
	@Test
	public void testGetPreviousEntityWhenNoPrevEntityPresent() {
		Entity currentTrade = new EntityBuilder().sourceId("tradeId").sourceUid("id1").build();
		Tuple tuple = mockNormalTuple(currentTrade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithTranslation.restClient = restClient;
		boltWithTranslation.serviceUrl = "localhost/entity-service/stream=stream+flow=flow+sourceId={2}";
		boltWithTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithTranslation.serviceUrl, currentTrade.sourceId), Entity.class)).thenReturn(new ArrayList<Entity>());
		Entity previousEntity = boltWithTranslation.getPreviousEntity(currentTrade);
		assertNull(previousEntity);
	}
	
	@Test
	public void testGetPreviousEntityWhenPrevEntityPresentButCurrentEntityNotPresent() {
		Entity currentTrade = new EntityBuilder().sourceId("tradeId").sourceUid("id3").build();
		Entity p1 = new EntityBuilder().sourceId("tradeId").sourceUid("id1").build();
		Entity p2 = new EntityBuilder().sourceId("tradeId").sourceUid("id2").build();
		Tuple tuple = mockNormalTuple(currentTrade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithTranslation.restClient = restClient;
		boltWithTranslation.serviceUrl = "localhost/entity-service/stream={0}+flow={1}+sourceId={2}";
		boltWithTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithTranslation.serviceUrl,null,null, currentTrade.sourceId), Entity.class)).thenReturn(Arrays.asList(p2,p1));
		Entity previousEntity = boltWithTranslation.getPreviousEntity(currentTrade);
		assertEquals("id2",previousEntity.sourceUId);
	}
	
	@Test
	public void testGetPreviousEntityWhenPrevEntityPresentButCurrentEntityAlsoPresent() {
		Entity currentTrade = new EntityBuilder().sourceId("tradeId").sourceUid("id3").build();
		Entity p1 = new EntityBuilder().sourceId("tradeId").sourceUid("id1").build();
		Entity p2 = new EntityBuilder().sourceId("tradeId").sourceUid("id2").build();
		Entity p3 = new EntityBuilder().sourceId("tradeId").sourceUid("id3").build();
		Tuple tuple = mockNormalTuple(currentTrade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithTranslation.restClient = restClient;
		boltWithTranslation.serviceUrl = "localhost/entity-service/stream={0}+flow={1}+sourceId={2}";
		boltWithTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithTranslation.serviceUrl,null,null, currentTrade.sourceId), Entity.class))
		.thenReturn(Arrays.asList(p3,p2,p1));
		Entity previousEntity = boltWithTranslation.getPreviousEntity(currentTrade);
		assertEquals("id2",previousEntity.sourceUId);
	}
	
	@Test
	public void testGetPreviousEntityWhenPrevEntityPresentButCurrentEntityAlsoPresentAndNextEntityAlsoPresent() {
		Entity currentTrade = new EntityBuilder().sourceId("tradeId").sourceUid("id3").build();
		Entity p1 = new EntityBuilder().sourceId("tradeId").sourceUid("id1").build();
		Entity p2 = new EntityBuilder().sourceId("tradeId").sourceUid("id2").build();
		Entity p3 = new EntityBuilder().sourceId("tradeId").sourceUid("id3").build();
		Entity p4 = new EntityBuilder().sourceId("tradeId").sourceUid("id4").build();
		Tuple tuple = mockNormalTuple(currentTrade);
		OutputCollector _collector = mock(OutputCollector.class);
		boltWithTranslation.restClient = restClient;
		boltWithTranslation.serviceUrl = "localhost/entity-service/stream={0}+flow={1}+sourceId={2}";
		boltWithTranslation._collector = _collector;
		when(restClient.getValues(MessageFormat.format(boltWithTranslation.serviceUrl,null,null, currentTrade.sourceId), Entity.class))
		.thenReturn(Arrays.asList(p4,p3,p2,p1));
		Entity previousEntity = boltWithTranslation.getPreviousEntity(currentTrade);
		assertEquals("id2",previousEntity.sourceUId);
	}

}