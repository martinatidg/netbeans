package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.CitimlParserBolt;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.StormConstants;

public class CitimlParserBoltTest {
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	public CitimlParserBolt parserBolt;
	public String citimlMsg;
	Map props = new HashMap<>();
	
	@Before
	public void setup() throws DocumentException{
		Map topologyConfig = new HashMap<>();
		topologyConfig.put("topology.stream", "M2PO");
		topologyConfig.put("topology.flow", "COM");
		props.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		parserBolt = new CitimlParserBolt();
		SAXReader reader = new SAXReader();
		Document doc = reader.read(CitimlParserBoltTest.class.getClassLoader().getResourceAsStream("citiml.xml"));
		citimlMsg = doc.asXML();
	}
	
	private Tuple mockNormalTuple(String key , Object message) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("key")).thenReturn(key);
		when(tuple.getValueByField("message")).thenReturn(message);
		return tuple;
	}
	
	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		parserBolt.declareOutputFields(declarer);
		verify(declarer, times(3)).declareStream(any(String.class), any(Fields.class));
	}
	
	@Test
	public void shouldEmitSourceStreamTest(){
		RawMsgObject obj = new RawMsgObject();
		obj.setMessage(citimlMsg);
		Tuple tuple = mockNormalTuple("123456",obj);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		parserBolt.prepare(props, context, _collector);
		parserBolt.execute(tuple);
		verify(_collector, times(1)).emit(eq(StormStreams.SOURCE), any(Values.class));
	}
	
	@Test
	public void shouldEmitExceptionAndAuditStreamTest(){
		Tuple tuple = mockNormalTuple("123456","fjhfjhgfhjgkgkjhgk");
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		parserBolt.prepare(props, context, _collector);
		parserBolt.execute(tuple);
		verify(_collector, times(1)).emit(eq(StormStreams.EXCEPTION), any(Values.class));
		verify(_collector, times(1)).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void validateExceptionEntityAndAuditObjects(){
		Tuple tuple = mockNormalTuple("123456","fjhfjhgfhjgkgkjhgk");
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		parserBolt.prepare(props, context, _collector);
		Entity entity = parserBolt.createExceptionEntity(tuple);
		assertEquals("123456",entity.regHubId);
		assertEquals("M2PO",entity.stream);
		assertEquals("COM",entity.flow);
		assertNull(entity.lastUpdatedTs);
		assertNull(entity.executionTs);
		assertNull(entity.publishedTs);
		assertNull(entity.receivedTs);
		assertNull(entity.regReportingRef);
		assertNull(entity.sourceId);
		assertNull(entity.sourceStatus);
		assertNull(entity.sourceUId);
		assertNull(entity.sourceVersion);
		assertNull(entity.sourceSystem);
		assertTrue(entity.reasonCodes.isEmpty());
		assertTrue(entity.info.isEmpty());
		assertEquals(EntityStatus.APP_EXCEPTION,entity.status);
		Audit audit = parserBolt.createAudit(entity, new NullPointerException());
		assertEquals("123456",audit.regHubId);
		assertEquals("M2PO",audit.stream);
		assertEquals("COM",audit.flow);
		assertEquals(StormConstants.SOURCE_APP_EXCEPTION,audit.event);
		assertEquals(StormConstants.ERROR,audit.result);
		assertEquals(NullPointerException.class.getName(),audit.info.get(StormConstants.MESSAGE));
		assertNotNull(audit.info.get(StormConstants.STACKTRACE));
		assertTrue(audit.tags.contains(StormConstants.SOURCE));
		assertTrue(audit.tags.contains(StormConstants.EXCEPTIONS));
		assertTrue(audit.tags.contains(StormConstants.PARSE_EXCEPTION));
	}

}
