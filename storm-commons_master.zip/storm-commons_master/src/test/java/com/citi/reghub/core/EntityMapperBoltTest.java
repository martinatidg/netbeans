package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.EntityMapperBolt;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.StormConstants;

public class EntityMapperBoltTest {
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	public EntityMapperBolt mapperBolt;
	
	Map props = new HashMap<>();
	
	@Before
	public void setup(){
		Map topologyConfig = new HashMap<>();
		topologyConfig.put("topology.stream", "M2PO");
		topologyConfig.put("topology.flow", "CSHFI");
		props.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		mapperBolt = new EntityMapperBolt(new EntityMapper() {
			
			@Override
			public Entity mapToEntity(Object message,Entity entity) {
				if(message == null)
					throw new NullPointerException();
				return new EntityBuilder().build();
			}
		});
	}
	
	private Tuple mockNormalTuple(String key , Object message) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("key")).thenReturn(key);
		when(tuple.getValueByField("message")).thenReturn(message);
		return tuple;
	}
	
	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		mapperBolt.declareOutputFields(declarer);
		verify(declarer, times(3)).declareStream(any(String.class), any(Fields.class));
	}
	
	@Test
	public void shouldEmitInputTuple() {
		Tuple tuple = mockNormalTuple("123456","");
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mapperBolt.prepare(props, context, _collector);
		mapperBolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
	}
	
	@Test
	public void shouldEmitSourceAndAuditStreamTest(){
		Tuple tuple = mockNormalTuple("123456","");
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mapperBolt.prepare(props, context, _collector);
		mapperBolt.execute(tuple);
		verify(_collector, times(1)).emit(eq(StormStreams.SOURCE), any(Values.class));
		verify(_collector, times(1)).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldEmitExceptionAndAuditStreamTest(){
		Tuple tuple = mockNormalTuple("123456",null);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mapperBolt.prepare(props, context, _collector);
		mapperBolt.execute(tuple);
		verify(_collector, times(1)).emit(eq(StormStreams.EXCEPTION), any(Values.class));
		verify(_collector, times(1)).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void validateExceptionEntityAndAuditObjects(){
		Tuple tuple = mockNormalTuple("123456",null);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mapperBolt.prepare(props, context, _collector);
		Entity entity = mapperBolt.createExceptionEntity(tuple);
		assertEquals("123456",entity.regHubId);
		assertEquals("M2PO",entity.stream);
		assertEquals("CSHFI",entity.flow);
		assertNull(entity.executionTs);
		assertNull(entity.publishedTs);
		assertNull(entity.receivedTs);
		assertNull(entity.regReportingRef);
		assertNull(entity.sourceId);
		assertNull(entity.sourceStatus);
		assertNull(entity.sourceUId);
		assertNull(entity.sourceVersion);
		assertNull(entity.sourceSystem);
		assertTrue(entity.reasonCodes.isEmpty());
		assertTrue(entity.info.isEmpty());
		assertEquals(EntityStatus.APP_EXCEPTION,entity.status);
		Audit audit = mapperBolt.createAudit(entity, new NullPointerException());
		assertEquals("123456",audit.regHubId);
		assertEquals("M2PO",audit.stream);
		assertEquals("CSHFI",audit.flow);
		assertEquals(StormConstants.SOURCE_APP_EXCEPTION,audit.event);
		assertEquals(StormConstants.ERROR,audit.result);
		assertEquals(NullPointerException.class.getName(),audit.info.get(StormConstants.MESSAGE));
		assertNotNull(audit.info.get(StormConstants.STACKTRACE));
		assertTrue(audit.tags.contains(StormConstants.SOURCE));
		assertTrue(audit.tags.contains(StormConstants.EXCEPTIONS));
		assertTrue(audit.tags.contains(StormConstants.ENTITY_CREATION_EXCEPTION));
	}

	

}
