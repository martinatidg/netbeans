package com.citi.reghub.core.kafka;

import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.storm.kafka.bolt.KafkaBolt;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.kafka.RegHubKafkaBolt;

public class RegHubKafkaBoltTest {

	@Test(expected = IllegalArgumentException.class)
	public void testNullConfigRefernce() throws Exception {
		RegHubKafkaBolt.getKafkaBolt(null, null, null);
	}
	
	@Test
	public void testKafkaBoltCreation() throws Exception {
		Map<String, String> config = new PropertiesLoader().getProperties("test");
		KafkaBolt<Object, Object> bolt = RegHubKafkaBolt.getKafkaBolt(config, "test", "bolt");
		Assert.assertNotNull("Kafka bolt reference should not be null", bolt);
	}
	
	@Test
	public void testMultipleKafkaBoltCreation() throws Exception {
		Map<String, String> config1 = new PropertiesLoader().getProperties("test");
		KafkaBolt<Object, Object> bolt1 = RegHubKafkaBolt.getKafkaBolt(config1, "test", "bolt1");
		Map<String, String> config2 = new PropertiesLoader().getProperties("test");
		KafkaBolt<Object, Object> bolt2 = RegHubKafkaBolt.getKafkaBolt(config2, "test", "bolt2");

		Assert.assertNotNull("Kafka bolt reference should not be null", bolt1);
		Assert.assertNotNull("Kafka bolt reference should not be null", bolt2);
	}
	
	@Test
	public void testKafkaBoltConfigValidation() {
		Map<String, String> config = new PropertiesLoader().getProperties("test");
		String sourceKafkaTopics = config.get("bolt.kafka.topic.names");

		try {
			config.remove("producer." + ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG);
			RegHubKafkaBolt.getKafkaBolt(config, "test", "bolt");
		} catch (Exception e) {
			Assert.assertTrue("Excpectd KeyNotFoundException", e instanceof IllegalArgumentException);
			Assert.assertTrue("Exception message should contain the missing field", e.getMessage().contains(RegHubKafkaBolt.ERROR_MESSAGE));
		}
	}
}
