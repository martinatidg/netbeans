package com.citi.reghub.core;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.SequencerBolt;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.HazelcastCacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;


@RunWith(JUnit4.class)
public class APATradeIdEnrichmentBoltTest {
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	private APATradeIdEnrichmentBolt bolt;
	HazelcastCacheClient cacheClient;
	HazelcastInstance hzInstance;


	@Before
	public void setUp() throws Exception {
		hzInstance = Hazelcast.newHazelcastInstance();
		Map props = new HashMap<>();
		props.put("cache.provider", "hazelcast");
		props.put("hazelcast.group.name", "dev");
		props.put("hazelcast.group.password", "dev-pass");
		props.put("hazelcast.network.address", "localhost");
		cacheClient = new HazelcastCacheClient(props);
		bolt = new APATradeIdEnrichmentBolt();
		bolt.cacheClient = cacheClient;
		bolt.cacheconfig = new HashMap<>();
		bolt.cacheconfig.put(CacheClient.CACHE_COLLECTION_NAME, "APATradeIdEnrichmentBoltTestCache");
		bolt.cacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");

		
	}

	@After
	public void tearDown() {
		cacheClient.destroy();
		hzInstance.shutdown();
		bolt.cleanup();
	}
	
	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}

	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		APATradeIdEnrichmentBolt bolt = new APATradeIdEnrichmentBolt();
		bolt.declareOutputFields(declarer);
		verify(declarer, times(4)).declareStream(any(String.class), any(Fields.class));
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitInputTuple() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt._collector = _collector;
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));

	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitReportableAndAuditStreamTest() {
		Entity trade = new EntityBuilder().regHubId("1").sourceStatus("NEW").info("tradeDate", LocalDate.now()).build();
		Tuple tuple = mockNormalTuple(trade);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt._collector = _collector;
		bolt.execute(tuple);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.sourceId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitReportableStreamTest() {
		Entity trade = new EntityBuilder().sourceId("source1234").flow("csheq").stream("m2tr").sourceStatus("AMEND").build();
		Tuple tuple = mockNormalTuple(trade);
		RawOutboundRecord record=new RawOutboundRecord();
		record.ackId="1234";
		Map stormConf = mock(Map.class);
		Map topologyConfig=mock(Map.class);
		when(topologyConfig.get("raw.outbound.service.url")).thenReturn("localhost:8135/{0}?stream={1}&flow={2}");
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt._collector = _collector;
		bolt.url="localhost:8135/{0}?stream={1}&flow={2}";
		bolt.restClient=mock(RestClient.class);
 		when((bolt.restClient).get("localhost:8135/source1234?stream=m2tr&flow=csheq", RawOutboundRecord.class)).thenReturn(record);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.sourceId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));

	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitExceptionStreamTest1() {
		Entity trade = new EntityBuilder().sourceId("source1").flow("csheq").stream("m2tr").sourceStatus("AMEND").build();
		Tuple tuple = mockNormalTuple(trade);
		RawOutboundRecord record=new RawOutboundRecord();
		record.ackId=null;
		Map stormConf = mock(Map.class);
		Map topologyConfig=mock(Map.class);
		when(topologyConfig.get("raw.outbound.service.url")).thenReturn("localhost:8135/{0}?stream={1}&flow={2}");
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt._collector = _collector;
		bolt.restClient=mock(RestClient.class);
 		when((bolt.restClient).get("localhost:8135/source1?stream=m2tr&flow=csheq", RawOutboundRecord.class)).thenReturn(record);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.EXCEPTION, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));

	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitExceptionStreamTest2() {
		Entity trade = new EntityBuilder().sourceId("source1").flow("csheq").stream("m2tr").sourceStatus("AMEND").build();
		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		Map topologyConfig=mock(Map.class);
		when(topologyConfig.get("raw.outbound.service.url")).thenReturn("localhost:8135/{0}?stream={1}&flow={2}");
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt._collector = _collector;
		bolt.restClient=mock(RestClient.class);
 		when((bolt.restClient).get("localhost:8135/source1?stream=m2tr&flow=csheq", RawOutboundRecord.class)).thenReturn(null);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.EXCEPTION, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));

	}
}