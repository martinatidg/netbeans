package com.citi.reghub.core.blackbox;

import java.util.ArrayList;
import java.util.List;

import com.citi.reghub.core.EntityMapper;

/**
 * This Singleton implementation is used to dynamically change Bolts that registered for updates at runtime.
 * 
 * The Singleton pattern needs to be used in order to allow a mechanism for changing this.  This will only work
 * when running the LocalCluster during testing.
 * 
 * @author sk73543
 *
 */
public class SingletonBoltTestController {
	
	public static final String RULES_PRE_ENRICHMENT 			= "1";
	public static final String RULES_POST_ENRICHMENT 			= "2";
	public static final String RULES_POST_ENRICHMENT_NR 		= "3";
	
	public static final String RULES_ENRICHMENT_NORMALIZATION 	= "10";
	public static final String RULES_ENRICHMENT_COMMON 			= "11";

	private static List<EntityMapperBoltTest> BOLTS_ENTITY_MAPPER;
	private static List<EligibilityBoltTest>  BOLTS_ELIGIBILITY;
	private static List<EnrichmentBoltTest>   BOLTS_ENRICHMENT;
	
	static {
		BOLTS_ENTITY_MAPPER = new ArrayList<EntityMapperBoltTest>();
		BOLTS_ELIGIBILITY = new ArrayList<EligibilityBoltTest>();
		BOLTS_ENRICHMENT = new ArrayList<EnrichmentBoltTest>();
	}
	
	public static final void registerBolt(EligibilityBoltTest eb) {
		System.out.println("Registering Eligibility Bolt: "+eb.getRuleGraphName());
		BOLTS_ELIGIBILITY.add(eb);
	}
	
	public static final void registerBolt(EntityMapperBoltTest emb) {
		BOLTS_ENTITY_MAPPER.add(emb);
	}
	
	public static final void registerBolt(EnrichmentBoltTest eb) {
		System.out.println("Registering Enrichment Bolt: "+eb.getEnrichmentPlanName());
		BOLTS_ENRICHMENT.add(eb);
	}
	
	public static final String getCurrentRuleGraph(EligibilityBoltTest ebt) {
		for (EligibilityBoltTest e : BOLTS_ELIGIBILITY) {
			if (e.getID() == ebt.getID()) {
				return e.getRuleGraphName();
			}
		}
		return null;
	}
	
	public static final EntityMapper getCurrentEntityMapper(EntityMapperBoltTest ebt) {
		for (EntityMapperBoltTest e : BOLTS_ENTITY_MAPPER) {
			if (e.getID() == ebt.getID()) {
				return e.getEntityMapper();
			}
		}
		return null;
	}

	public static final String getCurrentEnrichmentPlan(EnrichmentBoltTest ebt) {
		for (EnrichmentBoltTest e : BOLTS_ENRICHMENT) {
			if (e.getID() == ebt.getID()) {
				return e.getEnrichmentPlanName();
			}
		}
		
		return null;
	}
	
	public static final void changeRuleGraph(String rgtype, String rgraph) {
		for (EligibilityBoltTest eb : BOLTS_ELIGIBILITY) {
			if (eb.isRuleGraphType(rgtype)) {
				eb.changeRuleGraph(rgtype, rgraph);
			}
		}
	}
	
	public static final void changeEnrichmentPlan(String eptype, String eplan) {
		for (EnrichmentBoltTest eb : BOLTS_ENRICHMENT) {
			if (eb.isEnrichmentPlanType(eptype)) {
				eb.changeEnrichmentPlan(eptype, eplan);
			}
		}
	}
	
	public static final void changeEntityMapper(EntityMapper emapper) {
		for (EntityMapperBoltTest eb : BOLTS_ENTITY_MAPPER) {
			eb.changeEntityMapper(emapper);
		}
	}
	
}
