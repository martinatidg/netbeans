package com.citi.reghub.core;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CitimlParserTest {
	
	public static void main(String[] args) throws JAXBException, DocumentException, Exception{
		SAXReader reader = new SAXReader();
		Document doc = reader.read(CitimlParserTest.class.getClassLoader().getResourceAsStream("citiml.xml"));
		String citimlString = doc.asXML();
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

		org.w3c.dom.Document document = dBuilder.parse(new InputSource(new StringReader(citimlString)));
		document.getDocumentElement().normalize();

		XPath xPath =  XPathFactory.newInstance().newXPath();
		
		String xPathExpression = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent"
				+ "/nonpublicExecutionReport/trade/tradeHeader/partyTradeIdentifier/partyReference/@href";
		
		String tradeVenueTransactionId = (String) xPath.compile(xPathExpression).evaluate(document, XPathConstants.STRING);
		System.out.println(tradeVenueTransactionId);
		
		String xPathExpression1 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent"
				+ "/nonpublicExecutionReport/trade/tradeHeader/partyTradeInformation/executionDateTime";
		
		String tradeExecutionTsString = (String) xPath.compile(xPathExpression1).evaluate(document, XPathConstants.STRING);
		
		System.out.println(tradeExecutionTsString);
		
		System.out.println(LocalDateTime.parse(tradeExecutionTsString, DateTimeFormatter.ISO_DATE_TIME));
		
		String xPathExpression2 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade"
				+ "/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize[1]/citimlFixedInstrumentQuantity/quantity";

		String tradeQuantityString = (String) xPath.compile(xPathExpression2).evaluate(document, XPathConstants.STRING);
		Double tradeQuantity = Double.valueOf(tradeQuantityString);
		System.out.println(tradeQuantity);
		
		String xPathExpression3 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade"
				+ "/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize[1]/citimlFixedNotionalAmount/currency";

		String tradeCurrency = (String) xPath.compile(xPathExpression3).evaluate(document, XPathConstants.STRING);
		System.out.println("tradeCurrency"+tradeCurrency);
		
		String xPathExpression4 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent"
				+ "/nonpublicExecutionReport/trade/tradeHeader/partyTradeInformation/executionVenueType";

		String executionVenueType = (String) xPath.compile(xPathExpression4).evaluate(document, XPathConstants.STRING);
		System.out.println(executionVenueType);
		
		String xPathExpression5 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent"
				+ "/nonpublicExecutionReport/trade/tradeHeader/partyTradeInformation/intentToClear";

		String intentToClear = (String) xPath.compile(xPathExpression5).evaluate(document, XPathConstants.STRING);
		System.out.println(intentToClear);
		
		String xPathExpression6 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade"
				+ "/postEventTrade/genericProduct/primaryAssetClass";

		String instrumentClassification = (String) xPath.compile(xPathExpression6).evaluate(document, XPathConstants.STRING);
		System.out.println(instrumentClassification);
		
	}

}
