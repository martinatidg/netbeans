package com.citi.reghub.core.jms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.storm.spout.SpoutOutputCollector;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JMSSpoutTest {
	private static final Logger LOG = LoggerFactory.getLogger(JMSSpoutTest.class);
	private JMSSpout spout;
	private Topic topic;
	MockSpoutOutputCollector mockCollector;
	
	@Before
	public void setUp() throws NamingException, JMSException {
		spout = new JMSSpout();
		InitialContext jndiContext = new InitialContext();
		spout.conFactory = new ActiveMQConnectionFactory("vm://localhost?broker.persistent=false");
		spout.topicConnection=spout.conFactory.createTopicConnection();
		spout.topicSession = spout.topicConnection.createTopicSession(false, Session.CLIENT_ACKNOWLEDGE);
		topic = spout.topicSession.createTopic("test");
		spout.subscriber = spout.topicSession.createSubscriber(topic);
		spout.subscriber.setMessageListener(spout);
		spout.topicConnection.setExceptionListener(spout);
		spout.topicConnection.start();
		mockCollector = new MockSpoutOutputCollector();
		SpoutOutputCollector collector = new SpoutOutputCollector(mockCollector);
		spout.collector = collector;
		spout.queue = new LinkedBlockingQueue<>();
		spout.pendingMessages = new ConcurrentHashMap<>();
	}

	@Test
	public void testFailure() throws JMSException, Exception {
		Message msg = this.sendMessage(spout.conFactory, topic);
		Thread.sleep(5000);
		spout.nextTuple(); // Pretend to be storm.
		Assert.assertTrue(mockCollector.emitted);
		/*mockCollector.reset();
		spout.fail(msg.getJMSMessageID()); // Mock failure
		Thread.sleep(5000);
		spout.nextTuple(); // Pretend to be storm.
		Thread.sleep(5000);
		Assert.assertTrue(mockCollector.emitted); // Should have been re-emitted*/
	}

	@Test
	public void testSerializability() throws IOException {
		JMSSpout spout = new JMSSpout();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(out);
		oos.writeObject(spout);
		oos.close();
		Assert.assertTrue(out.toByteArray().length > 0);
	}

	public Message sendMessage(TopicConnectionFactory connectionFactory, Destination destination) throws JMSException {
		Session mySess = connectionFactory.createConnection().createSession(false, Session.CLIENT_ACKNOWLEDGE);
		MessageProducer producer = mySess.createProducer(destination);
		TextMessage msg = mySess.createTextMessage();
		msg.setText("Hello World");
		LOG.info("Sending Message: {}", msg.getText());
		producer.send(msg);
		return msg;
	}

}