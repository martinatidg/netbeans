package com.citi.reghub.core.rio;

import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.rio.spouts.RioSpout;

import org.apache.storm.spout.SpoutOutputCollector;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

@Ignore
public class RioSpoutTest {
	
	SpoutOutputCollector collector;
	MockSpoutOutputCollector mockCollector;
	
	
	@Before
	public void setUp(){
		mockCollector = new MockSpoutOutputCollector();
		collector = new SpoutOutputCollector(mockCollector);
	}
	
	@Test
	public void testSuccess() throws Exception{
		RioSpout rioSpout = new RioSpout(new PropertiesLoader().getProperties("test"),"rio-spout");
		rioSpout.open(null, null, collector);
		new RioPublisher().publish();
		Thread.sleep(1000);
		rioSpout.nextTuple();
		assertTrue(mockCollector.emitted);
		rioSpout.close();
	}
	
	@Test
	public void testFailure() throws Exception{
		RioSpout rioSpout = new RioSpout(new PropertiesLoader().getProperties("test"),"rio-spout"){
			@Override
			public String generateReghubId() {
				return "123456";
			}
		};
		rioSpout.open(null, null, collector);
		new RioPublisher().publish();
		Thread.sleep(1000);
		rioSpout.nextTuple();
		rioSpout.fail("123456");
		Thread.sleep(5000);
		assertTrue(mockCollector.emitted);
		rioSpout.close();
	}

}
