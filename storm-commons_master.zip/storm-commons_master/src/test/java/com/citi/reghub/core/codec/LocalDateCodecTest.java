package com.citi.reghub.core.codec;

import java.time.LocalDate;

import org.junit.Test;

public class LocalDateCodecTest extends CodecTestCase {

	@Test
	public void testLocalDateStringCodec() {
		writeReadCompare(LocalDate.now(), new LocalDateCodec());
	}
}
