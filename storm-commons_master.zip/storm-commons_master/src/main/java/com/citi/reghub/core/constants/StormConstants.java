package com.citi.reghub.core.constants;

public interface StormConstants {

	public static final String EXCEPTIONS = "exceptions";
	public static final String ERROR = "Error";
	public static final String MESSAGE = "message";
	public static final String STACKTRACE = "stacktrace";
	
	public static final String SOURCE = "Source";
	public static final String SOURCE_APP_EXCEPTION = "SOURCE_APP_EXCEPTION";
	public static final String ENTITY_CREATION_EXCEPTION = "ENTITY_CREATION_EXCEPTION";
	
	public static final String SENDER = "Sender";
	public static final String SENDER_APP_EXCEPTION = "SENDER_APP_EXCEPTION";
	public static final String FIX_MSG_GENERATION_EXCEPTION = "FIX_MSG_GENERATION_EXCEPTION";

	public static final String DOMAIN = "Domain";
	public static final String DOMAIN_APP_EXCEPTION = "DOMAIN_APP_EXCEPTION";
	
	public static final String SEQUENCER = "Sequencer";
	public static final String TRADE_STATUS_TRANSLATOR = "Trade Status Translator";
	public static final String SEQUENCER_APP_EXCEPTION  = "SEQUENCER_APP_EXCEPTION";
	public static final String TRADE_STATUS_APP_EXCEPTION  = "TRADE_STATUS_APP_EXCEPTION";
	public static final String PARSE_EXCEPTION = "PARSE_EXCEPTION";
	

	// TODO: revisit RIO properties
	public static final String RIO_ENV = "rio.env";
	public static final String RIO_REGION = "rio.region";
	public static final String RIO_SUBSCRIBER_KEY = "rio.subscriber.key";
	
	//JMS Spout constants constants
	public static final String APA_TOPIC_NAME = "apa.topic.name";
	public static final String APA_USERNAME="apa.user.name";
	public static final String APA_PASSWORD="apa.password";
	public static final String APA_JNDI_NAME="apa.jndi.name";
	public static final String APA_FACTORY_NAME="apa.factory.name";
	public static final String APA_PROVIDER_URL="apa.provider.url";
	public static final String APA_SUBSCRIBER_NAME="apa.subscriber.name";
	public static final String APA_PROVIDER_NAME="apa.provider.name";
	public static final String APA_PROVIDER_PROTOCOL="apa.provider.protocol";
	
	public static final String RESPONSE_CONSUMER = "RESPONSE_CONSUMER";
	public static final String RESPONSE_CONSUMER_EXCEPTION = "RESPONSE_CONSUMER_EXCEPTION";
	
	//TODO: Revisit JMS properties
	public static final String JMS_PROVIDER_TIBCO = "TIBCO"; 
	public static final String JMS_PROTOCOL_SSL = "ssl";
	public static final String JMS_PROVIDER_TIBCO_NAMING = "com.TIBCO.tibjms.naming";
	public static final String JMS_MESSAGE_SOURCE_SYSTEM_VERTICAL ="VERTICAL";
	public static final String JMS_MESSAGE_SOURCE_SYSTEM_EXTERNAL ="EXTERNAL";
}
