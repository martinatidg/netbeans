package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.rules.client.RuleGraph;
import com.citi.reghub.core.rules.client.RuleGraphResult;
import com.citi.reghub.core.rules.client.RulesClient;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

public class EligibilityBolt extends RegHubBolt {

	private static final Logger LOG = LoggerFactory.getLogger(EligibilityBolt.class);
	private static final long serialVersionUID = 1L;
	
	private OutputCollector _collector;


	public    RuleGraph   ruleGraph;
	protected RulesClient rulesClient;

	protected String  ruleGraphName;
	protected long    ruleGraphCurrentLoadTime;
	protected boolean forceRefreshCache;

	
	public EligibilityBolt(){
		super();
	}
	
	public EligibilityBolt(String ruleGraphName){
		this.ruleGraphName = ruleGraphName;
	}
	
	public String getRuleGraphName() {
		return this.ruleGraphName;
	}
		
	protected void loadRuleGraph(){
		ruleGraph = rulesClient.load(ruleGraphName);
		ruleGraphCurrentLoadTime = rulesClient.getLastLoadTime(ruleGraphName);
		forceRefreshCache = true;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		setCacheClient(topologyConfig);
		setRuleClient(topologyConfig);
		setMetadataClient(topologyConfig);
		rulesClient = SingletonRulesClient.getInstance();
		loadRuleGraph();	
	}

	private static String getStreamIdByEntityStatus(String status) {
		if(EntityStatus.REPORTABLE.equalsIgnoreCase(status)){
			return StormStreams.REPORTABLE;
		} else if(EntityStatus.NON_REPORTABLE.equalsIgnoreCase(status)) {
			return StormStreams.NON_REPORTABLE;
		} else {
			return StormStreams.EXCEPTION;
		}
	}

	public void process(Tuple input) {
		System.out.println("Rule Graph Executing For: "+this.ruleGraphName+":"+this.getClass().getSimpleName());

		long ruleGraphLastLoadTimeInCache = rulesClient.getLastLoadTime(ruleGraphName);
		if(ruleGraphLastLoadTimeInCache == 0 || ruleGraphCurrentLoadTime < ruleGraphLastLoadTimeInCache){
			loadRuleGraph();
		}
		
		Entity message = (Entity) input.getValueByField("message");
		LOG.info("Rule Graph Executing For: "+this.ruleGraphName+":"+message.regHubId);	

		RuleGraphResult result = ruleGraph.execute(message, new HashMap<>(),forceRefreshCache);
		forceRefreshCache = false;

		message.status = result.status;
		message.reasonCodes.addAll(result.resultCodes);
		
		Audit audit = message.toAudit();
		ruleGraph.toAudit(audit);
		result.toAudit(audit);
		
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		
		String emitStream =getStreamIdByEntityStatus(message.status);
				
		_collector.emit(emitStream, new Values(message.regHubId, message));
		_collector.ack(input);		
	}

	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.NON_REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.DOMAIN_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.DOMAIN);
		return exceptionTags;
	}

}
