package com.citi.reghub.core.rio.spouts;

import java.time.Clock;
import java.time.LocalDateTime;

public final class M2ReghubIdGeneratorUtil {
	
	public static String getCurrentDateFormated() {
		LocalDateTime localDateTime = LocalDateTime.now();
		Long epochSec = localDateTime.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
		Integer nanos = localDateTime.getNano();
		Long dateToBeStoredInMongoDB = (epochSec * 1000000000) + nanos;
		return Long.toString(dateToBeStoredInMongoDB);
	}

}
