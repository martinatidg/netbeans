package com.citi.reghub.core.rio.spouts;

import org.apache.commons.lang3.StringUtils;

import com.citi.reghub.core.constants.M2ReghubIdGeneratorConstants;

public class M2ReghubIdGeneratorFactory {
	
	public static M2ReghubIdGenerator getM2ReghubIdGenerator(String messageType){
		if(StringUtils.equalsIgnoreCase(M2ReghubIdGeneratorConstants.M2_CITIML_MESSAGE, messageType)){
			return new M2CitimlReghubIdGenerator();
		}else if(StringUtils.equalsIgnoreCase(M2ReghubIdGeneratorConstants.M2_CITIFIX_MESSAGE, messageType)){
			return new M2CitifixReghubIdGenerator();
		}else{
			return new M2DefaultReghubIdGenerator();
		}
	}

}
