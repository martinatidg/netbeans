package com.citi.reghub.core.rio.spouts;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.citi.reghub.core.constants.M2ReghubIdGeneratorConstants;

public class M2CitimlReghubIdGenerator implements M2ReghubIdGenerator {

private static List<Pattern>  patterns = new ArrayList<>();
	
	static {
		patterns.add(Pattern.compile(M2ReghubIdGeneratorConstants.M2_REGHUBID_CITIML_PATTERN));
		patterns.add(Pattern.compile(M2ReghubIdGeneratorConstants.M2_REGHUBID_CITIML_PATTERN_FIRST_LINEBREAK));
	}

	@Override
	public String generateReghubId(String stream, String flow, String messagePayload) {
		String reghubId = null;
		if (StringUtils.isNotEmpty(stream) && StringUtils.isNotEmpty(flow)) {
			if (StringUtils.isNotEmpty(messagePayload)) {
				StringBuilder reghubIdBuilder = new StringBuilder();
				reghubIdBuilder.append(stream);
				reghubIdBuilder.append(M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR);
				reghubIdBuilder.append(flow);
				reghubIdBuilder.append(M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR);
				String messageId = retriveMessageIdFromCitiml(messagePayload);
				if (!StringUtils.isEmpty(messageId)) {
					reghubIdBuilder.append(messageId);
					reghubIdBuilder.append(M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR);
					reghubIdBuilder.append(M2ReghubIdGeneratorUtil.getCurrentDateFormated());
					reghubId = reghubIdBuilder.toString();
				}
				else{
					//when pattern not found in reghub known message pattern
					reghubId = regHubGenericId(stream, flow);
				}
			} else {
				reghubId = regHubGenericId(stream, flow);
			}

		}
		return reghubId.replaceAll(" ", "");
	}

	protected String retriveMessageIdFromCitiml(String messagePayload) {
		String id = null;
		
		for(Pattern pattern :patterns){
			Matcher m = pattern.matcher(messagePayload);
			id = findID(m);
			if(id != null) break;
		}
				
		return id;
	}
	
	protected String findID(Matcher m) {
		String id = null;
		while (m.find()) {
			id = m.group(1);
		}
		return id;
	}
	
	protected String regHubGenericId(String stream, String flow){
		return stream + M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + flow
				+ M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + UUID.randomUUID();
	}

}
