package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.StormConstants;
import com.citigroup.get.quantum.intf.MessageFactory;
import com.citigroup.get.zcc.intf.MOTradeMessage;
import com.citigroup.get.zcc.intf.MessageFactoryImpl;

public class CitifixParserBolt extends RegHubBolt {

	private static final long serialVersionUID = 1L;

	private OutputCollector collector = null;

	private MessageFactory msgFactory = null;
	

	private static final Logger LOG = LoggerFactory.getLogger(CitifixParserBolt.class);

	@SuppressWarnings("rawtypes")
	@Override
	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		msgFactory = MessageFactoryImpl.getInstance();
		collector = outputCollector;
	};

	public void process(Tuple tuple) {
		String reghubId = (String) tuple.getValueByField("key");
		
		RawMsgObject rawMsgObject = (RawMsgObject) tuple.getValueByField("message");
		String citifixString = rawMsgObject.getMessage();
		
		LOG.info("citifix message is : " + citifixString);
		MOTradeMessage parsedMsg = (MOTradeMessage) msgFactory.getMessage(citifixString);
		if (parsedMsg == null)
			throw new RuntimeException("Parsed Message is null for the message : " + citifixString);
		collector.emit(StormStreams.SOURCE,new Values(reghubId, parsedMsg));
		collector.ack(tuple);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.SOURCE,new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.AUDIT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.PARSE_EXCEPTION);
		return exceptionTags;
	}
}