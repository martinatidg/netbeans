package com.citi.reghub.core;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.enrichment.client.EnrichmentClientConfig;
import com.citi.reghub.core.enrichment.client.SingletonEnrichmentClient;
import com.citi.reghub.core.entity.client.EntityClientConfig;
import com.citi.reghub.core.entity.client.SingletonEntityClient;
import com.citi.reghub.core.hrmstrader.client.HrmsTraderClientConfig;
import com.citi.reghub.core.hrmstrader.client.SingletonHrmsTraderClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;
import com.citi.reghub.core.refdata.client.SingletonRefdataClient;
import com.citi.reghub.core.rules.client.RulesClientConfig;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

public abstract class RegHubBolt extends BaseRichBolt {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(RegHubBolt.class);
	public static final String TUPLE_KEY = "key";
	public static final String TUPLE_MESSAGE = "message";

	protected String stream;

	protected String flow;

	/**
	 * Contains the bolt execute logic
	 * 
	 * @throws Exception
	 */
	public abstract void process(Tuple input) throws Exception; // process()

	/**
	 * Should be overriden in place of declareOutputFields method of Bolt
	 */
	public abstract void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer);

	/**
	 * Should be overriden in child class to return child class's collector
	 */
	public abstract OutputCollector getCollector();

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		Map topologyConfig = (Map) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		if(topologyConfig != null){
			stream = (String) topologyConfig.get(GlobalProperties.TOPOLOGY_STREAM_NAME);
			flow = (String) topologyConfig.get(GlobalProperties.TOPOLOGY_FLOW_NAME);
		}
		prepareBolt(stormConf, context, collector);
	}

	public abstract void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector);

	public void execute(Tuple input) {
		try {
			process(input);
		} catch (Throwable t) {
			getCollector().ack(input);
			LOGGER.error("Error occured while tupple processing for tuple  {}  exception {}", input, t);
			Entity entity = createExceptionEntity(input);
			Audit audit = createAudit(entity, t);
			getCollector().emit(StormStreams.EXCEPTION, new Values(entity.regHubId, entity));
			getCollector().emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		}
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declareBoltSpecificOutFields(declarer);
	}

	public Audit createAudit(Entity message, Throwable throwable) {
		Audit audit = message.toAudit();
		audit.event = getAuditExceptionEvent();
		audit.result = StormConstants.ERROR;
		audit.tags.add(StormConstants.EXCEPTIONS);
		List<String> exceptionTags = getAuditExceptionsTags();
		if (exceptionTags != null)
			exceptionTags.forEach(tag -> audit.tags.add(tag));
		audit.info.put(StormConstants.MESSAGE, throwable.getClass().getName());
		audit.info.put(StormConstants.STACKTRACE, getStacktraceAsString(throwable));
		return audit;
	}

	public abstract String getAuditExceptionEvent();

	public abstract List<String> getAuditExceptionsTags();

	public Entity createExceptionEntity(Tuple input) {
		String reghubId = (String) input.getValueByField(TUPLE_KEY);
		Object message = input.getValueByField(TUPLE_MESSAGE);
		Entity entity = null;
		if (message instanceof Entity) {
			entity = (Entity) message;
		} else {
			entity = new Entity();
			entity.regHubId = reghubId;
			entity.stream = stream;
			entity.flow = flow;
		}
		entity.status = EntityStatus.APP_EXCEPTION;
		return entity;
	}

	protected String getStacktraceAsString(Throwable throwable){
		StringWriter stringWriter = new StringWriter();
		throwable.printStackTrace(new PrintWriter(stringWriter));
		return stringWriter.toString();
	}

	protected void setCacheClient(Map<String, String> topologyConfig) {
		SingletonCacheClient.setInstance(topologyConfig);
	}

	protected void setRuleClient(Map<String, String> topologyConfig) {
		RulesClientConfig config = new RulesClientConfig();
		config.put(RulesClientConfig.RULE_GRAPH_URL_KEY, topologyConfig.get(GlobalProperties.RULE_GRAPH_SERVICE_URL));
		config.put(RulesClientConfig.REST_CLIENT, new RestClient(createDefault()));
		config.put(RulesClientConfig.CACHE_CLIENT, SingletonCacheClient.getInstance());
		SingletonRulesClient.setInstance(config);
	}

	protected HttpClient createDefault() {
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		CloseableHttpClient client = builder.build();
		return client;
	}

	protected void setMetadataClient(Map<String, String> topologyConfig) {
		MetadataClientConfig metaConfig = new MetadataClientConfig();
		metaConfig.put(MetadataClientConfig.METADATA_URL_KEY, topologyConfig.get(GlobalProperties.METADTA_SERVICE_URL));
		metaConfig.put(MetadataClientConfig.REST_CLIENT, new RestClient(createDefault()));
		metaConfig.put(MetadataClientConfig.CACHE_CLIENT, SingletonCacheClient.getInstance());
		metaConfig.put(MetadataClientConfig.STREAM_CODE, topologyConfig.get(GlobalProperties.TOPOLOGY_STREAM_NAME));
		metaConfig.put(MetadataClientConfig.FLOW_CODE, topologyConfig.get(GlobalProperties.TOPOLOGY_FLOW_NAME));
		SingletonMetadataClient.setInstance(metaConfig);
	}

	protected void setRefdataClient(Map<String, String> topologyConfig) {
		SingletonRefdataClient.setInstance(topologyConfig);
	}

	protected void setHrmsTraderClient(Map<String, String> topologyConfig) {
		HrmsTraderClientConfig hrmsTraderClientConfig = new HrmsTraderClientConfig();
		hrmsTraderClientConfig.set(HrmsTraderClientConfig.REST_CLIENT, new RestClient(createDefault()));
		hrmsTraderClientConfig.set(HrmsTraderClientConfig.CACHE_CLIENT, SingletonCacheClient.getInstance());
		hrmsTraderClientConfig.set(HrmsTraderClientConfig.HRMSTRADER_URL_KEY,
				topologyConfig.get(GlobalProperties.HRMS_TRADER_SERVICE_URL));
		hrmsTraderClientConfig.set(HrmsTraderClientConfig.TRADER_INFO_SERVICE_URI, "trader");
		SingletonHrmsTraderClient.setInstance(hrmsTraderClientConfig);
	}

	protected void setEnrichmentClient(Map<String, String> topologyConfig) {
		EnrichmentClientConfig enrichmentConfig = new EnrichmentClientConfig();
		enrichmentConfig.put(EnrichmentClientConfig.REST_CLIENT, new RestClient(createDefault()));
		enrichmentConfig.put(EnrichmentClientConfig.ENRICHMENT_PLAN_SERVICE_URL,
				topologyConfig.get(GlobalProperties.ENRICHMENT_SERVICE_URL));
		enrichmentConfig.put(EnrichmentClientConfig.METADATA_CLIENT, SingletonMetadataClient.getInstance());
		enrichmentConfig.put(EnrichmentClientConfig.REFDATA_CLIENT, SingletonRefdataClient.getInstance());
		enrichmentConfig.put(EnrichmentClientConfig.HRMS_TRADER_CLIENT, SingletonHrmsTraderClient.getInstance());
		enrichmentConfig.put(EnrichmentClientConfig.CACHE_CLIENT, SingletonCacheClient.getInstance());
		SingletonEnrichmentClient.setInstance(enrichmentConfig);
	}

	protected void setEntityClient(Map<String, String> topologyConfig) {
		EntityClientConfig entityConfig = new EntityClientConfig();
		entityConfig.put(EntityClientConfig.ENTITY_URL_KEY,
				topologyConfig.get(GlobalProperties.OVEERRIDEEN_ENTITY_SERVICE_URL));
		entityConfig.put(EntityClientConfig.REST_CLIENT, new RestClient(createDefault()));
		SingletonEntityClient.setInstance(entityConfig);
	}
}
