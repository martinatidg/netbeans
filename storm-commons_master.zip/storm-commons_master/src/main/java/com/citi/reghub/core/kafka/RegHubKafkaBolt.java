package com.citi.reghub.core.kafka;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.Validate;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.storm.kafka.bolt.KafkaBolt;
import org.apache.storm.kafka.bolt.mapper.FieldNameBasedTupleToKafkaMapper;
import org.apache.storm.kafka.bolt.mapper.TupleToKafkaMapper;
import org.apache.storm.kafka.bolt.selector.DefaultTopicSelector;

public class RegHubKafkaBolt implements Serializable{

	private static final long serialVersionUID = 1L;
	public static final String ERROR_MESSAGE = "Please provide kafka connection details.";
	public static final TupleToKafkaMapper<Object, Object> defaultMapper = new FieldNameBasedTupleToKafkaMapper<>();
	
	private String topicName;
	private String producerName;
	private Map<String, String> config;
	
	public RegHubKafkaBolt(Map<String, String> config, String topicName, String producerName) {
		this.config = config;
		this.topicName = topicName;
		this.producerName = producerName;
	}

	public static KafkaBolt<Object, Object> getKafkaBolt(Map<String, String> config, String topicName, String producerName) {
		return new RegHubKafkaBolt(config, topicName, producerName).getBolt();
	}
	
	private KafkaBolt<Object, Object> getBolt() {
		Properties producerProps = KafkaPropertiesFactory.getKafkaProducerProps(config, producerName);
		Validate.notNull(producerProps.get(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG), ERROR_MESSAGE);
		Validate.notNull(producerProps.get(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG), ERROR_MESSAGE);
		Validate.notNull(producerProps.get(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG), ERROR_MESSAGE);
		
		return new KafkaBolt<>()
			.withProducerProperties(producerProps)
			.withTopicSelector(new DefaultTopicSelector(topicName))
			.withTupleToKafkaMapper(defaultMapper);
	}

}