package com.citi.reghub.core.properties;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.citi.reghub.core.PropertiesLoader;

/**
 * Abstract class to load the mapping value from the property file
 * 
 * @author sk86139
 *
 */
public abstract class AbstractFileMapProperties implements Serializable {

	private static final long serialVersionUID = -7374815700333405487L;

	public Map<String, String> getHeaderMap() {
		return headerMap;
	}

	public Map<String, String> getMapInversed() {
		return mapInversed;
	}

	private Map<String, String> headerMap;

	private Map<String, String> mapInversed;

	public AbstractFileMapProperties(String fileName) {

		PropertiesLoader PropertiesLoader = new PropertiesLoader();
		headerMap = new HashMap<String, String>((Map) PropertiesLoader.loadProperties(fileName));
		mapInversed = headerMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));
	}
}
