package com.citi.reghub.core.rio.spouts;

public interface M2ReghubIdGenerator {
	
	String generateReghubId(String stream,String flow,String messagePayload);

}
