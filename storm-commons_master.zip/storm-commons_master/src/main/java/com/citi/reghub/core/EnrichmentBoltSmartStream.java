package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.enrichment.client.EnrichmentClient;
import com.citi.reghub.core.enrichment.client.EnrichmentPlan;
import com.citi.reghub.core.enrichment.client.EnrichmentResult;
import com.citi.reghub.core.enrichment.client.SingletonEnrichmentClient;


public class EnrichmentBoltSmartStream extends RegHubBolt {

	protected static final Logger LOG = LoggerFactory.getLogger(EnrichmentBoltSmartStream.class);
	private static final long serialVersionUID = 1L;
	
	private   OutputCollector _collector;
	private   EnrichmentResult enrichmentResult;
	public    EnrichmentClient enrichmentClient;
	protected String enrichmentPlanBaseName;
	
	private Map<String, EnrichmentPlan> enrichmentPlans = new HashMap<String, EnrichmentPlan>();
	private Map<String, Long> enrichmentPlanCurrentLoadTimes = new HashMap<String, Long>();
	
	protected boolean forceRefreshCache;

	public EnrichmentBoltSmartStream(String enrichmentPlanName){
		this.enrichmentPlanBaseName = enrichmentPlanName;
	}
	
	public String getEnrichmentPlanName() {
		return this.enrichmentPlanBaseName;
	}
	
	protected void loadEnrichmentPlan(String enrichmentPlanName){
		enrichmentPlans.put(enrichmentPlanName,enrichmentClient.getFromService(enrichmentPlanName));
		enrichmentPlanCurrentLoadTimes.put(enrichmentPlanName, enrichmentClient.getLastLoadTime(enrichmentPlanName));
		forceRefreshCache = true;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		setCacheClient(topologyConfig);
		setRuleClient(topologyConfig);
		setMetadataClient(topologyConfig);
		setRefdataClient(topologyConfig);
		setHrmsTraderClient(topologyConfig);
		setEnrichmentClient(topologyConfig);
		if(enrichmentClient == null) {
			enrichmentClient = SingletonEnrichmentClient.getInstance();
		}
	}

	@Override
	public void process(Tuple input) {
		Entity message = (Entity) input.getValueByField("message");
		String enrichmentPlanName = getEnrichmentPlanName(message);
		
		long enrichmentPlanLastLoadTimeInCache = enrichmentClient.getLastLoadTime(enrichmentPlanName);
		if(enrichmentPlanLastLoadTimeInCache == 0 || getEnrichmentPlanCurrentLoadTime(enrichmentPlanName) < enrichmentPlanLastLoadTimeInCache){
			loadEnrichmentPlan(enrichmentPlanName);
		}
	
		EnrichmentPlan enrichmentPlan = enrichmentPlans.get(enrichmentPlanName);
		
		enrichmentResult = enrichmentClient.execute(message,forceRefreshCache,enrichmentPlan);
		forceRefreshCache = false;
		Audit audit = message.toAudit();
		enrichmentPlan.toAudit(audit);
		enrichmentResult.toAudit(audit);
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		_collector.emit(StormStreams.REPORTABLE, new Values(message.regHubId, message));
		_collector.ack(input);		
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.DOMAIN_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.DOMAIN);
		return exceptionTags;
	}
	
	private String  getEnrichmentPlanName(Entity entity)
	{
		return entity.stream+"_"+entity.flow+"_"+enrichmentPlanBaseName;
	}
	
	private long  getEnrichmentPlanCurrentLoadTime(String enrichmentPlanName )
	{
		return enrichmentPlanCurrentLoadTimes.getOrDefault(enrichmentPlanName, 0l) ;
	}
	
	
}
