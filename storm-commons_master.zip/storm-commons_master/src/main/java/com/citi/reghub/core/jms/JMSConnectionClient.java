package com.citi.reghub.core.jms;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

/**
 * JMSConnectionClient for interaction with Middle ware System for sending Fix message to tradeEcho
 * 
 *
 */
public class JMSConnectionClient implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8055624586639876364L;

	public static final Logger LOGGER = LoggerFactory.getLogger(JMSConnectionClient.class);

	private   Map<String, String> config =null;
	private Properties env = null;
	private TopicConnection topicConnection;
	private Topic topic;
	private String factoryName=TibjmsInitialContextFactory.class.getName();
	private String prefix = null;
	private TopicSession topicSession = null;
	private TopicPublisher publisher = null;
	private TextMessage message;
	
	@SuppressWarnings("unused")
	private JMSConnectionClient() {}
	
	public JMSConnectionClient(Map<String, String> config) {
		this.config = config;
	}
	
	public JMSConnectionClient(Map<String, String> config, String prefix) {
		this.config = config;
		this.prefix = prefix;
	}

	/**
	 * Initializing JMSConnection.
	 * Required config parameter will be passed to Constructor
	 * Same config will be used to initialize JMS and JNDI	
	 * @throws Exception
	 */
	public void initConnection() throws JMSException{
		
		initJMS();
		
		openConnection();
	}
	

	/**
	 * Initializing JMS connection  
	 * 
	 */
	private void initJMS() {
		env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		env.put(Context.PROVIDER_URL, getConfiguration(GlobalProperties.APA_PROVIDER_URL));
		env.put(Context.SECURITY_PRINCIPAL, getConfiguration(GlobalProperties.APA_USERNAME));
		env.put(Context.SECURITY_CREDENTIALS, getConfiguration(GlobalProperties.APA_PWD_KEY));
	}
	
	/**
	 * 
	 * @param text Fix Messeage to be sent to Middleware 
	 * @throws JMSException
	 */
	public void sendMessage(String text)  throws JMSException{

	
		
		if(StringUtils.isEmpty(text)){
			LOGGER.error("Message to be sent cannot be null");
			throw new JMSException("Message to be sent cannot be null");
		}
		
		try {
			
			message.setText(text);
			publisher.publish(message);
			
			
		} catch (JMSException e) {
			LOGGER.error("Issue occured while sending message to Middleware {}", e.getMessage());
			throw e;
		}
	
	}

	
	/**
	 * Opening connection with JMS setting up ENV properties.
	 * 
	 * @throws Exception
	 */
	private void openConnection() throws JMSException {

		try {

			InitialContext jndi = new InitialContext(env);
			TopicConnectionFactory conFactory = (TopicConnectionFactory) jndi.lookup(getConfiguration(GlobalProperties.APA_JNDI_NAME));
			// Create a JMS connection
			topicConnection = conFactory.createTopicConnection(getConfiguration(GlobalProperties.APA_USERNAME), getConfiguration(GlobalProperties.APA_PWD_KEY));
			// Look up a JMS topic
			topic = (Topic) jndi.lookup(getConfiguration(GlobalProperties.APA_TOPIC_NAME));
			topicConnection.start();
			topicSession = topicConnection.createTopicSession(false,Session.AUTO_ACKNOWLEDGE);
			publisher = topicSession.createPublisher(topic);
			message = topicSession.createTextMessage();
			
		}
		catch (Exception e) {
			LOGGER.error("Issue occured while opening connection with Middleware {}", e.getMessage());
			throw new JMSException(e.getMessage());
		}
	}
	
	public void close() throws JMSException{
		publisher.close();
		topicSession.close();
	}

	/**
	 * @return
	 */
	public Map<String, String> getConfig() {
		return config;
	}
	
	private String getConfiguration(String configKey) {
		return config.get(getConfigurationKey(configKey));
	}
	
	private String getConfigurationKey(String configKey) {
		return prefix == null ? configKey : prefix + "." + configKey;
	}

	
}