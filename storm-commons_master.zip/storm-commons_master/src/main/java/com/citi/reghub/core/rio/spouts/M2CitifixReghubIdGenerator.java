package com.citi.reghub.core.rio.spouts;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.citi.reghub.core.constants.M2ReghubIdGeneratorConstants;

public class M2CitifixReghubIdGenerator implements M2ReghubIdGenerator{

	@Override
	public String generateReghubId(String stream, String flow, String messagePayload) {
		String reghubId = null;
		if (StringUtils.isNotEmpty(stream) && StringUtils.isNotEmpty(flow)) {
			if (StringUtils.isNotEmpty(messagePayload)) {
				StringBuilder reghubIdBuilder = new StringBuilder();
				reghubIdBuilder.append(stream);
				reghubIdBuilder.append(M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR);
				reghubIdBuilder.append(flow);
				reghubIdBuilder.append(M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR);
				String messageId = retrieveMessageIdFromCitifix(messagePayload);
				if (!StringUtils.isEmpty(messageId)) {
					reghubIdBuilder.append(messageId);
					reghubIdBuilder.append(M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR);
					reghubIdBuilder.append(M2ReghubIdGeneratorUtil.getCurrentDateFormated());
					reghubId = reghubIdBuilder.toString();
				}
				else{
					reghubId = regHubGenericId(stream, flow);
				}
			} else {
				reghubId = regHubGenericId(stream, flow);
			}

		}
		return reghubId;
	}

	protected String retrieveMessageIdFromCitifix(String messagePayload) {
		String id = null;
		String messageType = retriveFixMessageType(messagePayload);
		if (StringUtils.isNotEmpty(messageType)
				&& M2ReghubIdGeneratorConstants.M2_CITIFIX_RIO_MESSAGE_Type.equalsIgnoreCase(messageType)) {
			id = retrieveMessageIdForRioType(messagePayload);
		} else if (StringUtils.isNotEmpty(messageType)
				&& M2ReghubIdGeneratorConstants.M2_CITIFIX_URT_MESSAGE_Type.equalsIgnoreCase(messageType)) {
			id = retrieveMessageIdForURTType(messagePayload);
		} else if (StringUtils.isNotEmpty(messageType)
				&& M2ReghubIdGeneratorConstants.M2_CITIFIX_RFQ_MESSAGE_Type.equalsIgnoreCase(messageType)) {
			id = retrieveMessageIdForRFQType(messagePayload);
		}
		return id;
	}
	
	protected String retrieveMessageIdForRioType(String messagePayload) {
		String id = null;
		Matcher m = Pattern.compile(M2ReghubIdGeneratorConstants.M2_REGHUBID_CITIFIX_RIO_PATTERN)
				.matcher(messagePayload);
		while (m.find()) {
			id = m.group(1);
		}
		return id;
	}

	protected String retrieveMessageIdForURTType(String messagePayload) {
		String id = null;
		Matcher m = Pattern.compile(M2ReghubIdGeneratorConstants.M2_REGHUBID_CITIFIX_URT_PATTERN)
				.matcher(messagePayload);
		while (m.find()) {
			id = m.group(1);
		}
		return id;
	}
	
	protected String retrieveMessageIdForRFQType(String messagePayload) {
		String id = null;
		Matcher m = Pattern.compile(M2ReghubIdGeneratorConstants.M2_REGHUBID_CITIFIX_RFQ_PATTERN)
				.matcher(messagePayload);
		while (m.find()) {
			id = m.group(1);
		}
		return id;
	}
	
	
	protected String retriveFixMessageType(String messagePayload) {
		String messageType = null;
		Matcher m = Pattern.compile(M2ReghubIdGeneratorConstants.M2_CITIFIX_MESSAGE_TYPE_PATTERN)
				.matcher(messagePayload);
		while (m.find()) {
			messageType = m.group(1);
		}
		return messageType;
	}
	
	protected String regHubGenericId(String stream, String flow){
		return stream + M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + flow
				+ M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + UUID.randomUUID();
	}
	
}
