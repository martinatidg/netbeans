
package com.citi.reghub.core.mongo;

import static com.mongodb.client.model.Filters.eq;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.Validate;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.ConvertToMongoMap;
import com.citi.reghub.core.constants.GlobalProperties;
import com.mongodb.ErrorCategory;
import com.mongodb.MongoTimeoutException;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.UpdateOptions;

/**
 * Basic bolt for updating from MongoDB.
 *
 * Note: Each MongoUpdateBolt defined in a topology is tied to a specific
 * collection.
 *
 */
public class MongoDBUpdateBolt<T> extends BaseRichBolt {

	private static final Logger LOG = LoggerFactory.getLogger(MongoDBUpdateBolt.class);
	private static final long serialVersionUID = 1L;
	private OutputCollector collector;

	private String collectionName;
	private RegHubMongoClient mongoClient;
	private ConvertToMongoMap<T> toMongoMap;
	private MongoCollection<Document> collection;
	private Boolean isUpsert;

	public MongoDBUpdateBolt(String collectionName, ConvertToMongoMap toMongoMap) {
		this.collectionName = collectionName;
		this.toMongoMap = toMongoMap;
		this.isUpsert = false;
	}

	public MongoDBUpdateBolt(String collectionName, ConvertToMongoMap toMongoMap, Boolean isUpsert) {
		this.collectionName = collectionName;
		this.toMongoMap = toMongoMap;
		this.isUpsert = isUpsert;
	}

	@Override
	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		Validate.notEmpty((String) topologyConfig.get(GlobalProperties.MONGO_URL), "url can not be blank or null");
		String url = topologyConfig.get(GlobalProperties.MONGO_URL);
		String password = topologyConfig.get(GlobalProperties.MONGO_PASSWORD);
		String trustStore = topologyConfig.get(GlobalProperties.MONGO_TRUSTSTORE);
		String trustStorePassword = topologyConfig.get(GlobalProperties.MONGO_TRUSTSTORE_PASSWORD);
		String decryptKey = topologyConfig.get(GlobalProperties.DECRYPT_KEY);

		if (password != null) {
			Map<String, Object> mongoProps = new HashMap<>();
			mongoProps.put(RegHubMongoClient.CONNECTION_URL, url);
			mongoProps.put(RegHubMongoClient.PASSWORD, password);
			mongoProps.put(RegHubMongoClient.TRUSTSTORE, trustStore);
			mongoProps.put(RegHubMongoClient.TRUSTSTORE_PASSWORD, trustStorePassword);
			mongoProps.put(RegHubMongoClient.DECRYPT_KEY, decryptKey);
			this.mongoClient = new RegHubMongoClient(mongoProps);
		} else {
			this.mongoClient = new RegHubMongoClient(url);
		}
		collection = mongoClient.getDatabase().getCollection(collectionName);
	}

	@Override
	public void cleanup() {
		this.mongoClient.close();
	}

	@Override
	public void execute(Tuple tuple) {
		try {
			T message = (T) tuple.getValueByField("message");
			save((Document) toMongoMap.toMap(message));
			this.collector.ack(tuple);
		} 
		catch (MongoWriteException e) {
			if(e.getError().getCategory().equals(ErrorCategory.DUPLICATE_KEY)){
				// do not report error for duplicate key. Log it as warning.
				LOG.warn("Error saving data to mongo: Duplicate Key Exception: ", e);
				this.collector.ack(tuple);
			}
			else{
				LOG.error("Error saving data to mongo", e);
				this.collector.reportError(e);
				this.collector.fail(tuple);
			}
		}
		catch (MongoTimeoutException tme) {
			LOG.error("Error saving data to mongo", tme);
			this.collector.reportError(tme);
			this.collector.fail(tuple);
			throw tme;
		}
		catch (Exception e) {
			LOG.error("Error saving data to mongo", e);
			this.collector.reportError(e);
			this.collector.fail(tuple);
		}
	}

	public void save(Document document) {
		Object id = document.get("_id");
		if (id == null) {
			collection.insertOne(document);
		} else if (!isUpsert) {
			collection.replaceOne(eq("_id", id), document, new UpdateOptions().upsert(true));
		} else {
			collection.updateOne(eq("_id", id), new Document("$set", document), new UpdateOptions().upsert(true));
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		/**
		 * No output fields, as we are sending data to mongodb
		 */
	}
	
	

}
