package com.citi.reghub.core;

import static com.citi.reghub.core.constants.FlatFileConstants.FLATFILE_HEADER;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.M2ReghubIdGeneratorConstants;
import com.citi.reghub.core.properties.AbstractFileMapProperties;

/**
 * This is an abstract for transforming the incoming Raw delimited line to
 * Entity Domain Object. It provide Implementation for the common attributes,
 * specific ones needs to be overridden.
 * 
 * @author sk86139
 */
public abstract class AbstractFlatFileEntityMapper implements EntityMapper {

	private static final long serialVersionUID = 7688521073773686571L;

	protected static final Logger LOG = LoggerFactory.getLogger(AbstractFlatFileEntityMapper.class);

	protected String flow;
	protected String stream;
	protected AbstractFileMapProperties fileMap;
	protected String delimiter;

	/**
	 * Public constructor to set the Flow and Stream
	 * 
	 * @param flow
	 * @param stream
	 */
	public AbstractFlatFileEntityMapper(String flow, String stream) {
		this.flow = flow;
		this.stream = stream;
	}

	@Override
	public Entity mapToEntity(Object message, Entity entity) {
		if (message instanceof RawLineMsgObject) {
			RawLineMsgObject rawLineMsgObject = (RawLineMsgObject) message;
			populateMandatoryEntityAttributes(rawLineMsgObject, entity);
			Map<String, String> mappedValue = parse(rawLineMsgObject);

			mappedValue.entrySet().stream()
					.filter(rawEntity -> fileMap.getHeaderMap().values().contains(rawEntity.getKey()))
					.forEach(refinedEntity -> entity.info.put(fileMap.getMapInversed().get(refinedEntity.getKey()),
							refinedEntity.getValue()));
			applyFilters(entity);
		} else {
			throw new InvalidInputException(" Object to map is not of RawLineMsgObject type");
		}

		return entity;
	}

	private Map<String, String> parse(RawLineMsgObject rawLineMsgObject) {
		String[] headerOrderedList = ((String) rawLineMsgObject.get(FLATFILE_HEADER)).split(delimiter);
		String[] valueOrderedList = new String(Base64.getDecoder().decode(rawLineMsgObject.getMessage()))
				.split(delimiter);
		
		if(headerOrderedList.length < valueOrderedList.length)
		{
			throw new InvalidInputException(" Value does not match the header");
		}
		
		return new HashMap<String, String>() {
			private static final long serialVersionUID = 6347925400686125024L;

			{
				for (int i = 0; i < valueOrderedList.length; i++) {
					put(headerOrderedList[i], valueOrderedList[i]);
				}
			}
		};
	}

	/**
	 * This method maps basic fields into Entity object
	 * 
	 * @param entity
	 **/
	protected void populateMandatoryEntityAttributes(RawLineMsgObject message, Entity entity) {

		entity.status = EntityStatus.REPORTABLE;
		entity.flow = flow;
		entity.stream = stream;
		entity.receivedTs = LocalDateTime.now(Clock.systemUTC());
		entity.regHubId = stream + M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + flow
				+ M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + message.getSourceUId();

	}
	
	/**
	 * Apply post entity creation filters and enrichment if any
	 * @param entity
	 */
	protected void applyFilters(Entity entity){
		//Do Nothing here, expected for implementers to override and provide the filters if any
	}
}
