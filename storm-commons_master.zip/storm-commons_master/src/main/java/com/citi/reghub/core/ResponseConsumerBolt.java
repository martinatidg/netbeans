package com.citi.reghub.core;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.client.SingletonRestClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.metadata.client.MetadataClient;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;
import com.citi.reghub.core.response.handler.NoDefinedProcessorException;
import com.citi.reghub.core.response.handler.ParsedResponseBundle;
import com.citi.reghub.core.response.handler.ResponseMessageController;
import com.citi.reghub.core.response.handler.ResponseMessageProcessor;

public class ResponseConsumerBolt extends RegHubBolt {

	private static final String MAP = "Map";
	private static final String ENTITIES_CACHE = "m2post_entities_cache_collection";
	private static final long serialVersionUID = 1L;
	protected static final Logger LOG = LoggerFactory.getLogger(ResponseConsumerBolt.class);

	public RestClient restClient;
	public String rawOutboundServiceUrl;
	public String rawOutboundServiceSeqUrl;
	public String rawOutboundServiceRegHubIdUrl;
	public String entityServiceUrl;
	public OutputCollector _collector;
	public ResponseMessageController controller;
	private Map<String, String> cacheEntityConfig; 
	public CacheClient cacheClient;
	public Map<String, String> cacheConfig;
	public ResponseMessageProcessor report;

	public ResponseConsumerBolt(ResponseMessageController controller) {
		this.controller = controller;
	}

	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		restClient = SingletonRestClient.getInstance();

		Map topologyConfig = (Map) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		rawOutboundServiceUrl = (String) topologyConfig.get(GlobalProperties.RAW_OUTBOUND_SERVICE_URL);
		rawOutboundServiceSeqUrl = (String) topologyConfig.get(GlobalProperties.RAW_OUTBOUND_SERVICE_SEQ_URL);
		rawOutboundServiceRegHubIdUrl = (String) topologyConfig.get(GlobalProperties.RAW_OUTBOUND_SERVICE_REG_HUB_ID_URL);
		entityServiceUrl = (String) topologyConfig.get(GlobalProperties.ENTITY_SERVICE_URL);
		setCacheClient(topologyConfig);
		setMetadataClient(topologyConfig);
		
		cacheEntityConfig = getMapInstance();
		cacheEntityConfig.put(CacheClient.CACHE_COLLECTION_NAME, ENTITIES_CACHE);
		cacheEntityConfig.put(CacheClient.CACHE_COLLECTION_TYPE, MAP);
		
		cacheConfig = getMapInstance();
		cacheConfig.put(CacheClient.CACHE_COLLECTION_TYPE, MAP);
		cacheClient = getCacheInstance();
	}

	protected CacheClient getCacheInstance() {
		return SingletonCacheClient.getInstance();
	}

	public HashMap<String, String> getMapInstance() {
		return new HashMap<>();
	}

	protected MetadataClient getMetadataClient() {
		return SingletonMetadataClient.getInstance();
	}

	@Override
	public void process(Tuple input) throws Exception {
		String message = (String) input.getValueByField("message");

		// TODO: Below getParserMethod should be changed
		// ParsedResponse parsedResponse =
		// this.controller.getParser().convert(message);
		ParsedResponse parsedResponse = this.controller.getParser(message).parseMessage(message);

		// STEP 1 - Get the raw-outbound-record
		RawOutboundRecord rawRecord = null;
		List<RawOutboundRecord> rawRecords = null;
		try {
			if (null != parsedResponse.regHubId) {
				rawRecords = restClient.getValues(MessageFormat.format(rawOutboundServiceRegHubIdUrl, parsedResponse.regHubId), RawOutboundRecord.class);
				if (null != rawRecords && !rawRecords.isEmpty()) {
					rawRecord = rawRecords.get(0);
				}
			} else if (parsedResponse.regReportingRef != null) {
				rawRecord = restClient.get(MessageFormat.format(rawOutboundServiceUrl, parsedResponse.regReportingRef, parsedResponse.stream, parsedResponse.flow), RawOutboundRecord.class);
			} else {
				rawRecord = restClient.get(MessageFormat.format(rawOutboundServiceSeqUrl, parsedResponse.msgSeqNum), RawOutboundRecord.class);
			}
		} catch (Throwable t) {
			// Nothing we can do here.
			LOG.warn("Response Consumer Received Unknown Outbound Record: " + message, t);
			LOG.warn("ParsedResponse", rawRecord);
			_collector.ack(input);
			return;
		}

		// STEP 2 - Get the Entity
		Entity entity = null;
		try {
			entity = restClient.get(
					MessageFormat.format(entityServiceUrl, rawRecord.regHubId, rawRecord.stream, rawRecord.flow),
					Entity.class);
		} catch (Throwable t) {
			LOG.warn("Response Consumer Exception Looking Up Entity for : " + rawRecord.regHubId);

			createAndPublishEntityLookupFailureAudit(rawRecord, t);

			Entity e = createEntityException(input, rawRecord);
			getCollector().emit(StormStreams.EXCEPTION, new Values(e.regHubId, e));

			_collector.ack(input);
			return;
		}

		// STEP 3 - Process the Response
		try {
			String cache_collection_name = entity.stream + "_" + entity.flow + "_" + "response_consumer_cache";
			cacheConfig.putIfAbsent(CacheClient.CACHE_COLLECTION_NAME, cache_collection_name);

			ParsedResponseBundle prb = new ParsedResponseBundle(entity, rawRecord, parsedResponse, message);
			this.controller.process(prb);

			if (null != parsedResponse.sourceId && null != parsedResponse.ackId) {
				cacheClient.put(parsedResponse.sourceId, parsedResponse.ackId, cacheConfig);
				createAndPublishAudit(entity, parsedResponse.ackId);
			} else {

				// push creation of audit (including nack code/reason handling)
				// into MessageController
				// step 1 = get audit (message controller)
				// step 2 = publish (here)
				Audit audit = this.controller.getRejectionAudit(prb, getAuditExceptionEvent(),
						getAuditExceptionsTags());
				_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
			}
			 storeMessageInCaches(entity);
			_collector.emit(StormStreams.PARTIAL_UPDATE, new Values(entity.regHubId, entity));
		} catch (NoDefinedProcessorException ndp) {
			rawRecord.responseMessage = new String(Base64.getEncoder().encode(message.getBytes()));
			rawRecord.responseTs = LocalDateTime.now(Clock.systemUTC());
		}

		_collector.emit(StormStreams.PARTIAL_RAW_OUTBOUND_OBJECT, new Values(rawRecord._id, rawRecord));
		_collector.ack(input);
	}

	private void createAndPublishEntityLookupFailureAudit(RawOutboundRecord rawRecord, Throwable t) {
		Audit audit = new Audit();
		audit.event = getAuditExceptionEvent();
		audit.result = StormConstants.ERROR;
		audit.tags.add(StormConstants.EXCEPTIONS);

		audit.regHubId = rawRecord.regHubId;
		audit.flow = rawRecord.flow;
		audit.stream = rawRecord.stream;

		List<String> exceptionTags = getAuditExceptionsTags();
		if (exceptionTags != null) {
			exceptionTags.forEach(tag -> audit.tags.add(tag));
		}

		audit.info.put("rawrecord", rawRecord.toString());
		audit.info.put(StormConstants.MESSAGE, t.getClass().getName());
		audit.info.put(StormConstants.STACKTRACE, getStacktraceAsString(t));

	}

	public void createAndPublishAudit(Entity e, String ackId) {
		Audit audit = new Audit();
		audit.event = StormConstants.RESPONSE_CONSUMER;
		audit.regHubId = e.regHubId;
		audit.flow = e.flow;
		audit.stream = e.stream;
		audit.result = e.status;

		List<String> exceptionTags = getAuditExceptionsTags();
		if (exceptionTags != null) {
			exceptionTags.forEach(tag -> audit.tags.add(tag));
		}

		if (ackId != null) {
			audit.info.put("ackId", ackId);
		}

		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}

	public Entity createEntityException(Tuple input, RawOutboundRecord rawRecord) {
		String reghubId = rawRecord.regHubId;
		Object message = input.getValueByField(TUPLE_MESSAGE);
		Entity entity = null;
		if (message instanceof Entity) {
			entity = (Entity) message;
		} else {
			entity = new Entity();
			entity.regHubId = reghubId;
			entity.stream = rawRecord.stream;
			entity.flow = rawRecord.flow;
			entity.info.put("rawrecord", rawRecord.toString());
		}
		entity.status = EntityStatus.APP_EXCEPTION;
		return entity;
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.PARTIAL_UPDATE, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.PARTIAL_RAW_OUTBOUND_OBJECT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.AUDIT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.RESPONSE_CONSUMER_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.RESPONSE_CONSUMER);
		return exceptionTags;
	}
	
	public void storeMessageInCaches(Entity message){
		LOG.info("Storing message into hazelcast for"+ message.regHubId);
		
		try {
			restoreBigDecimalValuesForStorageRetrievedEntity(message);
			restoreLongToLocalDateTime(message);
			
			cacheClient.put(message.sourceId, message, cacheEntityConfig);
		} catch (Throwable t) {
			LOG.warn("Exception Writing Message to Hazelcast (suppressing) from Sender"+ message.regHubId, t);
		}
	}

	private void restoreLongToLocalDateTime(Entity message) {
		String[] attributeList = {"eventModTs"};
		
		Arrays.stream(attributeList).forEach(attribute -> {
			Object dbValue = message.info.get(attribute);
			if(dbValue instanceof Long) {
				Long dbTime=(Long)dbValue;
				Long timeInMillis = dbTime / 1000000;
				Integer timeInNanos = (int) (dbTime % 1000000000);
				LocalDateTime localDateTime=LocalDateTime.ofInstant(Instant.ofEpochMilli(timeInMillis), Clock.systemUTC().getZone());
				
				message.info.put(attribute, localDateTime.withNano(timeInNanos));
			}
		});
	}
	private void restoreBigDecimalValuesForStorageRetrievedEntity(Entity nexte) {
		
		String[] attributeList = {"tradeQty","receivedTradeQty", "notionalAmount1", "receivedNotionalAmount1",
				"priceMultiplier","underlyingIndex","qtyInMeasurementUnit","yield","lastPx","tradePrice", "receivedTradePrice"};
		
		Arrays.stream(attributeList).forEach(attribute -> {
			Object dbValue = nexte.info.get(attribute);
			if(dbValue instanceof String) {
				if(!StringUtils.equals("PNDG", (String) dbValue)) {
					BigDecimal converted = null;
					try {
						converted = new BigDecimal((String)dbValue);
					} catch (Throwable t) {
						converted = new BigDecimal(0);
					}
					nexte.info.put(attribute, converted);
				}
			}
		});
		
	}
}
