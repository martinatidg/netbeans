package com.citi.reghub.core.jms;

import static com.citi.reghub.core.constants.StormConstants.APA_FACTORY_NAME;
import static com.citi.reghub.core.constants.StormConstants.APA_JNDI_NAME;
import static com.citi.reghub.core.constants.StormConstants.APA_PASSWORD;
import static com.citi.reghub.core.constants.StormConstants.APA_PROVIDER_NAME;
import static com.citi.reghub.core.constants.StormConstants.APA_PROVIDER_PROTOCOL;
import static com.citi.reghub.core.constants.StormConstants.APA_PROVIDER_URL;
import static com.citi.reghub.core.constants.StormConstants.APA_SUBSCRIBER_NAME;
import static com.citi.reghub.core.constants.StormConstants.APA_TOPIC_NAME;
import static com.citi.reghub.core.constants.StormConstants.APA_USERNAME;
import static com.citi.reghub.core.constants.StormConstants.JMS_PROVIDER_TIBCO;
import static com.citi.reghub.core.constants.StormConstants.JMS_PROTOCOL_SSL;
import static com.citi.reghub.core.constants.StormConstants.JMS_PROVIDER_TIBCO_NAMING;
import static com.citi.reghub.core.constants.StormConstants.JMS_MESSAGE_SOURCE_SYSTEM_VERTICAL;
import static com.citi.reghub.core.constants.StormConstants.JMS_MESSAGE_SOURCE_SYSTEM_EXTERNAL;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.storm.kafka.bolt.mapper.FieldNameBasedTupleToKafkaMapper;
import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.rio.spouts.M2ReghubIdGeneratorFactory;
import com.citi.reghub.core.rio.spouts.RioSpout;
import static com.citi.reghub.core.constants.StormConstants.*;
import com.tibco.tibjms.TibjmsSSL;
import com.tibco.tibjms.naming.TibjmsContext;

public class JMSSpout extends BaseRichSpout implements MessageListener, ExceptionListener {

	private static final long serialVersionUID = 1L;
	public TopicSession topicSession;
	public TopicSubscriber subscriber;
	private String topicName;
	public TopicConnection topicConnection;
	public TopicConnectionFactory conFactory;
	public SpoutOutputCollector collector;
	private String userName;
	private String password;
	private String jndiName;
	private String factoryName;
	private String providerUrl;
	private String subscriberName;
	private String providerName;
	private String providerProtocol;
	public LinkedBlockingQueue<TextMessage> queue;
	public ConcurrentHashMap<String, Message> pendingMessages;
	private Properties env = null;
	private String stream;
	private String flow;
	private String messageType;
	private String messageSourceSystem;
	private static final Logger LOG = LoggerFactory.getLogger(RioSpout.class);

	public JMSSpout(Map<String, String> props, String spoutName) {
		super();
		topicName = props.get(spoutName + "." + APA_TOPIC_NAME);
		userName = props.get(spoutName + "." + APA_USERNAME);
		password = props.get(spoutName + "." + APA_PASSWORD);
		jndiName = props.get(spoutName + "." + APA_JNDI_NAME);
		factoryName = props.get(spoutName + "." + APA_FACTORY_NAME);
		providerUrl = props.get(spoutName + "." + APA_PROVIDER_URL);
		subscriberName = props.get(spoutName + "." + APA_SUBSCRIBER_NAME);
		providerName= props.get(spoutName + "." + APA_PROVIDER_NAME);
		providerProtocol= props.get(spoutName + "." + APA_PROVIDER_PROTOCOL);
		stream = props.get(GlobalProperties.TOPOLOGY_STREAM_NAME);
		flow = props.get(GlobalProperties.TOPOLOGY_FLOW_NAME);
		messageType = props.get(GlobalProperties.TOPOLOGY_MESSAGE_TYPE);
		messageSourceSystem = props.get(GlobalProperties.TOPOLOGY_MESSAGE_SOURCE_SYSTEM);
	}

	public JMSSpout() {
		super();
	}

	@Override
	public void open(Map conf, TopologyContext context, SpoutOutputCollector spoutOutputCollector) {
		queue = new LinkedBlockingQueue<>();
		pendingMessages = new ConcurrentHashMap<>();
		collector = spoutOutputCollector;
		initReceiver();
		initJMS();

	}

	@Override
	public void onMessage(Message message) {
		TextMessage textMessage = (TextMessage) message;
		try {
			System.out.println("SPOUT : " + textMessage.getText());
			queue.add(textMessage);
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void nextTuple() {
		synchronized (this) {
			if (!queue.isEmpty()) {
				TextMessage textMessage = queue.poll();
				String messageId;
				try {
					messageId = generateMessageId(messageSourceSystem, textMessage);
					collector.emit(new Values(messageId, textMessage.getText()), messageId);

					pendingMessages.put(messageId, textMessage);
				} catch (JMSException e) {
					LOG.warn("Unable to get  JMSMessageID of Text message : " + textMessage);
				}
			}
		}

	}

	private void initReceiver() {
		try {
			env = new Properties();
			// ... specify the JNDI properties specific to the vendor
			env.put(Context.INITIAL_CONTEXT_FACTORY, factoryName);
			env.put(Context.PROVIDER_URL, providerUrl);
			env.put(Context.SECURITY_PRINCIPAL, userName);
			env.put(Context.SECURITY_CREDENTIALS, password);
			if (StringUtils.isNotEmpty(providerName) && StringUtils.isNotEmpty(providerProtocol)
					&& providerName.equalsIgnoreCase(JMS_PROVIDER_TIBCO)
					&& providerProtocol.equalsIgnoreCase(JMS_PROTOCOL_SSL)) {
				env.put(Context.URL_PKG_PREFIXES, JMS_PROVIDER_TIBCO_NAMING);
				env.put(TibjmsContext.SECURITY_PROTOCOL, JMS_PROTOCOL_SSL);
				env.put(TibjmsContext.SSL_ENABLE_VERIFY_HOST_NAME, false);
				env.put(TibjmsContext.SSL_ENABLE_VERIFY_HOST, false);
				env.put(TibjmsSSL.TRACE, true);
				env.put(TibjmsSSL.DEBUG_TRACE, true);
			}
		} catch (Exception msgExcp) {
			LOG.error("There were problems obtaining a message service provider. Please contact programming staff");
		}

	}

	private void initJMS() {
		try {
			InitialContext jndi = new InitialContext(env);
			conFactory = (TopicConnectionFactory) jndi.lookup(jndiName);
			topicConnection = conFactory.createTopicConnection(env.getProperty(Context.SECURITY_PRINCIPAL),
					env.getProperty(Context.SECURITY_CREDENTIALS));
			// topicConnection.setClientID(applicationName); //TODO, comment it
			// out, only for Weblogic topic
			// otherwise, at RIO, the DurableName will become
			// applicationName.applicationName
			topicSession = topicConnection.createTopicSession(false, Session.CLIENT_ACKNOWLEDGE);
			Topic topic = (Topic) jndi.lookup(topicName);
			subscriber = topicSession.createDurableSubscriber(topic, subscriberName);
			subscriber.setMessageListener(this);
			topicConnection.setExceptionListener(this);
			topicConnection.start();
		} catch (Exception e) {
			LOG.error("Error creating JMS connection.", e);
		}
	}

	@Override
	public void onException(JMSException exception) {
		LOG.error("Received JMS Exception " + exception);
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(
				new Fields(FieldNameBasedTupleToKafkaMapper.BOLT_KEY, FieldNameBasedTupleToKafkaMapper.BOLT_MESSAGE));
	}

	/*public void fail(Object msgId) {
		LOG.warn("Message failed: " + msgId);
		this.pendingMessages.clear();
	}*/

	@Override
	public void ack(Object msgId) {
		super.ack(msgId);
		synchronized (msgId) {
			if (!pendingMessages.isEmpty()) {
				Message msg = pendingMessages.get(msgId);
				if (msg != null) {
					try {
						msg.acknowledge();
						pendingMessages.remove(msgId);
					} catch (JMSException e) {
						LOG.warn("Error acknowldging JMS message: " + msgId, e);
					}
				}
			}
		}
	}
	
	private String generateMessageId (String messageSourceSystem,TextMessage textMessage) throws JMSException{
		
		String messageId = null;
		
		 if(StringUtils.isNotEmpty(messageSourceSystem)){
			 if (JMS_MESSAGE_SOURCE_SYSTEM_VERTICAL.equalsIgnoreCase(messageSourceSystem)){
				 messageId = generateReghubId(textMessage.getText());
			 }else if(JMS_MESSAGE_SOURCE_SYSTEM_EXTERNAL.equalsIgnoreCase(messageSourceSystem)){
				 messageId = textMessage.getJMSMessageID();
			 }
			 
		 }else {
			 messageId = textMessage.getJMSMessageID();
		 }
		 return messageId;
	}
	
	
	private String generateReghubId(String textMessage){
		return M2ReghubIdGeneratorFactory.getM2ReghubIdGenerator(messageType).generateReghubId(stream, flow, textMessage);
	}
}
