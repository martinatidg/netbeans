package com.citi.reghub.core.codec;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import org.bson.BsonReader;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;

public class LocalDateTimeCodec implements Codec<LocalDateTime> {

    @Override
    public LocalDateTime decode(BsonReader bsonReader, DecoderContext decoderContext) {
    	Long time = bsonReader.readInt64();
    	Long timeInMillis = time / 1000000;
		Integer timeInNanos = (int) (time % 1000000000);
		Instant inst = Instant.ofEpochMilli(timeInMillis);
		LocalDateTime ldt = LocalDateTime.ofInstant(inst, Clock.systemUTC().getZone());
		return ldt.withNano(timeInNanos);
    }

    @Override
    public void encode(BsonWriter bsonWriter, LocalDateTime localDateTime, EncoderContext encoderContext) {
    	Long epochSec = localDateTime.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
		Integer nanos = localDateTime.getNano();
		Long nanoTime = (epochSec * 1000000000) + nanos;
    	bsonWriter.writeInt64(nanoTime);
    }

    @Override
    public Class<LocalDateTime> getEncoderClass() {
        return LocalDateTime.class;
    }
}
