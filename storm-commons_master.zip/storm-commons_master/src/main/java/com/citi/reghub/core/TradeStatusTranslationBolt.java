package com.citi.reghub.core;

import java.text.MessageFormat;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.stream.IntStream;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.EventTypes;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;

public class TradeStatusTranslationBolt extends RegHubBolt{

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(TradeStatusTranslationBolt.class);
	public static final String ENTITY_SERVICE_URL_QUERY = "trade-status.entity.service.url";
	
	
	OutputCollector _collector;
	RestClient restClient;
	String serviceUrl = null;
	
	private TradeStatusTranslationAbstractFactory tradeStatusTranslationFactory;

	public TradeStatusTranslationBolt(TradeStatusTranslationAbstractFactory tradeStatusTranslationFactory){
		this.tradeStatusTranslationFactory = tradeStatusTranslationFactory;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		restClient = new RestClient(createDefault());
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		serviceUrl = topologyConfig.get(ENTITY_SERVICE_URL_QUERY);
	}

	@Override
	public void process(Tuple input) throws Exception {

		Entity currentEntity = (Entity) input.getValueByField("message");
		List<Entity> translatedEntities = new ArrayList<>();
		
		if(serviceUrl != null) {
			LOG.debug("Started Trade status translation.");
			Entity previousEntity = getPreviousEntity(currentEntity);
			TradeStatusTranslator translator =  tradeStatusTranslationFactory.getTranslator(currentEntity);
			if(translator != null) {
				translatedEntities = translator.translateTradeStatus(currentEntity, previousEntity);
			} else {
				LOG.warn("No translator found for input entity. Transaction aborted. "+currentEntity);
			}
			LOG.debug("Finished Trade status translation.");
		} else {
			throw new Exception("Entity service url is null in Trade Status Translator. Transaction aborted.");
		}

		if (translatedEntities.size() == 0) {
			_collector.emit(StormStreams.REPORTABLE, new Values(currentEntity.regHubId, currentEntity));
			pushMessageToAuditStream(currentEntity, currentEntity.status);
		} else {
			for (Entity translatedEntity : translatedEntities) {
				_collector.emit(StormStreams.REPORTABLE, new Values(translatedEntity.regHubId, translatedEntity));
				pushMessageToAuditStream(translatedEntity, translatedEntity.status);
			}
		}

		_collector.ack(input);
	}

	public void pushMessageToAuditStream(Entity message, String auditResult) {
		Audit audit = message.toAudit();
		audit.event = EventTypes.TRADE_STATUS_TRANSLATION;
		audit.result = auditResult;
		audit.info.put("sourceStatus", message.sourceStatus);
		audit.info.put("dervNotionalChange", message.info.get("dervNotionalChange"));
		audit.info.put("tradeQty", message.info.get("tradeQty"));
		audit.info.put("regReportingRef", message.regReportingRef);
		audit.info.put("origExecutionTs", message.info.get("origTradeExecTs"));
		audit.info.put("executionTs", message.executionTs);
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.TRADE_STATUS_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.TRADE_STATUS_TRANSLATOR);
		return exceptionTags;
	}

	public Entity getPreviousEntity(Entity currentEntity){
		LOG.info("Fetching Entity From Storage for SourceId "+currentEntity.sourceId);
		String formattedUrl = MessageFormat.format(serviceUrl, stream, flow, currentEntity.sourceId);
		List<Entity> previousEntityListTemp = restClient.getValues(formattedUrl, Entity.class);
		List<Entity> previousEntityList  = null;
		Entity previousEntity = null;
		if(previousEntityListTemp != null){
			OptionalInt indexOfCurrentTrade = IntStream.range(0, previousEntityListTemp.size())
			.filter(i -> currentEntity.sourceUId.equals(previousEntityListTemp.get(i).sourceUId))
			.findFirst();
			
			if(indexOfCurrentTrade.isPresent()){
				previousEntityList = previousEntityListTemp.subList(indexOfCurrentTrade.getAsInt()+1, previousEntityListTemp.size());
			}else{
				previousEntityList = previousEntityListTemp;
			}
			
			previousEntity = (previousEntityList != null && !previousEntityList.isEmpty()) ? previousEntityList.get(0) : null;
		}
		LOG.info("Previous Entity "+previousEntity);
		return previousEntity;
	}


}
