package com.citi.reghub.core;

public class KeyNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public KeyNotFoundException(String message) {
		super(message);
	}
	
}
