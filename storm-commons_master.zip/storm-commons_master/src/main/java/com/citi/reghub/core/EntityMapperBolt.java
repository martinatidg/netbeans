package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.StormConstants;

public class EntityMapperBolt extends RegHubBolt {
	
	private static final long serialVersionUID = 1L;

	private OutputCollector collector;
	
	protected EntityMapper mapper;
	
	public EntityMapperBolt(EntityMapper mapper) {
		this.mapper = mapper;
	}

	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		collector = outputCollector;
	}
	
	public void process(Tuple tuple) {
		Entity entity = createNewEntity(tuple);
		Object message = tuple.getValueByField("message");
		entity = mapper.mapToEntity(message, entity);
		collector.emit(StormStreams.SOURCE,new Values(entity.regHubId, entity));
		Audit audit = entity.toAudit();
		audit.event = StormConstants.SOURCE;
		audit.tags.add(StormConstants.SOURCE);
		collector.emit(StormStreams.AUDIT, new Values(audit.regHubId,audit));
		collector.ack(tuple);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.SOURCE,new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.AUDIT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}
	
	public Entity createNewEntity(Tuple tuple){
		Entity entity = new Entity();
		entity.stream = stream;
		entity.flow = flow;
		entity.regHubId = (String) tuple.getValueByField("key");
		return entity;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}
