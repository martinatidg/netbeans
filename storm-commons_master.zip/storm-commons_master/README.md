# storm-commons

Library to provide configuration driven utility classes for setting up Apache Kafka-Storm topology components like:

- Property based configuration map to create Storm topology
- Kafka Spout
- Kafka Consumer Properties
- Basic tuple builder for Kafka values

Example usage:

```java
String topologyName = "cash";
String envName = "test";

Map<String, String> topologyConfig = new PropertiesLoader().getProperties(topologyName, envName);

KafkaSpout<String, String> spout = new KafkaSpoutFactory().getKafkaSpout(topologyConfig);
```