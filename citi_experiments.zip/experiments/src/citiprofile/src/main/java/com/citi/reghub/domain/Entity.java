package com.citi.reghub.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Document(collection = "entity")
@CompoundIndexes({ @CompoundIndex(name = "streamFlow", def = "{'stream': 1, 'flow': 1}") })
public class Entity {
	@Id
	private String id; // reghub generated unique id for each messages
	@Indexed
	private String status; // reghub reporting status e.g. REPORTABLE, NON_REPORTABLE, EXCEPTION, PENDING, REPORTED, REJECTED

	// reason codes supporting more granularity for status such as exception codes in case of exception, non reportability reasons
	// codes in case of non reportability
	@Indexed
	private List<String> reasonCodes = new ArrayList<String>();

	@Indexed
	private String stream; // reporting stream (always 4 char) e.g. M2TR, M2PR, M2PO
	@Indexed
	private String flow; // reporting asset class / product (always 3 char) e.g. CEQ (cash equities), CFI (cash fixed income)

	// source record fields
	private String sourceSystem; // upstream source system generated the message e.g. TPS, PRIMO
	@Indexed
	private String sourceUId; // unique id for a message received from source e.g. OceanId for transaction reporting
	@Indexed
	private String sourceId; // trade/quote/order id
	private String sourceStatus; // always normalised to NEW, AMEND and CANCEL
	private String sourceVersion; // trade/quote/order version
	private String regReportingRef; // used as reporting id for trade/quote/order/transaction e.g. stream + flow + sourceId

	// date fields
	@Indexed
	private LocalDateTime receivedTs; // timestamp when entity is received in Reghub
	private LocalDateTime publishedTs; // trade activity timestamp .i.e when upstream published on RIO
	@Indexed
	private LocalDateTime executionTs; // trade generation/execution/booked timestamp
	@Indexed
	private LocalDateTime lastUpdatedTs; // timestamp of last activity in reghub, classical updated timestamp for reghub

	private Map<String, Object> info = new HashMap<String, Object>();

	// stores execution instructions for end to end flow such as OVERRIDDEN, SKIP_SEQUENCING
	// 	- OVERRIDDEN: during replay update Entity with OverrideEntity data
	// 	- SKIP_SEQUENCING: do not apply sequencing and send the record 
	// all instructions are defined as constants
	@Indexed
	private List<String> instructions = new ArrayList<String>();

	private void setLastUpdatedTs(Clock clock) {
		this.lastUpdatedTs = LocalDateTime.now(clock);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getReasonCodes() {
		return reasonCodes;
	}

	public void setReasonCodes(List<String> reasonCodes) {
		this.reasonCodes = reasonCodes;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getSourceUId() {
		return sourceUId;
	}

	public void setSourceUId(String sourceUId) {
		this.sourceUId = sourceUId;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getSourceStatus() {
		return sourceStatus;
	}

	public void setSourceStatus(String sourceStatus) {
		this.sourceStatus = sourceStatus;
	}

	public String getSourceVersion() {
		return sourceVersion;
	}

	public void setSourceVersion(String sourceVersion) {
		this.sourceVersion = sourceVersion;
	}

	public String getRegReportingRef() {
		return regReportingRef;
	}

	public void setRegReportingRef(String regReportingRef) {
		this.regReportingRef = regReportingRef;
	}

	public LocalDateTime getReceivedTs() {
		return receivedTs;
	}

	public void setReceivedTs(LocalDateTime receivedTs) {
		this.receivedTs = receivedTs;
	}

	public LocalDateTime getPublishedTs() {
		return publishedTs;
	}

	public void setPublishedTs(LocalDateTime publishedTs) {
		this.publishedTs = publishedTs;
	}

	public LocalDateTime getExecutionTs() {
		return executionTs;
	}

	public void setExecutionTs(LocalDateTime executionTs) {
		this.executionTs = executionTs;
	}

	public LocalDateTime getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public void setLastUpdatedTs(LocalDateTime lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public Map<String, Object> getInfo() {
		return info;
	}

	public void setInfo(Map<String, Object> info) {
		this.info = info;
	}

	public List<String> getInstructions() {
		return instructions;
	}

	public void setInstructions(List<String> instructions) {
		this.instructions = instructions;
	}
	
	
}