package com.citi.reghub.client;

import java.net.URI;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.citi.reghub.domain.Employee;

public class ProfileClient {
	static Employee martin = new Employee("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803",
			"90 South Street, Tampa, FL");
	static Employee yuan = new Employee("Yuan", "Tan", "Female", "yuan.tan@cqu.com", "1353767698",
			"CQU Hospital, Shapingba, China");
	static Employee jing = new Employee("Jing", "Guo", "Female", "jing.guo@sf.com", "321-502-9803", "45 Trent, CA");
	static Employee xiaolan = new Employee("Xiaolan", "Wang", "Female", "xiaolan.wang@citi.com", "321-502-9803",
			"70 North St, Columbus, SC");

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		// List<Employee> emp = getEmployee("Tan");
		//List<Employee> emp = getEmployeeEntity("Tan");

		Employee emp = saveEmployee(xiaolan);
		System.out.print(emp);
	}

	public static Employee saveEmployee(Employee employee) {
		RestTemplate rest = new RestTemplate();
		return rest.postForObject("http://localhost:8080/profile/save", employee, Employee.class);
	}

	public static List<Employee> getEmployee(String id) {
		RestTemplate rest = new RestTemplate();
		return rest.getForObject("http://localhost:8080/profile/lastName/{id}", List.class, id);
	}

	public static List<Employee> getEmployeeEntity(String id) {
		RestTemplate rest = new RestTemplate();
		ResponseEntity<List> res = rest.getForEntity("http://localhost:8080/profile/lastName/{id}", List.class, id);
		HttpHeaders httpdeaders = res.getHeaders();
		List<MediaType> mtype = httpdeaders.getAccept();
		System.out.println("accepted type:");
		for (MediaType m : mtype) {
			System.out.print(m.toString() + ", ");
		}
		System.out.println();

		return res.getBody();
	}

	public void updateSpittle(Employee employee) { // throws EmployeeException {
		RestTemplate rest = new RestTemplate();
		String url = "http://localhost:8080/spittr-api/spittles/" + employee.getId();
		rest.put(URI.create(url), employee);
	}
}
