package com.citi.reghub.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.citi.reghub.db.ProfileRepository;
import com.citi.reghub.domain.Employee;

@RestController
@RequestMapping("/profile")
public class ProfileController {
	String myUserName = "yuan";
	String myPassword = "ribi";

	@Autowired
	ProfileRepository profileRepository;

	@RequestMapping(value = "/save", method = RequestMethod.POST) //, consumes = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public Employee saveEmployee(@RequestBody Employee em) {
		System.out.println("saveEmployee: em = " + em);
//		Employee employee = new Employee("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803",
//				"90 South Street, Tampa, FL");

		return profileRepository.insert(em);
	}

	@RequestMapping(value = "/put", method = RequestMethod.POST) //, consumes = "application/json")
	@ResponseStatus(HttpStatus.CREATED)
	public Employee updateEmployee(@PathVariable String firstName, Employee em) {
//		Employee employee = new Employee("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803",
//				"90 South Street, Tampa, FL");

		return profileRepository.save(em);
	}

	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<?> getEmployee(@RequestParam(value = "firstName") String firstName) {

		List<Employee> emp = profileRepository.findByFirstName(firstName);

		if (emp == null || emp.size() < 1) {
			Error error = new Error(4, "Employee [" + firstName + "] not found");
			return new ResponseEntity<Error>(error, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(emp, HttpStatus.OK);
	}

	@RequestMapping(value = "/firstName/{firstName}", method = RequestMethod.GET)
	public ResponseEntity<List<Employee>> getEmployeeByPath(@PathVariable String firstName) {

		List<Employee> emp = profileRepository.findByFirstName(firstName);

		if (emp == null || emp.size() < 1) {
			throw new EmployeeNotFoundException(firstName);
		}

		return new ResponseEntity<List<Employee>>(emp, HttpStatus.OK);
	}

	@RequestMapping(value = "/lastName/{lastName}", method = RequestMethod.GET) //, produces = "application/xml")
	public List<Employee> getEmployeeByLastName(@PathVariable String lastName) {

		List<Employee> emp = profileRepository.findByLastName(lastName);

		if (emp == null || emp.size() < 1) {
			throw new EmployeeNotFoundException(lastName);
		}

		return emp;
	}

//	@ExceptionHandler(EmployeeNotFoundException.class)
//	public ResponseEntity<Error> employeeNotFound(EmployeeNotFoundException e) {
//		String key = e.getSearchKey();
//		Error error = new Error(4, "Employee [" + key + "] not found");
//		return new ResponseEntity<Error>(error, HttpStatus.NOT_FOUND);
//	}

	@ExceptionHandler(EmployeeNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public Error employeeNotFound(EmployeeNotFoundException e) {
		String key = e.getSearchKey();
		Error error = new Error(4, "Employee [" + key + "] not found");
		return error;
	}
}
