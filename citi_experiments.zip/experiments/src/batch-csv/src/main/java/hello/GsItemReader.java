package hello;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

public class GsItemReader implements ItemReader<Object> {
	    private StepExecution stepExecution;
	    private boolean ran = false;
	    @BeforeStep
	    public void saveStepExecution(StepExecution stepExecution) {
	    	System.out.println("GsItemReader.saveStepExecution: stepExecution = " + stepExecution);

	        this.stepExecution = stepExecution;
	    }

		@Override
		public Object read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
	        ExecutionContext stepContext = this.stepExecution.getExecutionContext();
	        stepContext.put("someKey", "kskskkkk");
	        
	        if (ran) {
	        	return null;
	        }
	        ran = true;
	        return "from GsItemReader";
		}
	}