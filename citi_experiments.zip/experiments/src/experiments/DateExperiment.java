package experiments;

import java.time.LocalDateTime;

public class DateExperiment {
	public static void main(String[] args) {
		testDate();
	}
	
	public static void testDate() {
		LocalDateTime ldt = LocalDateTime.of(2017, 6, 20, 13, 0, 0, 0);
		LocalDateTime lnow = LocalDateTime.now();
		System.out.println("from: " + ldt + " to " + lnow + ", millisecond: " + System.currentTimeMillis());
	}
}
