Code source for chapter 07 of Spring Batch in Action "Processing data".

