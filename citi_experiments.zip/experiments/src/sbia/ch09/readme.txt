Code source for chapter 9 of Spring Batch in Action "Transaction management".
Contains unit test and integration test on transactional behavior of Spring Batch.
Tests cover also transaction patterns (JTA, best efforts with JMS.)

