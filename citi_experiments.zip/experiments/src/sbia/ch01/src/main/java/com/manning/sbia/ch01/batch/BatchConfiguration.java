package com.manning.sbia.ch01.batch;

import java.net.MalformedURLException;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.UrlResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.batch.item.ItemReader;

import com.manning.sbia.ch01.domain.Product;

//@Configuration
//@EnableBatchProcessing
public class BatchConfiguration {
//    @Bean
//    public DataSource dataSource() {
//        DriverManagerDataSource dataSource = new DriverManagerDataSource();
//        //MySQL database we are using
//        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
//        dataSource.setUrl("jdbc:mysql://localhost:3306/TestDB");//change url
//        dataSource.setUsername("userid");//change userid
//        dataSource.setPassword("password");//change pwd
//        
//        //H2 database
//        /*
//        dataSource.setDriverClassName("org.h2.Driver");
//        dataSource.setUrl("jdbc:h2:tcp://localhost/~/test");
//        dataSource.setUsername("sa");
//        dataSource.setPassword("");*/
//        return dataSource;
//    }

//    @Bean
//    public JdbcTemplate jdbcTemplate() {
//        JdbcTemplate jdbcTemplate = new JdbcTemplate();
//        jdbcTemplate.setDataSource(dataSource());
//        return jdbcTemplate;
//    }
//
//    @Bean
//	public ItemReader<Product> reader() throws MalformedURLException {
//	    FlatFileItemReader<Product> reader = new FlatFileItemReader<Product>();
//	    reader.setResource(new UrlResource("file:#{jobParameters['targetDirectory']+jobParameters['targetFile']}"));
//	    reader.setLineMapper(new DefaultLineMapper<Product>() {{
//	        setLineTokenizer(new DelimitedLineTokenizer());
//	        setFieldSetMapper(new ProductFieldSetMapper());
//	    }});
//	    return reader;
//	}
}
