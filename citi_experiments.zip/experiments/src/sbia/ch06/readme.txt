Code source for chapter 6 of Spring Batch in Action

Contains the Spring Batch Test sample.

