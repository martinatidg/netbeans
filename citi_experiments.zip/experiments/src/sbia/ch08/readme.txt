Code source for chapter 08 of Spring Batch in Action "Bullet-proof jobs".
Contains unit test and integration tests on skip, retry, and restart behavior.

