Code source for chapter 1 of Spring Batch in Action

You can browse the code as well as the unit/integration tests.

