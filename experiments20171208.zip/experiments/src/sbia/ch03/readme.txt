Code source for chapter 3 of Spring Batch in Action
