create table skipped_product(
  line varchar(1000),
  line_number int
);