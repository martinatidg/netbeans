package experiments;

import java.util.Random;

public class TryRandom {
	public static void main(String[] args) {
		runRandom();
	}
	
	public static void runRandom() {
		Random random = new Random();
		
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextInt(100): " + random.nextInt(100));
		System.out.println("nextDouble(): " + random.nextDouble());
		System.out.println("nextDouble(): " + random.nextDouble());
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextInt(10): " + random.nextInt(10));
		System.out.println("nextLong(): " + random.nextLong());
		System.out.println("nextLong(): " + random.nextLong());
		System.out.println("nextBoolean(): " + random.nextBoolean());
		System.out.println("nextBoolean(): " + random.nextBoolean());
		System.out.println("nextBoolean(): " + random.nextBoolean());
		System.out.println("nextBoolean(): " + random.nextBoolean());
		System.out.println("nextBoolean(): " + random.nextBoolean());
		System.out.println("nextBoolean(): " + random.nextBoolean());
		System.out.println("nextBoolean(): " + random.nextBoolean());

	}
}
