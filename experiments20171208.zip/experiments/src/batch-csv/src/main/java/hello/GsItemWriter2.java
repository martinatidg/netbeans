package hello;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;

public class GsItemWriter2 implements ItemWriter<Object> {
	    private StepExecution stepExecution;

	    public void write(List<? extends Object> items) throws Exception {
	        // ...

	        ExecutionContext stepContext = this.stepExecution.getExecutionContext();
	        stepContext.get("someKey");
	        System.out.println("GsItemWriter2: passed value of last step: " + stepContext.get("someKey"));
	    }

	    @BeforeStep
	    public void saveStepExecution(StepExecution stepExecution) {
	    	System.out.println("GsItemWriter2.saveStepExecution: stepExecution = " + stepExecution);
	        this.stepExecution = stepExecution;
	    }
	}