package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;

public class CompatibleFieldSerializerTest {

	private StreamFactory sf;
	private Kryo kryo;
	
	static interface StreamFactory {
		public Output createOutput (OutputStream os);

		public Output createOutput (OutputStream os, int size);

		public Output createOutput (int size, int limit);

		public Input createInput (InputStream os, int size);

		public Input createInput (byte[] buffer);
	}
	
	@Before
	public void setup(){
		kryo = new Kryo();
		sf = new StreamFactory() {
			public Output createOutput (OutputStream os) {
				return new Output(os);
			}

			public Output createOutput (OutputStream os, int size) {
				return new Output(os, size);
			}

			public Output createOutput (int size, int limit) {
				return new Output(size, limit);
			}

			public Input createInput (InputStream os, int size) {
				return new Input(os, size);
			}

			public Input createInput (byte[] buffer) {
				return new Input(buffer);
			}
		};
	}
	
	@Test
	public void testCompatibleFieldSerializer () {
		
		
		CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, TestClass.class);
		kryo.register(TestClass.class, serializer);
		
		TestClass object1 = new TestClass();
		object1.child = new TestClass();
		
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
	    Output output = sf.createOutput(outStream, 4096);
	    kryo.writeClassAndObject(output, object1);
	    output.flush();
	    
	    byte[] out = outStream.toByteArray();
		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		Object object2 = kryo.readClassAndObject(input);
		assertEquals(object1, object2);
	    
	}
	
	@Test
	public void testAddedField () {
		TestClass object1 = new TestClass();
		object1.child = new TestClass();
		CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, TestClass.class);
		serializer.removeField("text");
		kryo.register(TestClass.class, serializer);
		
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
	    Output output = sf.createOutput(outStream, 4096);
	    kryo.writeClassAndObject(output, object1);
	    output.flush();
	    byte[] out = outStream.toByteArray();
		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		
	    kryo.register(TestClass.class, new CompatibleFieldSerializer(kryo, TestClass.class));
		Object object2 = kryo.readClassAndObject(input);
		assertEquals(object1, object2);
	}
	
	static public class TestClass {
		public String text = "something";
		public int moo = 120;
		public long moo2 = 1234120;
		public TestClass child;
		public int zzz = 123;
		
		public boolean equals (Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			TestClass other = (TestClass)obj;
			if (child == null) {
				if (other.child != null) return false;
			} else if (!child.equals(other.child)) return false;
			if (moo != other.moo) return false;
			if (moo2 != other.moo2) return false;
			if (text == null) {
				if (other.text != null) return false;
			} else if (!text.equals(other.text)) return false;
			if (zzz != other.zzz) return false;
			return true;
		}
	}
}
