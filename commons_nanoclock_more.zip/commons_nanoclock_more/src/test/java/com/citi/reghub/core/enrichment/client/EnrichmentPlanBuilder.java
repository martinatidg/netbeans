package com.citi.reghub.core.enrichment.client;

import java.util.ArrayList;
import java.util.List;

public class EnrichmentPlanBuilder {
	
	public String id;
    public String name;
    public String type;
    public String description;
    public String group = "Metadata";
    public String	version;
    public List<EnricherConfig> enricherConfigs = new ArrayList<>();

    public EnrichmentPlanBuilder id (String id) {
    	this.id = id;
    	return this;
    }
    
    public EnrichmentPlanBuilder name (String name) {
    	this.name = name;
    	return this;
    }
    
    public EnrichmentPlanBuilder type(String type) {
    	this.type = type;
    	return this;
    }
    
    public EnrichmentPlanBuilder description(String description) {
    	this.description = description;
    	return this;
    }
    
    public EnrichmentPlanBuilder enricher(EnricherConfig enricherConfig) {
    	this.enricherConfigs.add(enricherConfig);
    	return this;
    }
    
    public EnrichmentPlanBuilder vesrion(String vesrion) {
    	this.version = vesrion;
    	return this;
    }
    
	public EnrichmentPlan build() {
		return new EnrichmentPlan(id, name, type, description, group, enricherConfigs, version);
	}
}
