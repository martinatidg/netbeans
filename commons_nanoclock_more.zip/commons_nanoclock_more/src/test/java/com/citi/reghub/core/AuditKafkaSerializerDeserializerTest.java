package com.citi.reghub.core;

import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;

public class AuditKafkaSerializerDeserializerTest {

	private StreamFactory sf;
	private Kryo kryo;
	AuditKafkaSerializerDeserializer serde;
	
	@Before
	public void setup() {
		kryo = new Kryo();
		serde = new AuditKafkaSerializerDeserializer();
		
		sf = new StreamFactory() {
			public Output createOutput(OutputStream os) {
				return new Output(os);
			}

			public Output createOutput(OutputStream os, int size) {
				return new Output(os, size);
			}

			public Output createOutput(int size, int limit) {
				return new Output(size, limit);
			}

			public Input createInput(InputStream os, int size) {
				return new Input(os, size);
			}

			public Input createInput(byte[] buffer) {
				return new Input(buffer);
			}
		};
	}

	@Test
	public void testSerializationDeserialization() {
		Audit audit = new EntityBuilder().build().toAudit();
		audit.regHubId = "M2TRCSHEQ110789";

		byte[] serBytes = serde.serialize("test_topic", audit);
		Audit deserAudit = serde.deserialize("test_topic", serBytes);
		assertEquals(audit.regHubId, deserAudit.regHubId);
	}

	@Test
	public void testAuditBackwardCompatibility() {
		CompatibleFieldSerializer<Audit> serializer = new CompatibleFieldSerializer<Audit>(kryo, Audit.class);

		Audit audit = new EntityBuilder().build().toAudit();
		serializer.removeField("regHubId");
		kryo.register(Audit.class, serializer);

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		Output output = sf.createOutput(outStream, 4096);
		kryo.writeClassAndObject(output, audit);
		output.flush();

		byte[] out = outStream.toByteArray();
		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		Audit deserAudit = (Audit) kryo.readClassAndObject(input);

		assertThat(audit.regHubId, not(deserAudit.regHubId));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAuditDeserilizationException() {
		Audit audit = new EntityBuilder().build().toAudit();
		audit.regHubId = "M2TRCSHEQ110789";

		byte[] serBytes = serde.serialize("test_topic", audit);
		serBytes = new byte[4096];
		Audit deserAudit = serde.deserialize("test_topic",  serBytes);
		assertEquals(audit.regHubId, deserAudit.regHubId);
	}

	static interface StreamFactory {
		public Output createOutput(OutputStream os);

		public Output createOutput(OutputStream os, int size);

		public Output createOutput(int size, int limit);

		public Input createInput(InputStream os, int size);

		public Input createInput(byte[] buffer);
	}
}
