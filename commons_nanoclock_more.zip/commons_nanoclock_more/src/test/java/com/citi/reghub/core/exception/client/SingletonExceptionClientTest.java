package com.citi.reghub.core.exception.client;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Field;

import org.junit.Test;

import com.citi.reghub.core.exception.client.SingletonExceptionClient;


public class SingletonExceptionClientTest {
	
	@Test(expected = IllegalAccessException.class)
	public void shouldNotGetXmClient() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InstantiationException {
		Field xmClientInstance = SingletonExceptionClient.class.getDeclaredField("instance");
		xmClientInstance.setAccessible(true);
		xmClientInstance.set(SingletonExceptionClient.class.newInstance(), null);
		SingletonExceptionClient.getInstance();
	}
	
	@Test
	public void shouldSetClient() {
		SingletonExceptionClient.setInstance(null);
		assertNotNull(SingletonExceptionClient.getInstance());
	}

}
