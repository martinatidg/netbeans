package com.citi.reghub.core.refdata.client;

import java.util.HashMap;

import com.citi.reghub.core.refdata.client.SingletonRefdataClient;

public class TestRefData {

	public static void main(String args[]) {

		SingletonRefdataClient.setInstance(new HashMap<String, String>() {
			{
				put(RefdataClient.GEMFIRE_CACHE_XML_PATH, "gemfire-client-default.xml");
			}
		});

		String[] smcps = { "1200538", "61365", "207517284", "58506", "56453", "72609178", "222706619", "57020",
				"1532122", "34266", "72290608", "18898", "57893", "35845", "66962195", "30786891", "15465815",
				"1535399", "56753", "54201", "320223348", "1143273", "44970", "1557389", "87405403", "1622139",
				"152177302", "62104", "56057", "60495", "57477", "14916855", "19053805", "9675", "126485394", "57709",
				"315713", "23202", "4982", "26659", "320133345", "98302611", "200941725", "64235643", "1436705",
				"22335", "148932056", "62428", "45290", "81484513" };

		String[] isins = { "XS0470740530", "GB0002374006", "AU000000S320", "GB0009252882", "ES0148396007",
				"ZAG000096132", "NL0011333752", "GB0006683238", "XS0236800412", "NL0011821202", "XS0798491113",
				"DE0005439004", "BMG702781094", "NO0003096208", "XS0782021140", "XS0629969352", "GG00B4ZWPH08",
				"GB00B0CX2M20", "TRAARCLK91H5", "ES0113900J37", "XS0195160329", "IT0001398541", "XS0241945582",
				"IE00B7ZQC614", "XS0423048247", "GB00BMSKPJ95", "GB00B03MM408", "GB00B07KD360", "FR0000045072",
				"JE00B5TT1872", "XS0562107762", "LU0569974404", "FI0009000681", "GB00BFXW0853", "GB0001500809",
				"NL0011821202", "DE000CBK1001", "FI0009005987", "DE0007500001", "XS0919401751", "GB00BVVT4H71",
				"XS0772553037", "FR0000483687", "GRS323003012", "GB00BLT1Y088", "GB0008706128", "NO0003070609",
				"GB00BY9D0Y18" };
		String[] cusips = { "T9277NAJ4", "T52452124", "E90678AD0", "G1237PAR1", "N2557FEP5", "G0013T104", "G7690A118",
				"G41440143", "F22797108", "G2055Q105", "F4113NGB9", "L0187K107", "X61873133", "G2R26J3Q9", "G91235104",
				"N4578E595", "D172W1279", "X9518S108", "D8398Q119", "F62738AK9", "G62924108", "G08097AM2", "F4113CDF7",
				"X2321W101", "G7770H108", "G5533W248", "R33736100", "G2871V114" };

		String[] fiis = { "35608282", "7922055", "127165804", "32067144", "83666024", "129119879", "32029406",
				"32361198", "18002101", "44560351", "8030777", "32017756", "32205167", "83838608", "40615477",
				"39753441", "32328271", "32280143", "7892934", "32251989", "8540983", "32367990", "46230240",
				"34542228", "82899328", "32319669", "7921120", "32138400", "42905786", "37774607", "38440575",
				"8529027", "57505901", "18016111", "151145396", "7919873", "18000928", "32019671", "48545373",
				"126131327", "58231924", "32063003", "32019909", "82113606", "7927795", "32235219", "45447567" };

		String[] mnemonics = { "PACW1", "AKEU", "USCA", "USCA", "HKSSS", "JPAP", "HKSSS", "HEF", "KRLOL", "KRLOL",
				"BTB1", "YCOP", "EUEB", "BTB1", "BTB1", "BTB1", "YSDE", "RCOP", "CZMP", "RTEL", "RTEL", "EUMAM",
				"CGMLFOR", "HKIL", "LTS1385", "HKIL", "MYCGML", "KEBSBS", "T8KSE", "BDMASUTF", "LDD84274", "LTD9878",
				"BDMASUTF", "BDMASUTF", "BDMASUTF", "LDDC8684", "YCOP", "YRUS", "YTEL" };

		String[] rics = { "ES047074053=", "DGE.L", "S32.L", "GSK.L", "ITX.MC", "ZAG000096132=RRPS", "ATCA.AS", "CMS.L",
				"FR023680041=", "INGA.AS", "US079849111=", "CONG.DE", "PDL.L", "LSG.OL", "GB062996935=", "JLIF.L",
				"GBB0CX2M2=", "ARCLK.IS", "SAN.MC", "IT019516032=", "GEDI.MI", "ES024194558=", "3OIL.L", "DE042304824=",
				"AAAA.L", "RDSb.L", "COB.L", "CAGR.PA", "CEY.L", "FR056210776=", "APAM.AS", "NOKIA.HE", "TLW.L",
				"CBKG.DE", "UPM.HE", "TKAG.DE", "FR091940175=", "MTFB.L", "FR012000430=", "EURBr.AT", "SAGAG.L",
				"LLOY.L", "IDEX.OL", "DLGD.L" };

		Integer[] gfcis = { 1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000242191,
				1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000242191,
				1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000242191, 1000651636, 0000244651,
				1000493038, 1002680692, 1000493038, 1002079751, 1004133168, 1000517034, 1010815092, 1006033977,
				1002234706, 1010815092, 1010815092, 1010815092, 1011889006, 1000242191, 1000242191, 1000242191 };

		for (int gfci : gfcis) {
			try {
				System.out.println(
						SingletonRefdataClient.getInstance().getRefdataAccountClient().getData("GFCID", gfci));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// Fii pass, cusip 1 pass, isin pass, smcp pass, ric 1 pass

		/*
		 * for (String ric : rics) { try { System.out.println(ric + " - " +
		 * SingletonRefdataClient.getInstance().getRefdataProductClient().getData("RIC",
		 * ric)); } catch (Exception e) { e.printStackTrace(); } }
		 */
		System.out
				.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("RIC", "ES047074053"));

		/*
		 * System.out.println(SingletonRefdataClient.getInstance().
		 * getRefdataAccountClient() .getData(AccountIdentifier.MNEMONIC.getValue(),
		 * "HKFXFIFX"));
		 * 
		 * System.out.println(SingletonRefdataClient.getInstance().
		 * getRefdataAccountClient() .getData(AccountIdentifier.ACTID.getValue(),
		 * 20367272));
		 * 
		 * System.out.println(SingletonRefdataClient.getInstance().
		 * getRefdataAccountClient() .getData(AccountIdentifier.GFCID.getValue(),
		 * 1000101865));
		 * 
		 * System.out
		 * .println(SingletonRefdataClient.getInstance().getRefdataProductClient().
		 * getData("CUSIP", "G3910J112"));
		 * System.out.println(SingletonRefdataClient.getInstance().
		 * getRefdataProductClient().getData("SMCP", "1200538"));
		 * System.out.println("ISIN TRAARCLK91H5" +
		 * SingletonRefdataClient.getInstance().getRefdataProductClient().getData(
		 * "ISIN", "TRAARCLK91H5"));
		 */
	}

}
