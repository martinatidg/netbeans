package com.citi.reghub.core.rules.client.integration;

import static org.apache.http.impl.client.HttpClients.createDefault;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.CacheClientFactory;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;
import com.citi.reghub.core.rules.client.RuleGraphResult;
import com.citi.reghub.core.rules.client.RulesClient;
import com.citi.reghub.core.rules.client.RulesClientConfig;
import com.citi.reghub.core.rules.client.Trade;

public class RulesClientIntegrationWithRulesServiceTest {
    RestClient restClient;
    RulesClientConfig rulesClientConfig;
    MetadataClientConfig metadataConfig;
    RulesClient rulesClient;
    CacheClient cacheClient;

    @Before
    public void setUp() throws Exception {
        restClient = new RestClient(createDefault());
		Map map = new HashMap<>();
		map.put("cache.provider", "hazelcast");
        cacheClient = CacheClientFactory.getInstance(map);
        rulesClientConfig = new RulesClientConfig().set(RulesClientConfig.REST_CLIENT, restClient).set(RulesClientConfig.CACHE_CLIENT, cacheClient);
        metadataConfig = new MetadataClientConfig().set(MetadataClientConfig.REST_CLIENT, restClient)
        			.set(metadataConfig.CACHE_CLIENT, cacheClient).setDefaultMetadataUrl().set(MetadataClientConfig.FLOW_CODE, "FLOW1");
        rulesClient = new RulesClient(rulesClientConfig);
        SingletonMetadataClient.setInstance(metadataConfig);
    }

    @Test
    @Ignore // ignored since this is integration tests and requires rules service to be up and running
    public void shouldBeAbleToGetAndExecuteDroolsRule() throws Exception {
        Trade trade = new Trade(){{
            this.exchangeCode = "NYSE";
            this.info.put("tradeDate", LocalDate.of(2007, 11, 4));
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("m2tr-pre-eligibility-check")
                .execute(trade, new HashMap<>(),true);

        assertThat(result.getStatus(),equalTo(EntityStatus.NON_REPORTABLE));
        assertThat(result.getRuleResults().get(0).getStatus(),equalTo("NON_REPORTABLE"));
        assertThat(result.getRuleResults().get(1).getStatus(),equalTo("REPORTABLE"));

    }
}
