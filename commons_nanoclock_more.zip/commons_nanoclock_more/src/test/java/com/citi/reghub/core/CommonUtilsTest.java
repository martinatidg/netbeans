package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class CommonUtilsTest {

	@Test
	public void shouldConvertPojoToMap() {
		Entity entity = new EntityBuilder().build();

		long start = System.currentTimeMillis();
		Map<String, Object> mappedEnitty = CommonUtils.objectToMap(entity);
		long end = System.currentTimeMillis();
		System.out.printf("Time taken in milli sec: %d", end - start);
		
		assertEquals(entity.regHubId, mappedEnitty.get("regHubId"));
		assertEquals(entity.receivedTs, mappedEnitty.get("receivedTs"));
		assertEquals(entity.reasonCodes, mappedEnitty.get("reasonCodes"));
		assertEquals(entity.isRdsEligible(), mappedEnitty.get("rdsEligible"));
		assertEquals(entity.getLocalDate("tradeDate"),
				(LocalDate)((Map<String, Object>) mappedEnitty.get("info")).get("tradeDate"));
		assertEquals(entity.getBigDecimal("tradeQty"),
				((Map<String, Object>) mappedEnitty.get("info")).get("tradeQty"));
		
	}
	
	@Test
	public void shouldBeAbleToConvertNull() {
		Map<String, Object> mappedEnitty = CommonUtils.objectToMap(null);
		
		assertEquals(new HashMap<>(), mappedEnitty);
	}
	
	@Test
	public void shouldBeAbleToConvertUtilDate() throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		SimpleDateFormat formatterWithTime = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String date = "2017/10/26";
		String dateTime = "2017/10/26 13:16:40";
		Date dateWithoutTimeComp = formatter.parse(date);
		Date dateWithTimeComp = formatterWithTime.parse(dateTime);
		
		TestDate testDate = new TestDate(dateWithoutTimeComp, dateWithTimeComp);
		
		Map<String, Object> mappedEnitty = CommonUtils.objectToMap(testDate);
		
		LocalDateTime outLdt = (LocalDateTime) mappedEnitty.get("dateTs");
		assertEquals(dateWithTimeComp.getTime(), outLdt.atZone(ZoneOffset.UTC).toInstant().toEpochMilli());
	}
	
	static class TestDate {
		
		Date date;
		Date dateTs;
		
		public TestDate(Date date, Date dateTs) {
			this.date = date;
			this.dateTs = dateTs;
		}
	}
}
