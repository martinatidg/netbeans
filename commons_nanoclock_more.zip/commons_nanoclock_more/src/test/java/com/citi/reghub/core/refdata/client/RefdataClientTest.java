package com.citi.reghub.core.refdata.client;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;

import com.citi.reghub.core.refdata.client.Refdata.RefdataType;

public class RefdataClientTest {

	RefdataClient refdataClient;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	
	@Before
	public void setup() {
		refdataClient = new RefdataClient();
		refdataClient.setRefdataProductClient(Mockito.mock(RefdataSecurityClient.class));
		refdataClient.setRefdataAccountClient(Mockito.mock(RefdataAccountClient.class));
	}

	@Test
	public void shouldReturnAccountDetailsOceanId() {
		Mockito.when(refdataClient.getRefdataAccountClient().getData(AccountIdentifier.OCEAN_ID.name(), 926716551L))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("oceanAccountId", 926716551L);
						put("actId", 20392447L);
						put("gfci", "1000451742");
						put("cagid", "9000027429");
						put("acctMnemonic", "Q7WB640");
						put("accShrtName", "Citi Finance");
						put("restricTradeFlag", "Y");
					}
				});

		Refdata resultSet = refdataClient.getDetails("ACCOUNT", "OCEAN_ID", 926716551L);

		assertThat(resultSet.getType(), equalTo("ACCOUNT"));
		assertEquals(926716551L, ((Map) resultSet.getData()).get("oceanAccountId"));
		assertEquals("Q7WB640", ((Map) resultSet.getData()).get("acctMnemonic"));
		assertEquals("1000451742", ((Map) resultSet.getData()).get("gfci"));
		assertEquals("Y", ((Map) resultSet.getData()).get("restricTradeFlag"));
	}
	
	@Test
	public void shouldReturnAccountDetailsActId() {
		Mockito.when(refdataClient.getRefdataAccountClient().getData(AccountIdentifier.ACTID.name(), 20392447L))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("oceanAccountId", 926716551L);
						put("actId", 20392447L);
						put("gfci", "1000451742");
						put("cagid", "9000027429");
						put("acctMnemonic", "Q7WB640");
						put("accShrtName", "Citi Finance");
						put("restricTradeFlag", "Y");
					}
				});

		Refdata resultSet = refdataClient.getDetails("ACCOUNT", "ACTID", 20392447L);

		assertThat(resultSet.getType(), equalTo("ACCOUNT"));
		assertEquals(926716551L, ((Map) resultSet.getData()).get("oceanAccountId"));
		assertEquals("Q7WB640", ((Map) resultSet.getData()).get("acctMnemonic"));
		assertEquals("1000451742", ((Map) resultSet.getData()).get("gfci"));
		assertEquals("Y", ((Map) resultSet.getData()).get("restricTradeFlag"));
	}
	
	@Test
	public void shouldReturnAccountDetailsGfcId() {
		Mockito.when(refdataClient.getRefdataAccountClient().getData(AccountIdentifier.GFCID.name(), "1000451742"))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("oceanAccountId", 926716551L);
						put("actId", 20392447L);
						put("gfci", "1000451742");
						put("cagid", "9000027429");
						put("acctMnemonic", "Q7WB640");
						put("accShrtName", "Citi Finance");
						put("restricTradeFlag", "Y");
					}
				});

		Refdata resultSet = refdataClient.getDetails("ACCOUNT", "GFCID", "1000451742");

		assertThat(resultSet.getType(), equalTo("ACCOUNT"));
		assertEquals(926716551L, ((Map) resultSet.getData()).get("oceanAccountId"));
		assertEquals("Q7WB640", ((Map) resultSet.getData()).get("acctMnemonic"));
		assertEquals("1000451742", ((Map) resultSet.getData()).get("gfci"));
		assertEquals("Y", ((Map) resultSet.getData()).get("restricTradeFlag"));
	}

	@Test
	public void shouldReturnAccountDataByAccountMnemonic() {
		Mockito.when(refdataClient.getRefdataAccountClient().getData(AccountIdentifier.MNEMONIC.name(), "Q7WB640"))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("oceanAccountId", 926716551L);
						put("actId", 20392447L);
						put("gfci", "1000451742");
						put("cagid", "9000027429");
						put("acctMnemonic", "Q7WB640");
						put("accShrtName", "Citi Finance");
						put("restricTradeFlag", "Y");
					}
				});

		Refdata resultSet = refdataClient.getDetails("ACCOUNT", "MNEMONIC", "Q7WB640");

		assertThat(resultSet.getType(), equalTo("ACCOUNT"));
		assertEquals(926716551L, ((Map) resultSet.getData()).get("oceanAccountId"));
		assertEquals("Q7WB640", ((Map) resultSet.getData()).get("acctMnemonic"));
		assertEquals("1000451742", ((Map) resultSet.getData()).get("gfci"));
		assertEquals("Y", ((Map) resultSet.getData()).get("restricTradeFlag"));
	}
	
	@Test
	public void shouldThrowExceptionWhenInvalidRefdataType() {
		expectedEx.expect(RuntimeException.class);
		expectedEx.expectMessage("Invalid refdata type: PRODUCT");
		refdataClient.getDetails("PRODUCT", "ISIN", "DE0007236101");
	}

	@Test
	public void shouldReturnProductDataByISIN() {
		Mockito.when(refdataClient.getRefdataProductClient().getData(SecurityIdentifier.ISIN.name(), "DE0007236101"))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("fii", "32408314");
						put("isin", "DE0007236101");
						put("cusip", "D69671218");
						put("sedol", "5727973");
					}
				});

		Refdata resultSet = refdataClient.getDetails("SECURITY", "ISIN", "DE0007236101");

		assertThat(resultSet.getType(), equalTo("SECURITY"));
		assertThat((String) ((Map) resultSet.getData()).get("fii"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("isin"), equalTo("DE0007236101"));
		assertThat((String) ((Map) resultSet.getData()).get("cusip"), equalTo("D69671218"));
		assertThat((String) ((Map) resultSet.getData()).get("sedol"), equalTo("5727973"));
	}

	@Test
	public void shouldReturnProductDataByFII() {
		Mockito.when(refdataClient.getRefdataProductClient().getData(SecurityIdentifier.FII.name(), "32408314"))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("fii", "32408314");
						put("isin", "DE0007236101");
						put("cusip", "D69671218");
						put("sedol", "5727973");
					}
				});

		Refdata resultSet = refdataClient.getDetails("SECURITY", "FII", "32408314");

		assertThat(resultSet.getType(), equalTo("SECURITY"));
		assertThat((String) ((Map) resultSet.getData()).get("fii"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("isin"), equalTo("DE0007236101"));
		assertThat((String) ((Map) resultSet.getData()).get("cusip"), equalTo("D69671218"));
		assertThat((String) ((Map) resultSet.getData()).get("sedol"), equalTo("5727973"));
	}

	@Test
	public void shouldReturnProductDataByCusip() {
		Mockito.when(refdataClient.getRefdataProductClient().getData(SecurityIdentifier.CUSIP.name(), "D69671218"))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("fii", "32408314");
						put("isin", "DE0007236101");
						put("cusip", "D69671218");
						put("sedol", "5727973");
					}
				});

		Refdata resultSet = refdataClient.getDetails("SECURITY", "CUSIP", "D69671218");

		assertThat(resultSet.getType(), equalTo("SECURITY"));
		assertThat((String) ((Map) resultSet.getData()).get("fii"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("isin"), equalTo("DE0007236101"));
		assertThat((String) ((Map) resultSet.getData()).get("cusip"), equalTo("D69671218"));
		assertThat((String) ((Map) resultSet.getData()).get("sedol"), equalTo("5727973"));
	}

	@Test
	public void shouldReturnProductDataBySMCP() {
		Mockito.when(refdataClient.getRefdataProductClient().getData(SecurityIdentifier.SMCP.name(), "32408314"))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("smcp", "32408314");
						put("fii", "32408314");
						put("isin", "DE0007236101");
						put("cusip", "D69671218");
						put("sedol", "5727973");
					}
				});

		Refdata resultSet = refdataClient.getDetails("SECURITY", "SMCP", "32408314");

		assertThat(resultSet.getType(), equalTo("SECURITY"));
		assertThat((String) ((Map) resultSet.getData()).get("smcp"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("fii"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("isin"), equalTo("DE0007236101"));
		assertThat((String) ((Map) resultSet.getData()).get("cusip"), equalTo("D69671218"));
		assertThat((String) ((Map) resultSet.getData()).get("sedol"), equalTo("5727973"));
	}

	@Test
	public void shouldReturnProductDataByOceanId() {
		Mockito.when(refdataClient.getRefdataProductClient().getData(SecurityIdentifier.OCEAN_ID.name(), 123456789))
				.thenReturn(new HashMap<String, Object>() {
					{
						put("oceanProductId", "123456789");
						put("smcp", "32408314");
						put("fii", "32408314");
						put("isin", "DE0007236101");
						put("cusip", "D69671218");
						put("sedol", "5727973");
					}
				});

		Refdata resultSet = refdataClient.getDetails("SECURITY", "OCEAN_ID", 123456789);

		assertThat(resultSet.getType(), equalTo("SECURITY"));
		assertThat((String) ((Map) resultSet.getData()).get("oceanProductId"), equalTo("123456789"));
		assertThat((String) ((Map) resultSet.getData()).get("smcp"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("fii"), equalTo("32408314"));
		assertThat((String) ((Map) resultSet.getData()).get("isin"), equalTo("DE0007236101"));
		assertThat((String) ((Map) resultSet.getData()).get("cusip"), equalTo("D69671218"));
		assertThat((String) ((Map) resultSet.getData()).get("sedol"), equalTo("5727973"));
	}
	
	
}
