package com.citi.reghub.core.metadata.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;

public class MetadataClientTest {
	
	RestClient restClient;
	
	MetadataClientConfig metadataClientConfig;
	
	MetadataClient metadataClient;
	
	CacheClient cacheClient;
	
	@Before
	public void setUp(){
		restClient = mock(RestClient.class);
		cacheClient = mock(CacheClient.class);		
		metadataClientConfig = new MetadataClientConfig().set(MetadataClientConfig.REST_CLIENT, restClient).
				set(MetadataClientConfig.CACHE_CLIENT, cacheClient).setDefaultMetadataUrl()
				.set(MetadataClientConfig.STREAM_CODE, "STREAM2")
				.set(MetadataClientConfig.FLOW_CODE, "FLOW2");
		metadataClient = new MetadataClient(metadataClientConfig);
		
        Map<String,Object> metadataFromService = new MetadataBuilder("testGroup","simpleList",Arrays.asList("EQUITY","DEBT")).build();
        when(restClient.get("http://localhost:8082/reghub-api/metadata-service/metadata/myMetadata",Map.class))
                .thenReturn(metadataFromService);
	}
	
	@Test
	public void testMetadataFound(){
		Object obj = metadataClient.get("myMetadata",null);
		assertNotNull(obj);
		assertTrue(obj instanceof List);
		assertEquals("EQUITY",((List) obj).get(0));
		assertEquals("DEBT",((List) obj).get(1));
	}
	
	@Test
	public void testMetadataFoundInCache(){
		Map<String,Object> metadataFromCache = new MetadataBuilder("testGroup","simpleList",Arrays.asList("EQTY","DBT")).build();
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		config.put(CacheClient.CACHE_COLLECTION_NAME, "stream2_flow2_metadata");
		when(cacheClient.get("myMetadata", config)).thenReturn(new Metadata(metadataFromCache).value);
		Object obj = metadataClient.get("myMetadata",null);
		assertNotNull(obj);
		assertTrue(obj instanceof List);
		assertEquals("EQTY",((List) obj).get(0));
		assertEquals("DBT",((List) obj).get(1));
	}
	
	@Test
	public void testMetadataNotFoundInCacheButFoundInService(){
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		config.put(CacheClient.CACHE_COLLECTION_NAME, "STREAM2_FLOW2_metadata");
		when(cacheClient.get("myMetadata", config)).thenReturn(null);
		Object obj = metadataClient.get("myMetadata",null);
		assertNotNull(obj);
		assertTrue(obj instanceof List);
		assertEquals("EQUITY",((List) obj).get(0));
		assertEquals("DEBT",((List) obj).get(1));
	}
	
	@Test(expected = RuntimeException.class)
	public void testMetadataNotFoundInCacheAndService(){
		Object obj = metadataClient.get("someMetadata",null);
	}
	
	@Test
	public void testMetadataFoundInCacheCacheName(){
		Map<String,Object> metadataFromCache = new MetadataBuilder("testGroup","simpleList",Arrays.asList("EQTY","DBT")).build();
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		config.put(CacheClient.CACHE_COLLECTION_NAME, "custom_cache_name");
		when(cacheClient.get("myMetadata", config)).thenReturn(new Metadata(metadataFromCache).value);
		Object obj = metadataClient.get("myMetadata","custom_cache_name");
		assertNotNull(obj);
		assertTrue(obj instanceof List);
		assertEquals("EQTY",((List) obj).get(0));
		assertEquals("DBT",((List) obj).get(1));
	}

}
