package com.citi.reghub.core.entity.client;

import java.util.HashMap;

import com.citi.reghub.core.client.RestClient;

public class EntityClientConfig  extends HashMap<String,Object> {
	
	private static final long serialVersionUID = 1L;
	
	public static final String REST_CLIENT = "restClient";
    public static final String ENTITY_URL_KEY = "metadataUrl";
    public static final String ENTITY_URL_VALUE = "http://localhost:8132/overriddenEntity/getOverriddenEntities";
    public static final String FLOW_CODE = "flowCode";

    public RestClient getRestClient() {
        return (RestClient) get(REST_CLIENT);
    }

    public String getEntityUrl() {
        return (String) get(ENTITY_URL_KEY);
    }

    public EntityClientConfig setDefaultMetadataUrl() {
        return set(ENTITY_URL_KEY, ENTITY_URL_VALUE);
    }

    public String getFlowCode(){
    	return (String)get(FLOW_CODE);
    }
    
    public EntityClientConfig set(String key, Object value){
        put(key,value);
        return this;
    }
}
