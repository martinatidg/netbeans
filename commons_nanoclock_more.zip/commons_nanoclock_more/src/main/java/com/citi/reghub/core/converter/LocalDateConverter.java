package com.citi.reghub.core.converter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LocalDateConverter implements TypeConverter<String, LocalDate> {

	public LocalDate convert(String obj, String format) {
		// TODO Auto-generated method stub
		if(format == null || format.isEmpty())
			return LocalDate.parse(obj);
		return LocalDate.parse(obj, DateTimeFormatter.ofPattern(format));
	}

}
