package com.citi.reghub.core.refdata.client;

import java.util.Map;

public interface RefdataInterface {

	public Map<String, Object> getData(String identifier, Object value);

}
