package com.citi.reghub.core.constants;

public interface Flow {
    String CSHEQ = "csheq";
    String CSHFI = "cshfi";
    String COMDERV = "comderv";
    String OTCEQD = "otceqd";
    String TPSDERV = "tpsderv";
    String CSHFX = "cshfx";
  	String CSHFXBHW = "cshfxbhw";
    String OPTFX = "optfx";
    String EDLFI = "edlfi";
    String ETDFUTR = "etdfutr";
    String ETDDDI = "etdddi";
    String DDIOTC = "ddiotc";
    String COMETD = "cometd";
    String DDIWRNT = "ddiwrnt";
    String EXMUR = "exmur";
    String MUNIDERV = "muniderv";
    String OASYSDERV = "oasysderv";
}
