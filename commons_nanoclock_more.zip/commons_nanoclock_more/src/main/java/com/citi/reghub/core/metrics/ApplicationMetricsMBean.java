package com.citi.reghub.core.metrics;

import java.util.Iterator;
import java.util.Set;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.DynamicMBean;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.ReflectionException;

/**
 * JMX DynamicMBean to publish {@code Metric} interface as an attributes in JMX
 * 
 * @author Michael Rootman
 *
 */
public class ApplicationMetricsMBean implements DynamicMBean {
	private MetricsManager manager;

	public ApplicationMetricsMBean(MetricsManager manager) {
		if(manager ==null){
			throw new IllegalArgumentException("MetricManager cannot be null");
		}
		
		this.manager = manager;
	}

	@SuppressWarnings("rawtypes")
	public Object getAttribute(String attribute)
			throws AttributeNotFoundException, MBeanException, ReflectionException {

		Metric metric = manager.getMetric(attribute);
		if (metric == null) {
			throw new AttributeNotFoundException("No such property: " + attribute);
		}

		return metric.getValue();
	}

	public void setAttribute(Attribute attribute)
			throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {

		throw new UnsupportedOperationException("setAttribute is not supported");
	}

	public AttributeList getAttributes(String[] attributes) {
		AttributeList list = new AttributeList();
		for (String name : attributes) {
			Object value = manager.getMetric(name).getValue();
			list.add(new Attribute(name, value));
		}
		return list;
	}

	public AttributeList setAttributes(AttributeList attributes) {
		throw new UnsupportedOperationException("setAttributes is not supported");
	}

	public Object invoke(String actionName, Object[] params, String[] signature)
			throws MBeanException, ReflectionException {
		throw new UnsupportedOperationException("invoke is not supported");
	}

	public MBeanInfo getMBeanInfo() {
		Set<String> names = manager.getAllMetrics().keySet();

		MBeanAttributeInfo[] attrs = new MBeanAttributeInfo[names.size()];

		Iterator<String> it = names.iterator();
		for (int i = 0; i < attrs.length; i++) {
			String name = it.next();
			attrs[i] = new MBeanAttributeInfo(name, "java.lang.Object", "Property " + name, true, false, false);
		}

		return new MBeanInfo(this.getClass().getName(), "Application Metrics MBean", attrs, null, null, null);
	}

}
