package com.citi.reghub.core.rules.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonRulesClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonRulesClient.class);
	private static RulesClient instance;

	public static RulesClient getInstance() {
		if (instance == null) {
			LOGGER.error("RulesClient instance='{}'", instance, new RuntimeException("Instance of RulesClient  is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonRulesClient");
		}
		return instance;
	}

	public static void setInstance(RulesClientConfig config) {
		instance = new RulesClient(config);
	}

	public static void setInstance(RulesClient rulesClient) {
		instance = rulesClient;
	}
}
