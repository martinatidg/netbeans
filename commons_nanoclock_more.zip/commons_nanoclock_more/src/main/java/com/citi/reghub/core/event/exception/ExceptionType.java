package com.citi.reghub.core.event.exception;

public enum ExceptionType {
	DATA_QUALITY("data-quality"),
	NON_REPORTABLE("non-reportable"),
	APPLICATION("application"),
	NACK("nack");

	final String value;

	ExceptionType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ExceptionType fromValue(String v) {
		for (ExceptionType c : ExceptionType.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
