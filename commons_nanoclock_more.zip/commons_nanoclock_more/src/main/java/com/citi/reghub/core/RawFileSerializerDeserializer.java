package com.citi.reghub.core;

import java.io.ByteArrayOutputStream;
import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;
import com.esotericsoftware.kryo.serializers.FieldSerializer;

public class RawFileSerializerDeserializer implements Serializer<RawFile>, Deserializer<RawFile> {

	@SuppressWarnings("rawtypes")
	private ThreadLocal kryos = new ThreadLocal() {
		@Override
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			kryo.getFieldSerializerConfig()
					.setCachedFieldNameStrategy(FieldSerializer.CachedFieldNameStrategy.EXTENDED);
			CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, RawFile.class);
			kryo.register(RawFile.class, serializer);
			return kryo;
		}
	};

	@Override
	public byte[] serialize(String arg0, RawFile rawOutboundFile) {

		ByteArrayOutputStream baos = new ByteArrayOutputStream(1000000); 
		Output output = new Output(baos);

		((Kryo) kryos.get()).writeObject(output, rawOutboundFile);

		output.flush();
		return baos.toByteArray();
	}

	@Override
	public RawFile deserialize(String arg0, byte[] bytes) {
		Input input = null;
		try {
			input = new Input(bytes);
			RawFile rawOutbound = ((Kryo) kryos.get()).readObject(input, RawFile.class);
			input.close();
			return rawOutbound;
		} catch (Exception e) {
			if (input != null)
				input.close();
			throw new IllegalArgumentException("Error reading bytes", e);
		}
	}

	@Override
	public void close() {
		/**
		 * 
		 * Auto-generated method stub
		 */
	}

	@Override
	public void configure(Map<String, ?> arg0, boolean arg1) {
		/**
		 * 
		 * Auto-generated method stub
		 */
	}
}
