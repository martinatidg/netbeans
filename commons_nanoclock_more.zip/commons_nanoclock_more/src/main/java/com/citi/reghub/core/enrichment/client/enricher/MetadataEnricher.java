package com.citi.reghub.core.enrichment.client.enricher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.rules.client.DroolsEngine;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;

public class MetadataEnricher extends Enricher {

	private static final Logger LOGGER = LoggerFactory.getLogger(MetadataEnricher.class);

	@SuppressWarnings({"unchecked" })
	private Map<String, Object> getData(String lookupKey, String cacheName) {
		Map<String, Object> data = (HashMap<String, Object>) (StringUtils.isBlank(cacheName) ? clientConfig.getMetadataClient().get(lookupKey) : clientConfig.getMetadataClient().get(lookupKey,cacheName));
		if(data == null) {
			data = new HashMap<>();
		}
		return data;
	}

	public EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefereshCache) {
		LOGGER.debug("processing enrich, request with enricherConfig='{}', root='{}', forceRefreshCache='{}' initiated", enricherConfig, root, forceRefereshCache);
		Map<String, Object> metadata= getData((String)enricherConfig.configuration.get("lookupKey"),(String)enricherConfig.configuration.get("lookupCacheName"));
		Rule enrichmentRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName, (String)enricherConfig.configuration.get(UPDATE_DEFINITION), null, new ArrayList<>());
		RuleResult ruleResult =  DroolsEngine.getEngine().execute(enrichmentRule, root, metadata,forceRefereshCache);
		return new EnricherResult(ruleResult.ruleName, ruleResult.comments, ruleResult.value);
	}

}
