package com.citi.reghub.core.metrics;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generic implementation of {@link Metric} interface for Integer type of values
 * 
 * @author Michael Rootman
 *
 */
public class GenericMetric implements Metric<Integer> {

	private String name;
	private AtomicInteger counter = new AtomicInteger();

	/**
	 * Sets the name of the metric
	 * 
	 * @param name
	 *            Unique name of the metrics as it will be exposed in JMX bean.
	 *            Example: {@code "core.reportable.count"}
	 */
	public GenericMetric(String name) {
		if (name ==null || name.isEmpty()){
			throw new IllegalArgumentException("Metric name cannot be null or empty");
		}
		
		this.name = name;
	}

	public void setValue(Integer value) {
		if (value==null){
			throw new IllegalArgumentException("Metric value cannot be null");
		}
		
		counter.set(value);
	}

	public void addToValue(Integer addOn) {
		if (addOn==null){
			throw new IllegalArgumentException("Metric value cannot be null");
		}
		
		counter.addAndGet(addOn);
	}

	public Integer getValue() {
		return counter.getAndSet(0);
	}

	public String getName() {
		return name;
	}

}
