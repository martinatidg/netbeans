package com.citi.reghub.core.crypto.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.crypto.SecretKey;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public class FileStoreCipherClient extends AbstractCipherClient {
	
	public static final String KEY_FILE_PATH = "cipher.filestore.keyFilePath";
	private String keyFilePath;
	
    public static Logger LOGGER = LoggerFactory.getLogger(FileStoreCipherClient.class);

	public FileStoreCipherClient(Map<String,String> config, CacheClient cacheClient) {
		super(cacheClient);
		keyFilePath = config.get(KEY_FILE_PATH);
	}

	@Override
	public void generateAndStoreKey(String keyRef) {
		try (ObjectOutputStream keyWriter = new ObjectOutputStream(new FileOutputStream(new StringBuffer(keyFilePath).append(File.separator).append(keyRef).toString())))
		{
			SecretKey aesKey = super.generateKey();
			keyWriter.writeObject(aesKey);
		} catch (FileNotFoundException e) {
			LOGGER.error("Unable to store key at '{}'", keyFilePath, e);
			throw new RuntimeException("Cipher Key File Store Not Available/Accessible", e);
		} catch (IOException e) {
			LOGGER.error("Unable to store key at '{}'", keyFilePath, e);
			throw new RuntimeException("Cipher Key File Store Not Available/Accessible", e);
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error("Unable to generate key for keyReference '{}'", keyRef, e);
			throw new RuntimeException("Cipher Key Alogrithm Invalid", e);
		}
	}
	
	@Override
	public SecretKey getKey(String keyRef) {
    	LOGGER.debug("Processing get for Crypto Key with keyRef='{}'", keyRef);
        Object aesKeyObj = getFromCache(keyRef);
        if(aesKeyObj == null){
        	aesKeyObj = getFromFile(keyRef);
        }
        return (SecretKey)aesKeyObj;
	}
	
	private SecretKey getFromFile(String keyRef) {
		LOGGER.debug("Retrieving key from store for keyRef '{}'", keyRef);
		try (ObjectInputStream keyReader = new ObjectInputStream(new FileInputStream(new StringBuffer(keyFilePath).append(File.separator).append(keyRef).toString())))
		{
			SecretKey aesKey = (SecretKey)keyReader.readObject();
			putInCache(keyRef, aesKey);
			return aesKey;
		} catch (FileNotFoundException e) {
			LOGGER.error("Unable to find key for keyRef '{}' at '{}'", keyRef, keyFilePath, e);
		} catch (IOException e) {
			LOGGER.error("Unable to find key for keyRef '{}' at '{}'", keyRef, keyFilePath, e);
		} catch (ClassNotFoundException e) {
			LOGGER.error("Corrupted key found for keyRef '{}' at '{}'", keyRef, keyFilePath, e);
		}
		return null;
	}
}
