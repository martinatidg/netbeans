package com.citi.reghub.core.enrichment.client;

import java.util.ArrayList;
import java.util.List;

import com.citi.reghub.core.Audit;

public class EnrichmentResult {
	
	private List<EnricherResult> enricherResult = new ArrayList<>();
	

	public List<EnricherResult> getEnricherResult() {
		return enricherResult;
	}

	public void setEnricherResult(List<EnricherResult> enricherResult) {
		this.enricherResult = enricherResult;
	}
	
	public void add(EnricherResult enricherResult) {
		this.enricherResult.add(enricherResult);
	}
	
	public Audit toAudit(Audit audit){
		if(!enricherResult.isEmpty())
			enricherResult.forEach(r -> audit.info.put(r.enricherId, r.toMap(r)));
		return audit;
	}
	
}
