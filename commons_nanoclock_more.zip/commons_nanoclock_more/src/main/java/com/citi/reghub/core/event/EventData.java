package com.citi.reghub.core.event;

import java.io.Serializable;

public interface EventData extends Serializable {

}
