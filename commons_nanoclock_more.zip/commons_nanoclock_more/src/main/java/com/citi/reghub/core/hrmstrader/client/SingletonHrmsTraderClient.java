package com.citi.reghub.core.hrmstrader.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonHrmsTraderClient {

	private static HrmsTraderClient instance;
	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonHrmsTraderClient.class);

	public static HrmsTraderClient getInstance() {
		if (instance == null) {
			LOGGER.error("HrmsTraderClient instance='{}'", instance,
					new RuntimeException("Instance of HrmsTrader client is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonHrmsTraderClient");
		}
		return instance;
	}

	public static void setInstance(HrmsTraderClientConfig config) {
		instance = new HrmsTraderClient(config);
	}

}
