package com.citi.reghub.core.enrichment.client;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.metadata.client.MetadataClient;

public class EnrichmentPlanExecutor {

	RestClient restClient;
	MetadataClient metadataClient;
	EnrichmentClientConfig clientConfig;

	private static final Logger LOGGER = LoggerFactory.getLogger(EnrichmentPlanExecutor.class);

	public EnrichmentPlanExecutor setConfig(EnrichmentClientConfig config) {
		this.clientConfig = config;
		return this;
	}

	public EnrichmentResult execute(EnrichmentPlan enrichmentPlan, Object root, boolean forceRefereshCache) {
		LOGGER.debug("Processing execute request with enrichmentPlan='{}', root='{}', forceRefreshCache='{}'", enrichmentPlan, root, forceRefereshCache);
		EnrichmentResult result = new EnrichmentResult();

		List<EnricherResult> enricherResult = enrichmentPlan.enricherConfigs.stream().map(config -> EnricherFactory.getEnricher(config.type)
				.setConfig(clientConfig)
				.enrich(config, root, forceRefereshCache))
				.collect(Collectors.toList());

		result.setEnricherResult(enricherResult);
		return result;
	}

}
