
package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.cache.client.MapService;
import com.citi.ocean.cache.util.MapName;
import com.citi.ocean.dataobject.account.OceanAccountInfo;
import com.citi.ocean.dataobject.account.OceanAccountSummary;
import com.citi.ocean.dataobject.account.OceanGFCDetail;
import com.citi.ocean.dataobject.product.OceanProductSummary;

public class OceanGemfireCacheClient {

	public static final String ERROR_MSG = "Exception occurred while fetching response from Ocean Gemfire Region %s, Identifier %s, IdentifierValue %s, Error %s";

	private static final Logger LOGGER = LoggerFactory.getLogger(OceanGemfireCacheClient.class);

	private Map<Long, OceanProductSummary> productMap;
	
	private Map<String, OceanGFCDetail> gfcidMap;
	
	private Map<String, OceanAccountInfo> slangMap;

	private Map<String, String> config;

	public OceanGemfireCacheClient(final Map<String, String> config) {
		this.config = config;
		if (config != null && config.containsKey(RefdataClient.GEMFIRE_CACHE_XML_PATH)) {
			setCacheConfig(config.get(RefdataClient.GEMFIRE_CACHE_XML_PATH));
		} else {
			// set default gemfire config xml
			setCacheConfig(RefdataClient.GEMFIRE_CACHE_XML_VALUE);
		}
		initilizeGemfireCache();
	}

	private void initilizeGemfireCache() {
		try {
			gfcidMap = MapService.get(MapName.MAP_REFERENCE_GFCID);
		} catch (Exception e) {
			LOGGER.error("Error connecting Ocean Gemfire cache.", e);
		}
		try {
			slangMap = MapService.get(MapName.MAP_REFERENCE_ACCOUNT_SLANG);
		} catch (Exception e) {
			LOGGER.error("Error connecting Ocean Gemfire cache.", e);
		}
	}

	private void setCacheConfig(String cacheXmlValue) {
		System.setProperty(RefdataClient.GEMFIRE_CACHE_XML_KEY, cacheXmlValue);
	}

	public boolean isCacheAvailable() throws Exception {
		if (!isAlive()) {
			return reconnectGemfireCache();
		}
		return true;
	}

	private boolean reconnectGemfireCache() throws Exception {
		try {
			if (config != null && config.containsKey(RefdataClient.GEMFIRE_CACHE_XML_PATH)) {
				setCacheConfig(config.get(RefdataClient.GEMFIRE_CACHE_XML_PATH));
			} else {
				// set default gemfire config xml
				setCacheConfig(RefdataClient.GEMFIRE_CACHE_XML_VALUE);
			}
			initilizeGemfireCache();
			return true;
		} catch (Exception e) {
			LOGGER.error("Error connecting Ocean Gemfire cache.", e);
			throw e;
		}
	}

	public boolean isAlive() {
		if (productMap == null || gfcidMap == null || slangMap == null) {
			return false;
		} else {
			return true;
		}
	}
	
	public OceanProductSummary getByOceanProductId(Long oceanId) {
		try {
			isCacheAvailable();
			return productMap.get(oceanId);
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_OCEAN_PRODUCT, "OceanId",
					oceanId, e.getMessage()));
		}
	}
	
	public OceanProductSummary getProductsByFII(Long fii) {
		try {
			return MapService.getProductSummary(fii, MapName.MAP_REFERENCE_PRODUCT_FII);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_FII, "FII", fii, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsByCUSIP(String cusip) {
		try {
			return MapService.getProductSummary(cusip, MapName.MAP_REFERENCE_PRODUCT_CUSIP);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_CUSIP, "CUSIP", cusip, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsBySMCP(String smcp) {
		try {
			return MapService.getProductSummary(smcp, MapName.MAP_REFERENCE_PRODUCT_SMCP);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_SMCP, "SMCP", smcp, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsByISIN(String isin) {
		try {			
			return MapService.getProductSummary(isin, MapName.MAP_REFERENCE_ISIN_PRODUCT);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_ISIN_PRODUCT, "ISIN", isin, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsByRIC(String ric) {
		try {
			return MapService.getProductSummary(ric, "/ocean/reference/product/ric");
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, "/ocean/reference/product/ric", "RIC", ric, e.getMessage()));
		}
	}

	public OceanAccountSummary getAccountByOceanId(Long oceanId) {
		try {
			return MapService.getAccountSummary(oceanId, MapName.MAP_REFERENCE_ACCOUNT);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_ACCOUNT, "OCEAN_ID", oceanId, e.getMessage()));
		}
	}

	public OceanGFCDetail getAccountByGFCID(String gfcid) {
		try {
			return gfcidMap.get(gfcid);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_GFCID, "GFCID", gfcid, e.getMessage()));
		}
	}

	public OceanAccountSummary getAccountByMnemonic(String mnemonic) {
		try {
			return MapService.getAccountSummary(mnemonic, MapName.MAP_REFERENCE_ACCOUNT_ACCOUNT_MNEMONIC);
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_ACCOUNT_ACCOUNT_MNEMONIC,
					"MNEMONIC", mnemonic, e.getMessage()));
		}
	}

	public OceanAccountSummary getAccountByActi(Integer actid) {
		try {
			return MapService.getAccountSummary(actid, MapName.MAP_REFERENCE_ACCOUNT_ACTI);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_ACCOUNT_ACTI, "ACTID", actid, e.getMessage()));
		}
	}

	public OceanAccountInfo getAccountBySlang(String slang) {
		try {
			isCacheAvailable();
			return slangMap.get(slang);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format(ERROR_MSG, MapName.MAP_REFERENCE_ACCOUNT_SLANG, "SLANG", slang, e.getMessage()));
		}
	}
}