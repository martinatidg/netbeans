package com.citi.reghub.core.constants;

public interface AuditTags {

	String SOURCE = "SOURCE";
	String RULE = "RULE";
	String ENRICHMENT = "ENRICHMENT";
	String SEQUENCING = "SEQUENCING";
	String USER = "USER";
	String SYSTEM = "SYSTEM";
	String REPORT = "REPORT";
	String RESPONSE = "RESPONSE";
	
	String OCEAN = "OCEAN";
}
