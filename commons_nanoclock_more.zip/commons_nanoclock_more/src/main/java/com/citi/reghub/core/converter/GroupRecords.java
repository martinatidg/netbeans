package com.citi.reghub.core.converter;

import java.util.List;
import java.util.Map;

import com.citi.reghub.core.Entity;

public interface GroupRecords {
	public Map<String, List<Entity>> groupRecordsFromList(List<Entity> entities);
}
