package com.citi.reghub.core.enrichment.client.enricher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.hrmstrader.client.HrmsTraderClient;
import com.citi.reghub.core.rules.client.DroolsEngine;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;

public class HRMSTraderEnricher extends Enricher {

	public static final String LOOK_UP_KEY_DEFINITION = "lookupKeyDefinition";
	public static final String HRMS_TRADER = "HRMS_TRADER";

	private static final Logger LOGGER = LoggerFactory.getLogger(RefDataEnricher.class);

	@Override
	public EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefreshCache) {

		LOGGER.debug("processing hrms trader enrich, request with enricherConfig='{}', root='{}', forceRefreshCache='{}' initiated",
				enricherConfig, root, forceRefreshCache);

		Rule lookupKeyRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName + "_lookup",
				(String) enricherConfig.configuration.get(LOOK_UP_KEY_DEFINITION), null, new ArrayList<>());

		Map<String, Object> metadata = new HashMap<String, Object>();

		RuleResult keyLookUpRuleResult = DroolsEngine.getEngine().execute(lookupKeyRule, root, metadata,
				forceRefreshCache);

		if (keyLookUpRuleResult.value == null) {
			return new EnricherResult(keyLookUpRuleResult.ruleName,
					"Enrichment lookup rule failed, skiping enrichment.", keyLookUpRuleResult.value);
		}

		if (keyLookUpRuleResult.value instanceof Map) {
			Map<String, Object> refdata = getData((HashMap<String, Object>) keyLookUpRuleResult.value);

			Rule enrichmentRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName,
					(String) enricherConfig.configuration.get(UPDATE_DEFINITION), null, new ArrayList<>());

			RuleResult enrichmentRuleResult = DroolsEngine.getEngine().execute(enrichmentRule, root, refdata,
					forceRefreshCache);

			return new EnricherResult(enrichmentRuleResult.ruleName, enrichmentRuleResult.comments,
					enrichmentRuleResult.value);
		} else {
			return new EnricherResult(keyLookUpRuleResult.ruleName, keyLookUpRuleResult.comments,
					keyLookUpRuleResult.value);
		}
	}

	private Map<String, Object> getData(Map<String, Object> input) {
		LOGGER.debug("Fetching HRMS Trader details for input='{}'", input);
		HrmsTraderClient hrmsClient = clientConfig.getHrmsTraderClient();
		String lookupKeyValue = (String) input.get("lookupKeyValue");
		try {
			return hrmsClient.getTrader(lookupKeyValue);	
		} catch (Exception e) {
			LOGGER.error("Error getting data for traderId " + lookupKeyValue, e);
			return null;
		}
		
	}

}
