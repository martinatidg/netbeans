package com.citi.reghub.core;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonUtils {

	public static Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);

	public static Map<String, Object> objectToMap(Object inputPojo) {
		Map<String, Object> objectAsMap = new HashMap<String, Object>();
		if (inputPojo == null)
			return objectAsMap;
		try {
			for (Field field : getAllFields(new LinkedList<Field>(), inputPojo.getClass())) {
				field.setAccessible(true);
				if (field.get(inputPojo) == null) {
					objectAsMap.put(field.getName(), field.get(inputPojo));
				} else if (field.getType().isPrimitive()) {
					objectAsMap.put(field.getName(), field.get(inputPojo));
				} else if (field.getType().getName().equals("java.util.Date")) {
					convertToJava8Date(objectAsMap, field.getName(), (Date) field.get(inputPojo));
				} else if (field.getType().getName().equals("java.lang.Double")) {
					objectAsMap.put(field.getName(), BigDecimal.valueOf((Double) field.get(inputPojo)));
				} else if (field.getType().getName().startsWith("java.lang.")
						|| field.getType().getName().startsWith("java.util.")
						|| field.getType().getName().startsWith("java.math.")
						|| field.getType().getName().startsWith("java.time.")) {
					objectAsMap.put(field.getName(), field.get(inputPojo));
				} else {
					objectAsMap.put(field.getName(), objectToMap(field.get(inputPojo)));
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error converting given object to Map", e);
			throw new RuntimeException("Error converting given object to Map", e);
		}
		return objectAsMap;
	}

	private static void convertToJava8Date(Map<String, Object> objectAsMap, String fieldName, Date date) {
		if (fieldName.toLowerCase().endsWith("ts")) {
			objectAsMap.put(fieldName, utilDateToLocalDateTime(date));
		} else {
			objectAsMap.put(fieldName, utilDateToLocalDate(date));
		}
	}

	private static List<Field> getAllFields(List<Field> fields, Class<?> type) {
		fields.addAll(Arrays.asList(type.getDeclaredFields()));

		if (type.getSuperclass() != null) {
			getAllFields(fields, type.getSuperclass());
		}

		return fields;
	}

	public static LocalDateTime utilDateToLocalDateTime(Date date) {
		Instant instant = Instant.ofEpochMilli(date.getTime());
		return instant.atZone(ZoneOffset.UTC).toLocalDateTime();
	}

	public static LocalDate utilDateToLocalDate(Date date) {
		Instant instant = Instant.ofEpochMilli(date.getTime());
		return instant.atZone(ZoneOffset.UTC).toLocalDate();
	}

}
