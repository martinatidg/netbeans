package com.citi.reghub.core.converter;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class LongToLocalDateTimeDeserializer extends StdDeserializer<LocalDateTime> {

	public LongToLocalDateTimeDeserializer(Class<LocalDateTime> vc) {
		super(vc);
	}

	private static final long serialVersionUID = 1L;

	@Override
	public LocalDateTime deserialize(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext)
			throws IOException, JsonProcessingException {
		Long time = paramJsonParser.getLongValue();
		Long timeInMillis = time / 1000000;
		Integer timeInNanos = (int) (time % 1000000000);

		Instant inst = Instant.ofEpochMilli(timeInMillis);
		LocalDateTime ldt = LocalDateTime.ofInstant(inst, Clock.systemUTC().getZone());
		return ldt.withNano(timeInNanos);
	}
}