package com.citi.reghub.core.cache.client;

import com.citi.reghub.core.EntityCacheSeqDetails;
import com.hazelcast.nio.serialization.Portable;
import com.hazelcast.nio.serialization.PortableFactory;

public class CustomPortableFactory implements PortableFactory {

	  @Override
	  public Portable create( int classId ) {
	    if (classId == 1 )
	      return new EntityCacheSeqDetails();
	    else
	      return null;
	  }
	}