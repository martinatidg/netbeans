package com.citi.reghub.core.hrmstrader.client;

import com.citi.reghub.core.cache.client.CacheClient;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HrmsTraderClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(HrmsTraderClient.class);

    private static final String CACHE_HRMSTRADER_COLLECTION = "all_all_hrms_traders";
    private static final String CACHE_HRMSTRADER_COLLECTION_TYPE = "Map";

    public static final String HRMS_TRADER_MAP_KEY = "hrms_trader";

    private final Map						props;
    private final HrmsTraderClientConfig 	hrmsTraderClientConfig;
    private final CacheClient 				cacheClient;

    public HrmsTraderClient(HrmsTraderClientConfig hrmsTraderClientConfig) {
        if(hrmsTraderClientConfig == null) {
        	LOGGER.warn("Provided hrmsTrader client config is null, using default configuration");
        }
        
        this.hrmsTraderClientConfig = (hrmsTraderClientConfig == null ? new HrmsTraderClientConfig() :  hrmsTraderClientConfig);
        
        if (!this.hrmsTraderClientConfig.containsKey(HrmsTraderClientConfig.HRMSTRADER_URL_KEY)) {
        	this.hrmsTraderClientConfig.setDefaultHrmsTraderUrl();
        }
        
        this.cacheClient = this.hrmsTraderClientConfig.getCacheClient();
        this.props = prepareCacheClientConfig();
        
        LOGGER.info("Instantialised HrmsTrader Client with configuration='{}'", hrmsTraderClientConfig);
    }

    @SuppressWarnings("unchecked")
	public Map<String,Object> getTrader(String traderIdentifier) {
    	final boolean debug = LOGGER.isDebugEnabled();
    	if (debug) {
    		LOGGER.debug("Processing getTrader for hrmsTrader with traderIdentifier='{}'", traderIdentifier);
    	}
    	
		Object trader = getFromCache(traderIdentifier);
		
		if (debug) {
			LOGGER.debug("Found trader in cache ='{}'", trader);
		}
		
		if(trader == null){
			trader = getFromService(traderIdentifier);
			if (debug) {
				LOGGER.debug("Got trader from service ='{}'", trader);
			}
		}

		return (Map<String,Object>)trader;
    }

    private Object getFromCache(String traderIdentifier) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing getFromCache for hrmsTrader with traderIdentifier='{}'", traderIdentifier);
    	}

    	return cacheClient.get(traderIdentifier, this.props);
    }

    @SuppressWarnings("unchecked")
	private Map<String,Object> getFromService(String traderIdentifier) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing getFromService for hrmsTrader with id", traderIdentifier);
    	}
    	
        if (hrmsTraderClientConfig.getRestClient() == null) {
        	RuntimeException ex = new RuntimeException("Invalid Rest client for hrmsTrader");
        	LOGGER.error("HTTP_CLIENT has not be set with traderIdentifier='{}'", traderIdentifier, ex);
        	throw ex;
        }
        
        Map<String,Object> traderInfo = hrmsTraderClientConfig.getRestClient().get(prepareHrmsTraderUrl(hrmsTraderClientConfig.getTraderInfoServiceURI(), traderIdentifier), Map.class);
        if(traderInfo == null) {
            RuntimeException ex = new RuntimeException("Invalid trader identifier has been provided");
            LOGGER.error("Get request with traderIdentifier='{}'", traderIdentifier, ex);
            throw ex;
        }
        
        Map<String, Object> trader = new HashMap<String,Object>();
        trader.put(HRMS_TRADER_MAP_KEY, traderInfo);
        putInCache(traderIdentifier, trader);
        return trader;
    }

    private String prepareHrmsTraderUrl(String serviceURI, String traderIdentifier) {
        return String.format(hrmsTraderClientConfig.getHrmsTraderUrl(), serviceURI, traderIdentifier);
    }

    private void putInCache(String traderIdentifier,Object trader){
        cacheClient.put(traderIdentifier, trader, this.props);

        if (LOGGER.isTraceEnabled()) {
        	LOGGER.trace("Processed put for traderIdentifier='{}', trader='{}'", traderIdentifier, trader);
        }
    }
    
    public HrmsTraderClientConfig getHrmsTraderClientConfig() {
    	return hrmsTraderClientConfig;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private static final Map prepareCacheClientConfig(){
        Map props = new HashMap<>();
        props.put(CacheClient.CACHE_COLLECTION_NAME, CACHE_HRMSTRADER_COLLECTION);
        props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_HRMSTRADER_COLLECTION_TYPE);
        return props;
    }

}