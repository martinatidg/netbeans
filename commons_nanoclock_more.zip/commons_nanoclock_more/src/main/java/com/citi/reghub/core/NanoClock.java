package com.citi.reghub.core;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class NanoClock extends Clock {
	private static final long NANOSECONDS = 1000_000L;
	private static final int MAX_DATE_LENGTH = 14;

	private final Clock clock;

	private final long initialNanos;

	private final Instant initialInstant;

	public NanoClock() {
		this(Clock.systemUTC());
	}

	public NanoClock(final Clock clock) {
		this.clock = clock;
		initialInstant = clock.instant();
		initialNanos = getSystemNanos();
	}

	@Override
	public ZoneId getZone() {
		return clock.getZone();
	}

	@Override
	public Instant instant() {
		return initialInstant.plusNanos(getSystemNanos() - initialNanos);
	}

	@Override
	public Clock withZone(final ZoneId zone) {
		return new NanoClock(clock.withZone(zone));
	}

	public LocalDateTime now() {
		LocalDateTime ldt = LocalDateTime.ofInstant(instant(), getZone());
		return ldt.withNano(instant().getNano());
	}

	private long getSystemNanos() {
		return System.nanoTime();
	}

	/**
	 * @return the current time stamp in nanoseconds
	 */
	public static Long currentNanoTimeStamp() {
		LocalDateTime currentTs = LocalDateTime.now();
		return dateToNanoTimeStamp(currentTs);
	}

	/**
	 * Convert a LocalDateTime instance to nanosecond time stamp.
	 * 
	 * @param ldateTime,
	 *            a LocalDateTime instance
	 * @return nanosecond time stamp converted from the LocalDateTime instance
	 */
	public static Long dateToNanoTimeStamp(LocalDateTime ldateTime) {
		long epochSec = ldateTime.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
		Integer nanos = ldateTime.getNano();

		return epochSec * 1000000000 + nanos;
	}

	/**
	 * Convert millisecond time stamp to nanosecond time stamp.
	 * 
	 * @param millisecond,
	 *            millisecond time stamp
	 * @return nanosecond time stamp converted from millisecond time stamp
	 */
	public static Long convertMilliToNano(Long millisecond) {
		if (millisecond == null) {
			return null;
		}

		// if length is greater than 13, than it's nano seconds
		int length = String.valueOf(millisecond).length();

		return length < MAX_DATE_LENGTH ? millisecond * NANOSECONDS : millisecond;
	}

	/**
	 * Convert a nanosecond time stamp to LocalDateTime.
	 * 
	 * @param timeInLong, time stamp in nanoseconds.
	 * @return an LocalDateTime instance converted from the nanosecond time stamp
	 */
	public static LocalDateTime convertNanoTimeStampToLocalDateTime(Long timeInLong) {
		Long timeInMillis = timeInLong / 1000000;
		Integer timeInNanos = (int) (timeInLong % 1000000000);
		Instant inst = Instant.ofEpochMilli(timeInMillis);
		LocalDateTime ldt = LocalDateTime.ofInstant(inst, Clock.systemUTC().getZone());
		ldt = ldt.withNano(timeInNanos);
		return ldt;
	}
}
