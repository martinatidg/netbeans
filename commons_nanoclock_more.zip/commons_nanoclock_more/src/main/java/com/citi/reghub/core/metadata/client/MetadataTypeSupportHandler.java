package com.citi.reghub.core.metadata.client;

import java.util.HashMap;
import java.util.Map;

import com.citi.reghub.core.converter.BigDecimalConverter;
import com.citi.reghub.core.converter.BigIntegerConverter;
import com.citi.reghub.core.converter.DoubleConverter;
import com.citi.reghub.core.converter.FloatConverter;
import com.citi.reghub.core.converter.IntegerConverter;
import com.citi.reghub.core.converter.LocalDateConverter;
import com.citi.reghub.core.converter.LocalDateTimeConverter;
import com.citi.reghub.core.converter.LongConverter;
import com.citi.reghub.core.converter.TypeConverter;

public class MetadataTypeSupportHandler {
	
	public static Map<String,TypeConverter> converters;
	
	static {
		converters = new HashMap<String, TypeConverter>();
		converters.put("Integer", new IntegerConverter());
		converters.put("Long", new LongConverter());
		converters.put("Float", new FloatConverter());
		converters.put("Double", new DoubleConverter());
		converters.put("BigDecimal", new BigDecimalConverter());
		converters.put("BigInteger", new BigIntegerConverter());
		converters.put("LocalDate", new LocalDateConverter());
		converters.put("LocalDateTime", new LocalDateTimeConverter());
	}
	
	private Object value;
	private String dataType;
	private String format;
	
	public MetadataTypeSupportHandler(Map map){
		this.value = map.get("value");
		this.dataType = (String) map.get("dataType");
		this.format = (String) map.get("format");
	}
	
	public Object getValue(){
		Object retValue = value;
		if(value instanceof String && dataType != null){
			retValue = converters.get(dataType).convert(value, format);	
		}
		return retValue;
	}

}
