package com.citi.reghub.core.exception.client;

import java.util.List;

public class AggregatePostResponse { 
	
	
	private boolean success;
	private String  errorMessage;
	private List<AggregateValue> aggregateValues;
	
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<AggregateValue> getAggregateValues() {
		return aggregateValues;
	}
	public void setAggregateValues(List<AggregateValue> aggregateValues) {
		this.aggregateValues = aggregateValues;
	}
	
	
	
}
