package com.citi.reghub.core.metrics;

/**
 *Interface to be implemented by all Metrcis classes 
 *
 * 
 * @author Michael Rootman
 *
 * @param <V>
 */
public interface Metric<V extends Number> {

	void setValue(V value);

	V getValue();

	void addToValue(V addOn);

	String getName();

}
