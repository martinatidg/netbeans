package com.citi.reghub.core.converter;

import java.io.IOException;

public interface GenerateByteFileFromString {
	public byte[] generateByteArray(String data) throws IOException;

}
