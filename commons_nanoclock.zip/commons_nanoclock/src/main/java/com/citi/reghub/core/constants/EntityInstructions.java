package com.citi.reghub.core.constants;

public interface EntityInstructions {

    String OVERRIDDEN = "OVERRIDDEN";
}
