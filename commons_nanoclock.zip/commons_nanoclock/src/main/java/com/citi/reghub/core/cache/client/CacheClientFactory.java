package com.citi.reghub.core.cache.client;

import java.util.Map;

import com.hazelcast.core.Hazelcast;

public class CacheClientFactory {

	public static final String CACHE_PROVIDER = "cache.provider";
	public static final String HAZELCAST_CACHE = "hazelcast";

	public static CacheClient getInstance(Map<String, String> props) {
		String cacheProvider = props.get(CACHE_PROVIDER);
		
		if (HAZELCAST_CACHE.equals(cacheProvider) && "localhost:5701".equals(props.get("hazelcast.network.address"))) {
			HazelcastCacheClient cacheClient = new HazelcastCacheClient(props);
			if(!cacheClient.isAlive()){
				Hazelcast.newHazelcastInstance();
				cacheClient = new HazelcastCacheClient(props);
			}
			return cacheClient;
		} else if (HAZELCAST_CACHE.equals(cacheProvider)) {
			return new HazelcastCacheClient(props);
		} else {
			throw new InvalidConfigurationException("Invalid cache.provider " + cacheProvider);
		}
	}
}
