package com.citi.reghub.core.constants;

public interface FlatFileConstants {

	String PARENT_FILE_REG_HUB_ID = "ParentFileRegHubId";
	String FLATFILE_HEADER = "header";
	String FILE_RECIVED_TS = "FileRecivedTS";
}
