package com.citi.reghub.core.entity.client;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.fasterxml.jackson.core.JsonProcessingException;


public class EntityClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(EntityClient.class);

	private EntityClientConfig config;

	public EntityClient(EntityClientConfig entityClientConfig) {
		if(entityClientConfig == null) {
			LOGGER.warn("Entity client config passed is null, using default configuration");
		}
		
		this.config = (entityClientConfig == null ? new EntityClientConfig() : entityClientConfig);
		
		if (!this.config.containsKey(MetadataClientConfig.METADATA_URL_KEY)) {
			this.config.setDefaultMetadataUrl();
		}
		
		LOGGER.info("Instantiated Enrichment client instance with config='{}'", entityClientConfig);
	}

	private String prepareEntityUrl(String metadataName) {
		return String.format(config.getEntityUrl(), metadataName);
	}

	public Entity getOverriddenEntityFromService(String reghubId) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Hitting Entity Service for reghubId='{}'", reghubId);
		}

		return (Entity) config.getRestClient().get(prepareEntityUrl(reghubId), Entity.class);
	}
	
	public Entity getEntityFromReghubId(String reghubId,String stream, String flow) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Hitting Entity Service for reghubId='{1}', stream={2} and flow={3}", reghubId,stream, flow);
		}
		
		Entity entity = (Entity) config.getRestClient().get(MessageFormat.format(config.getEntityUrl(), reghubId,stream, flow), Entity.class);
		
		if (entity != null && entity.regHubId != null)
			return entity;
		else
			return null;
	}

	public List<Map> getEntitySourceUIdsByReghubIds(Map payload) throws JsonProcessingException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Hitting Entity Service for payload='{}'", payload);
		}

		List<Map> entity =  config.getRestClient().doPostReturnValues(payload , config.getEntityUrl(), Map.class);
		if (entity == null){
			RuntimeException ex = new RuntimeException("Entity Not found for the specified payload");
			LOGGER.error("Entity not found for the payload='{}'", payload, ex);
			throw ex;
		}

		return entity;
	}

	public Entity getLatestReportedEntityBySourceId(String sourceId , String stream , String flow) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Hitting Entity Service for sourceId='{}', stream='{}', flow='{}'", sourceId, stream, flow);
		}

		StringBuilder sb = new StringBuilder();
		sb.append("?stream=").append(stream)
			.append("&flow=").append(flow)
			.append("&sourceId=").append(sourceId)
			.append("&status=").append(EntityStatus.REPORTED)
			.append("&limit=1");

		List<Entity> entity = (List<Entity>) config.getRestClient().getValues(config.getEntityUrl()+sb.toString(), Entity.class);
		
		return entity.get(0);
	}

	public Entity getLatestEntityBySourceId(String sourceId) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Hitting Entity Service for sourceId='{}'", sourceId);
		}

		StringBuilder sb = new StringBuilder();
		sb.append("?sourceId=").append(sourceId)
			.append("&limit=1")
			.append("&summaryView=").append(false);
			
		List<Entity> entity = (List<Entity>) config.getRestClient().getValues(config.getEntityUrl()+sb.toString(), Entity.class);

		return entity.get(0);
	}
}
