package com.citi.reghub.core;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.google.common.base.CaseFormat;

public abstract class InfoablePojo extends GenericToString {
	
	public Map<String,Object> info = new HashMap<String,Object>();

	public String getString(String key){
		return (String) info.get(key);
	}
	public Integer getInteger(String key){
		return (Integer) info.get(key);
	}
	public Long getLong(String key){
		return (Long) info.get(key);
	}
	public Double getDouble(String key){
		return (Double) info.get(key);
	}
	public BigDecimal getBigDecimal(String key){
		return (BigDecimal) info.get(key);
	}
	public LocalDate getLocalDate(String key){
		return (LocalDate) info.get(key);
	}
	public LocalDateTime getLocalDateTime(String key){
		return (LocalDateTime) info.get(key);
	}


	public static String convertSnakeToCamelCase(String arg){
		return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, arg);
	}
}
