package com.citi.reghub.core;

import java.io.ByteArrayOutputStream;
import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;
import com.esotericsoftware.kryo.serializers.FieldSerializer;

@Deprecated
/**Use RawFileSerializerDeserializer instead of this*/
public class RawOutboundFileSerializerDeserializer implements Serializer<RawOutboundFile>, Deserializer<RawOutboundFile> {

	@SuppressWarnings("rawtypes")
	private ThreadLocal kryos = new ThreadLocal() {
		@Override
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			kryo.getFieldSerializerConfig().setCachedFieldNameStrategy(FieldSerializer.CachedFieldNameStrategy.EXTENDED);
            CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, RawOutboundFile.class);
            kryo.register(RawOutboundFile.class, serializer);
			return kryo;
		}
	};

	@Override
	public byte[] serialize(String arg0, RawOutboundFile rawOutboundFile) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(1000000); 
		Output output = new Output(baos);
		((Kryo) kryos.get()).writeObject(output, rawOutboundFile);
		output.flush();
		return baos.toByteArray();
	}
	
	@Override
	public RawOutboundFile deserialize(String arg0, byte[] bytes) {
		try {
			Input input = new Input(bytes);
			RawOutboundFile rawOutbound = ((Kryo) kryos.get()).readObject(input, RawOutboundFile.class);
			input.close();
			return rawOutbound;
		} catch (Exception e) {
			throw new IllegalArgumentException("Error reading bytes", e);
		}
	}

	@Override
	public void close() {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}

	@Override
	public void configure(Map<String, ?> arg0, boolean arg1) {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}
}
