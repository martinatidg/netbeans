package com.citi.reghub.core;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;
import com.esotericsoftware.kryo.serializers.FieldSerializer;

public class EntityKafkaSerializerDeserializer implements Serializer<Entity>, Deserializer<Entity>{
	
	@SuppressWarnings("rawtypes")
	protected ThreadLocal kryos = new ThreadLocal() {
        @Override
		protected Kryo initialValue() {
            Kryo kryo = new Kryo();
            kryo.getFieldSerializerConfig().setCachedFieldNameStrategy(FieldSerializer.CachedFieldNameStrategy.EXTENDED);
            CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, Entity.class);
            kryo.register(Entity.class, serializer);
            return kryo;
        }
    };
    
   @Override
	public byte[] serialize(String arg0, Entity entity) {
		Output output = new ByteBufferOutput(24576); // Setting buffer size 24KB
		((Kryo) kryos.get()).writeObject(output, entity);
		output.flush();
		return output.toBytes();
	}

	@Override
	public Entity deserialize(String arg0, byte[] bytes) {
		try {
			Input input = new Input(bytes);
			Entity entity = ((Kryo) kryos.get()).readObject(input, Entity.class);
			input.close();
			return entity;
        }
        catch(Exception e) {
            throw new IllegalArgumentException("Error reading bytes",e);
        }
	}
    
	@Override
	public void close() {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}

	@Override
	public void configure(Map<String, ?> arg0, boolean arg1) {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}

}
