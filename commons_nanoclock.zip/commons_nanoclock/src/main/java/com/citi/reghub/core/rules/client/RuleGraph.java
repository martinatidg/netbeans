package com.citi.reghub.core.rules.client;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.AuditTags;
import com.citi.reghub.core.constants.EventTypes;

public class RuleGraph implements Serializable {

    private static final long serialVersionUID = -3480981365171954276L;
	public String id;
    public String name;
    public String type;
    public String description;
    public String group;
    private String	version;
    
    public List<Rule> rules;
    
    public RuleGraph() {
    	rules = new ArrayList<Rule>();
    }

    public RuleGraph(String id, String name, String type, List<Rule> rules, String	version) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.rules = rules;
        this.version = version;
    }
    
    public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public RuleGraphResult execute(Object root, Map<String, Object> data, boolean forceRefreshCache) {
		RuleGraphResult result = new RuleGraphResult(rules.size());

		for (Rule r : rules) {
			result.addRuleResult(r.execute(root, data, forceRefreshCache));
		}

		result.markRuleResult();
		
		return result;
	}

	public Audit toAudit(Audit audit) {
		String event = EventTypes.RULE_GRAPH_EXECUTION + " : " + this.name;
		audit.event = event;
		audit.tags.add(AuditTags.RULE);
		audit.setVersion(getVersion());		
		return audit;
	}
}

