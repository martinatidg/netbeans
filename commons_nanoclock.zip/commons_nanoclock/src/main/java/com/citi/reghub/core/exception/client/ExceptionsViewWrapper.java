package com.citi.reghub.core.exception.client;

import java.util.ArrayList;
import java.util.List;

import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ExceptionsViewWrapper {
	
    private List<ExceptionMessage> exceptionsList = new ArrayList<>();
	
	private long totalRecords;
	
	public ExceptionsViewWrapper(){
		//Default constructor. nothing to do here.
	}
	
	
	public List<ExceptionMessage> getExceptionsList() {
		return exceptionsList;
	}

	public void setExceptionsList(List<ExceptionMessage> exceptionsList) {
		this.exceptionsList = exceptionsList;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}

}
