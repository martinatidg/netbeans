package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.dataobject.account.OceanAccountInfo;
import com.citi.ocean.dataobject.account.OceanAccountSummary;
import com.citi.ocean.dataobject.account.OceanGFCDetail;
import com.citi.reghub.core.CommonUtils;

public class RefdataAccountClient implements RefdataInterface {

	public static Logger LOGGER = LoggerFactory.getLogger(RefdataAccountClient.class);

	private final OceanGemfireCacheClient oceanGemfireCacheClient;

	public RefdataAccountClient(final OceanGemfireCacheClient oceanGemfireCacheClient) {
		this.oceanGemfireCacheClient = oceanGemfireCacheClient;
	}

	@Override
	public Map<String, Object> getData(String identifier, Object value) {
		try {
			AccountIdentifier inputIdentifier = AccountIdentifier.valueOf(identifier.toUpperCase());

			switch (inputIdentifier) {
			case OCEAN_ID:
				return getAccountDetailsByOceanId(value);
			case GFC:
			case GFCID:
				return getAccountDetailsByGFCID(value);
			case ACTID:
				return getAccountDetailsByActi(value);
			case SLANG:
				return getAccountDetailsBySlang(value);
			case MNEMONIC:
			case ACCOUNTMNEMONIC:
				return getAccountDetailsByMnemonic(value);
			}
			return null;
		} catch (IllegalArgumentException e) {
			LOGGER.error("Invalid input Account Identifier: '{}'", identifier, e);
			throw new RuntimeException("Invalid input Account Identifier: " + identifier
					+ " supported Account Identifier are " + AccountIdentifier.values().toString());
		}
	}

	private Map<String, Object> getAccountDetailsByOceanId(Object inpOceanId) {
		Long oceanId = Long.parseLong(inpOceanId.toString());
		OceanAccountSummary response = oceanGemfireCacheClient.getAccountByOceanId(oceanId);
		return CommonUtils.objectToMap(response);
	}
	
	private Map<String, Object> getAccountDetailsByGFCID(Object gfcid) {
		OceanGFCDetail response = oceanGemfireCacheClient.getAccountByGFCID(gfcid.toString());
		return CommonUtils.objectToMap(response);
	}

	private Map<String, Object> getAccountDetailsByMnemonic(Object mnemonic) {
		OceanAccountSummary response = oceanGemfireCacheClient.getAccountByMnemonic(mnemonic.toString());
		return CommonUtils.objectToMap(response);
	}

	private Map<String, Object> getAccountDetailsByActi(Object acti) {
		OceanAccountSummary response = oceanGemfireCacheClient.getAccountByActi(Integer.parseInt(acti.toString()));
		return CommonUtils.objectToMap(response);
	}

	private Map<String, Object> getAccountDetailsBySlang(Object slang) {
		OceanAccountInfo response = oceanGemfireCacheClient.getAccountBySlang(slang.toString());
		return CommonUtils.objectToMap(response);
	}
}
