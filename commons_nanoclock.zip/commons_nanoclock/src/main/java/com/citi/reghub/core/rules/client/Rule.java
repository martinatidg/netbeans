package com.citi.reghub.core.rules.client;

import  static com.citi.reghub.core.constants.EntityStatus.APP_EXCEPTION;
import  static com.citi.reghub.core.constants.EntityStatus.BIZ_EXCEPTION;
import  static com.citi.reghub.core.constants.EntityStatus.NON_REPORTABLE;
import  static com.citi.reghub.core.constants.EntityStatus.REPORTABLE;
import  static com.citi.reghub.core.constants.EntityStatus.TECH_EXCEPTION;
import static com.citi.reghub.core.constants.RuleTagConstants.LEVEL_WARNING;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_APPLICATION;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_DATA_QULAITY;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_NON_REPORTABLE;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_TECHNICAL;

import java.io.Serializable;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.citi.reghub.core.metadata.client.Metadata;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;

public class Rule implements Serializable{

	private static final long serialVersionUID = 7010474213401941083L;
	
	private static final Map<String, String> STATUS_MAP;
	
	static {
		Map<String, String> m = new HashMap<String, String>(4);
		m.put(TYPE_APPLICATION, APP_EXCEPTION);
		m.put(TYPE_NON_REPORTABLE, NON_REPORTABLE);
		m.put(TYPE_DATA_QULAITY, BIZ_EXCEPTION);
		m.put(TYPE_TECHNICAL, TECH_EXCEPTION);
		
		STATUS_MAP = Collections.unmodifiableMap(m);
	}
	
	public  String 			id;
	public  String 			name;
	public  String 			definition;
	public  String 			resultCode;
	public  List<Metadata>	metadata;
	
	private String 			type;
	private String 			level;
	private String 			version;
	private List<String> 	attributes;

	public Rule() {
	}

	public Rule(String ruleId, String name, String definition, String resultCode, List<Metadata> metadata) {
		this.id = ruleId;
		this.name = name;
		this.definition = definition;
		this.metadata = metadata;
		this.resultCode = resultCode;
	}

	public RuleResult execute(Object root, Map<String, Object> data, boolean forceRefereshCache) {
		for (Metadata m : this.metadata) {
			data.put(m.key, fetchMetadata(m));
		}

		RuleResult ruleResult = DroolsEngine.getEngine().execute(this, root, data, forceRefereshCache);

		deduceReportingStatus(ruleResult);

		if (!ruleResult.isReportable() && ruleResult.code == null) {
			ruleResult.code = resultCode;
		}

		return ruleResult;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getVersion() {
		return this.version;
	}

	public void setAttributes(List<String> attributes) {
		this.attributes = attributes;
	}

	public List<String> getAttributes() {
		return this.attributes;
	}
	
	protected Object fetchMetadata(Metadata m) {
		if(StringUtils.isBlank(m.getCacheName()))
			return SingletonMetadataClient.getInstance().get(m.name);
		else
			return SingletonMetadataClient.getInstance().get(m.name,m.getCacheName());
	}

	public String getBase64DecodedDefinition() {
		return new String(Base64.getDecoder().decode(definition));
	}
	
	private void deduceReportingStatus(RuleResult result) {
		if (!result.useRulePrecedence() || !result.hasFailed()) {
			return;
		}
		
		if (StringUtils.isEmpty(level) || StringUtils.isEmpty(type)) {
			return;
		}
		
		if (LEVEL_WARNING.equalsIgnoreCase(level)) {
			result.status = REPORTABLE;
		} else {
			String st = STATUS_MAP.get(type);
			if (st != null) {
				result.status = st;
			}
		}
	}
}
