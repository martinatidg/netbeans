package com.citi.reghub.core.metadata.client;

import java.util.Map;

public class Metadata {

	public String key;
	public String name;
    public Object value;
	private String	version;
	private String cacheName;
    
    public Metadata(){
    	
    }
    
    public Metadata(String name, String key){
    	this.name = name;
    	this.key = key;
    }
    
    public Metadata(String name, String key, String version, String cacheName){
    	this.name = name;
    	this.key = key;
    	this.version = version;
    	this.cacheName = cacheName;
    }
        
    public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Metadata(Map map){
    	if(map != null && !map.isEmpty()){
    		this.name = (String) map.get("name");
    		this.value = new MetadataTypeSupportHandler(map).getValue();
    		if(map.containsKey("version")){
    			this.version = (String) map.get("version");
    		}
    		if(map.containsKey("cacheName")){
    			this.cacheName = (String) map.get("cacheName");
    		}
    	}
    }

	public String getCacheName() {
		return cacheName;
	}

	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}
}
