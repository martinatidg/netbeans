package com.citi.reghub.core.rules.client;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public class RulesClient {

    public static final Logger LOGGER = LoggerFactory.getLogger(RulesClient.class);

    private static final String CACHE_RULES_COLLECTION 		= "rule_graph";
    private static final String CACHE_RULES_COLLECTION_TYPE = "Map";

    private final Map				props;
    private final RulesClientConfig config;
    private final CacheClient 		cacheClient;

    public RulesClient(RulesClientConfig config){
    	this.config = (config == null ? new RulesClientConfig() :  config);
    	
        if (!this.config.containsKey(RulesClientConfig.RULE_GRAPH_URL_KEY)) {
        	this.config.setDefaultRuleGraphUrl();
        }
        
        this.cacheClient = config.getCacheClient();
        this.props = prepareCacheClientConfig();
        
        LOGGER.info("Initialized Rules Client with configuration='{}'", config);
    }

    public RuleGraph load(String ruleGraphName) {
    	return getFromService(ruleGraphName);
    }

    private RuleGraph getFromService(String ruleGraphName) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Hitting Rules Service for Rule Graph with name='{}'", ruleGraphName);
    	}
    	
    	if (config.getRestClient() == null) {
    		throw new RuntimeException("RulesClientConfig should have HTTP_CLIENT set.");
    	}
    	
        RuleGraph ruleGraph = (RuleGraph) config.getRestClient().get(prepareRuleGraphUrl(ruleGraphName),RuleGraph.class);
        if(ruleGraph == null) {
        	throw new RuntimeException("Rule Graph Not found for rule graph name "+ruleGraphName);
        }
        
        putInCache(ruleGraphName);
        return ruleGraph;
	}

	public long getLastLoadTime(String ruleGraphName) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Hitting cache to get last load time for RuleGraph='{}'", ruleGraphName);
		}
		
		Object obj = cacheClient.get(ruleGraphName, this.props);
		
		if (obj == null) {
			return 0;
		}
		
		return (long) obj;
	}

	private void putInCache(String ruleGraphName) {
		cacheClient.put(ruleGraphName, System.currentTimeMillis(), this.props );
	}

	private String prepareRuleGraphUrl(String ruleGraphName) {
        return String.format(config.getRuleGraphUrl(), ruleGraphName);
    }

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static final Map prepareCacheClientConfig(){
		Map props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, CACHE_RULES_COLLECTION);
		props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_RULES_COLLECTION_TYPE);
		props.put(CacheClient.PUT_IF_ABSENT, "true");
		return props;
	}
}