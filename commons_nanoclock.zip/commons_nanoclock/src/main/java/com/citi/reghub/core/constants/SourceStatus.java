package com.citi.reghub.core.constants;

public interface SourceStatus {

	String NEW = "NEW";
	String AMEND = "AMEND";
	String CANCEL = "CANCEL";
	
}
