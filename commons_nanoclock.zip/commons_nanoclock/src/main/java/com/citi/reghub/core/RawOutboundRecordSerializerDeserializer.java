package com.citi.reghub.core;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;
import com.esotericsoftware.kryo.serializers.FieldSerializer;

public class RawOutboundRecordSerializerDeserializer implements Serializer<RawOutboundRecord>, Deserializer<RawOutboundRecord>{
	
	@SuppressWarnings("rawtypes")
	protected ThreadLocal kryos = new ThreadLocal() {
		@Override
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			kryo.getFieldSerializerConfig().setCachedFieldNameStrategy(FieldSerializer.CachedFieldNameStrategy.EXTENDED);
            CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, RawOutboundRecord.class);
            kryo.register(RawOutboundRecord.class, serializer);
			return kryo;
		}
	};
	
	@Override
	public byte[] serialize(String arg0, RawOutboundRecord rawOutboudRecord) {
		Output output = new ByteBufferOutput(10000); // Setting buffer size, need this to be updated in future  
		((Kryo) kryos.get()).writeObject(output, rawOutboudRecord);
		output.flush();
		return output.toBytes();		
	}
	
	@Override
	public RawOutboundRecord deserialize(String arg0, byte[] bytes) {
		try {
			Input input = new Input(bytes);
			RawOutboundRecord rawOutbound = ((Kryo) kryos.get()).readObject(input, RawOutboundRecord.class);
			input.close();
			return rawOutbound;
		}
		catch(Exception e) {
			throw new IllegalArgumentException("Error reading bytes",e);
		}
	}
	
	@Override
	public void close() {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}
	
	@Override
	public void configure(Map<String, ?> arg0, boolean arg1) {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}

}
