package com.citi.reghub.core.cache.client;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.XmlClientConfigBuilder;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.HazelcastInstanceNotActiveException;
import com.hazelcast.core.IMap;
import com.hazelcast.core.MultiMap;
import com.hazelcast.query.SqlPredicate;

public class HazelcastCacheClient implements CacheClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(HazelcastCacheClient.class);

	private static final String COLLECTION_MAP = "Map";
	private static final String COLLECTION_MULTIMAP = "MultiMap";

	private HazelcastInstance instance;
	private long lockLeaseTime;
	
	private long lockTimeoutValue;

	public HazelcastCacheClient(HazelcastInstance instance) {
		this.instance = instance;
	}
	
	private ClientConfig clientConfig;

	public HazelcastCacheClient(Map<String, String> props) {
		try {
			clientConfig = buildClientConfig(props);
			LOGGER.info("Created Hazelcast client config with props='{}'", props);
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting Hazelcast instance", e);
		}
	}
	
	public boolean createHazelcastClient(){
		try {
			instance = HazelcastClient.newHazelcastClient(clientConfig);
			LOGGER.info("Instantiated Hazelcast client instance with config "+clientConfig);
			return true;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting Hazelcast instance", e);
			return false;
		}
	}
	
	public boolean isCacheAvailable(){
		if(!isAlive()){
			LOGGER.error("Hazelcast instance is not initialized or the cluster is not Running");
			return createHazelcastClient();
		}
		return true;
	}
	
	public boolean isAlive(){
		if(instance == null || !instance.getLifecycleService().isRunning()){
			return false;
		}
		return true;
	}
	
	public void validateKey(Object key){
		if (key == null){
			InvalidConfigurationException ex = new InvalidConfigurationException("Invalid Key");
			LOGGER.error("Invalid key='{}'", key, ex);
			throw ex;
		}
	}

	@Override
	public Object get(Object key, Map config) {
		LOGGER.debug("Get from cache, request with config='{}' and key='{}' initiated", config, key);
		if(!isCacheAvailable()) return null;
		validateCollection(config);
		validateKey(key);
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		try{
			if (COLLECTION_MAP.equals(collectionType)) {
				Map map = instance.getMap(getCollectionName(config));
				return map.get(key);
			} else if (COLLECTION_MULTIMAP.equals(collectionType)) {
				MultiMap multimap = instance.getMultiMap(getCollectionName(config));
				Collection collection = multimap.get(key);
				return collection.isEmpty()?null:collection;
			}
		}catch (HazelcastInstanceNotActiveException ex){
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while processing get in HazelcastCacheClient with key='{}' and config = '{}'", key,config, e);
		}
		return null;
	}

	private String getCollectionName(Map config) {
		return (String) config.get(CACHE_COLLECTION_NAME);
	}

	public Object getCollection(Map config) {
		return this.instance.getMap(this.getCollectionName(config));
	}

	public boolean tryLock(Object key, Map config) {
		LOGGER.debug("TryLock from cache, request with config='{}' and key='{}' initiated", config, key);
		boolean flag = false;
		long lease_time =  (config.get(LOCK_LEASE_TIME) == null) ? lockLeaseTime : Long.parseLong( (String)config.get(LOCK_LEASE_TIME));
		long timeout_value = (config.get(LOCK_TIMEOUT_VALUE) == null) ? lockTimeoutValue : Long.parseLong( (String)config.get(LOCK_TIMEOUT_VALUE));

		if(!isCacheAvailable()) return false;
		validateCollection(config);
		validateKey(key);
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		try{
			if (COLLECTION_MULTIMAP.equals(collectionType)) {
				MultiMap multimap = instance.getMultiMap(getCollectionName(config));
				flag = multimap.tryLock(key, timeout_value, TimeUnit.MILLISECONDS, lease_time, TimeUnit.MILLISECONDS);
			} else if (COLLECTION_MAP.equals(collectionType)) {
				IMap map = instance.getMap(getCollectionName(config));
				flag = map.tryLock(key, timeout_value, TimeUnit.MILLISECONDS, lease_time, TimeUnit.MILLISECONDS);
			}
		}catch (HazelcastInstanceNotActiveException ex){
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while processing tryLock in HazelcastCacheClient with key='{}' and config = '{}'", key,config, e);
		}
		return flag;
	}

	public void unlock(Object key, Map config) {
		LOGGER.debug("Unlock in cache request with config='{}' and key='{}' initiated", config, key);
		if(!isCacheAvailable()) return;
		validateCollection(config);
		validateKey(key);
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		try{
			if (COLLECTION_MULTIMAP.equals(collectionType)){
				MultiMap multimap = instance.getMultiMap(getCollectionName(config));
				multimap.unlock(key);
				LOGGER.trace("Unlock in cache request with config='{}' and key='{}' has been processed", config, key);
			}
			else if (COLLECTION_MAP.equals(collectionType)) {
				IMap map = instance.getMap(getCollectionName(config));
				map.unlock(key);
				LOGGER.trace("Unlock in cache request with config='{}' and key='{}' has been processed", config, key);
			}
		}catch (HazelcastInstanceNotActiveException ex){
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while processing unlock in HazelcastCacheClient with key='{}' and config = '{}'", key,config, e);
		}
	}

	@Override
	public void put(Object key, Object value, Map config) {
		LOGGER.debug("Put in cache, request with config='{}' and key='{}' initiated", config, key);
		if(!isCacheAvailable()) return;
		validateCollection(config);
		validateKey(key);
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		try{
			if (COLLECTION_MAP.equals(collectionType)) {
				Map map = instance.getMap(getCollectionName(config));
				if("true".equals(config.get(PUT_IF_ABSENT)))
					map.putIfAbsent(key, value);
				else
					map.put(key, value);
				LOGGER.trace("Put in cache request with config='{}', key='{}', value='{}' has been processed", config, key, value);
			} else if (COLLECTION_MULTIMAP.equals(collectionType)) {
				MultiMap multimap = instance.getMultiMap(getCollectionName(config));
				multimap.put(key, value);
				LOGGER.trace("Put in cache request with config='{}', key='{}', value='{}' has been processed", config, key, value);
			}
		}catch (HazelcastInstanceNotActiveException ex){
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while processing put in HazelcastCacheClient with key='{}', value = '{}' and config = '{}'", key,value,config, e);
		}
	}

	private void validateCollection(Map props) {
		if (props.get(CACHE_COLLECTION_TYPE) == null)
			throw new InvalidConfigurationException(CACHE_COLLECTION_TYPE + " not found");
		if (props.get(CACHE_COLLECTION_NAME) == null)
			throw new InvalidConfigurationException(CACHE_COLLECTION_NAME + " not found");
		if(!Arrays.asList(COLLECTION_MAP,COLLECTION_MULTIMAP).contains(props.get(CACHE_COLLECTION_TYPE)))
			throw new InvalidConfigurationException("Unsupported Collection Type "+props.get(CACHE_COLLECTION_TYPE));
	}

	public void destroy() {
		if (instance != null)
			instance.shutdown();
	}

	@Override
	public boolean evictObject(Object key, Map config) {
		LOGGER.debug("Evict request with config='{}', key='{}' initiated", config, key);
		if(!isCacheAvailable()) return false;
		validateCollection(config);
		validateKey(key);
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		try{
		if (COLLECTION_MAP.equals(collectionType)) {
				IMap map = instance.getMap(getCollectionName(config));
				return map.evict(key);
		}else if(COLLECTION_MULTIMAP.equals(collectionType)){
				MultiMap multimap = instance.getMultiMap(getCollectionName(config));
				return multimap.remove(key) != null;
		}
		}catch (HazelcastInstanceNotActiveException ex){
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while processing evictObject in HazelcastCacheClient with key='{}' and config = '{}'", key,config, e);
		}
		return false;
	}

	@Override
	public void evictCollection(Map config) {
		LOGGER.debug("Evict request with config='{}' initiated", config);
		if(!isCacheAvailable()) return;
		validateCollection(config);
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		try{
		if (COLLECTION_MAP.equals(collectionType)) {
				IMap map = instance.getMap(getCollectionName(config));
				map.evictAll();
		}else if(COLLECTION_MULTIMAP.equals(collectionType)){
				MultiMap multimap = instance.getMultiMap(getCollectionName(config));
				multimap.keySet().forEach(key->multimap.remove(key));
		}
		}catch (HazelcastInstanceNotActiveException ex){
			createHazelcastClient();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while processing evictCollection in HazelcastCacheClient with config = '{}'",config, e);
		}
	}

	private ClientConfig buildClientConfig(Map<String, String> props) throws IOException {

		LOGGER.debug("BuildClientConfig request with props='{}' initiated", props);
		XmlClientConfigBuilder clientConfigBuilder = new XmlClientConfigBuilder();
		Properties properties = new Properties();

		properties.load(HazelcastCacheClient.class.getClassLoader().getResourceAsStream("hazelcast.properties"));
		LOGGER.debug("Loading properties='{}' from classpath with size='{}'", properties, properties.size());

		props.forEach((key, value) -> properties.setProperty(key, value));
		lockLeaseTime = Long.parseLong((String) properties.get(LOCK_LEASE_TIME));
		lockTimeoutValue = Long.parseLong((String) properties.get(LOCK_TIMEOUT_VALUE));
		clientConfigBuilder.setProperties(properties);
		ClientConfig config = clientConfigBuilder.build();
		String networkAddresses = properties.getProperty("hazelcast.network.address");

		if (networkAddresses == null || "".equals(networkAddresses)) {
			InvalidConfigurationException ex = new InvalidConfigurationException("Invalid network address provided in the buildClientConfig request.");
			LOGGER.error("Exception occurred while processing buildClientConfig with props='{}'", props, ex);
			throw ex;
		}
		config.getNetworkConfig().addAddress(networkAddresses.split(","));
		LOGGER.debug("Config near cache config map='{}'", config.getNearCacheConfigMap());
		return config;
	}

	@Override
	public Object filter(String query, Map config) {
		if(!isCacheAvailable()) return null;
		String collectionType = (String) config.get(CACHE_COLLECTION_TYPE);
		if (COLLECTION_MAP.equals(collectionType)){
			try{
				IMap map = instance.getMap(getCollectionName(config));
				return map.values(new SqlPredicate(query));
			} catch (HazelcastInstanceNotActiveException ex){
				createHazelcastClient();
			} catch (Exception e) {
				LOGGER.error("Exception occurred while processing filter with config='{}', query='{}'", config, query, e);
			}
		}
		else{
			InvalidConfigurationException ex =new InvalidConfigurationException("Unsupported collection type provided in the evictCollection request.");
			LOGGER.error("Exception occurred while processing evictCollection with collectionType='{}'", collectionType, ex);
			throw ex;
		}
		return null;
	}

}

