package com.citi.reghub.core.rules.client;

import java.util.HashMap;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;


public class RulesClientConfig extends HashMap<String,Object> {

	private static final long serialVersionUID = 3002304281165654824L;
	
	public static final String REST_CLIENT = "restClient";
    public static final String CACHE_CLIENT = "cacheClient";
    public static final String RULE_GRAPH_URL_KEY = "ruleGraphUrl";
    public static final String RULE_GRAPH_URL_VALUE = "http://localhost:8081/reghub-api/rules-service/rule-graphs/%s/details";

    public RestClient getRestClient() {
        return (RestClient) get(REST_CLIENT);
    }

    public String getRuleGraphUrl() {
        return (String) get(RULE_GRAPH_URL_KEY);
    }

    public void setDefaultRuleGraphUrl() {
        put(RULE_GRAPH_URL_KEY, RULE_GRAPH_URL_VALUE);
    }

    public CacheClient getCacheClient(){
    	return (CacheClient)get(CACHE_CLIENT);
    }
    
    public RulesClientConfig set(String key,Object value){
        put(key,value);
        return this;
    }

}
