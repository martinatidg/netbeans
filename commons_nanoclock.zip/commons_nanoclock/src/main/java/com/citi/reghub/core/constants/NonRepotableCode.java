package com.citi.reghub.core.constants;

public interface NonRepotableCode {

    String PRE_MEFID = "PRE_MEFID";

    String NON_REPORTABLE_PRE_MIFID_TRADE = "non_reportable_pre_mifid_trade";
}
