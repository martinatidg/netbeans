package com.citi.reghub.core.event.exception;

public enum ExceptionLevel {
	
	WARNS("warning"),
	EXCEPTION("exception"),
	NACK("nack");

	final String value;

	ExceptionLevel(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ExceptionLevel fromValue(String v) {
		for (ExceptionLevel c : ExceptionLevel.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	
	
}
