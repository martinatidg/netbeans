package com.citi.reghub.core;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.UUID;

public class RawOutboundRecord extends InfoablePojo {

	private static final long serialVersionUID = 1L;
	
	public static final String NO_FILE_NAME = "NULL";

	public class OutboundMessageType {
		public static final String FIX 		  = "fix";
		public static final String CSV_FORMAT = "csv";
		public static final String XML_FORMAT = "xml";
	}

	public String _id;
	public String regHubId;
	public String correlationId; // Stores the ID sent to uniquely identify this to the reporting agency (regReportingRef in some cases)
	public String stream; 
	public String flow; 

	public LocalDateTime sendTs;
	
	public String sendTo;
	public String reportedMessageType;
	public String reportedMessage;
	public String fileName;
	public String msgSeqNum; // Unique message sequence number (by date for TRADEcho) - Need for low-level technical nacks.

	public String responseMessage;
	public String ackId;
	
	public String reportStatus; 
	public String responseStatus; 
	
	public LocalDateTime responseTs;
	public String intmdResponse;

	public LocalDateTime intmdResponseTs;
	public String message;
	public String messageType;
	public String sourceId;
	public String regReportingRef; // need to remove in favor of correlationId !!!

	public RawOutboundRecord() {
		_id = UUID.randomUUID().toString();
		this.fileName = NO_FILE_NAME;
	}

	public RawOutboundRecord(Entity entity) {
		_id = UUID.randomUUID().toString();
		this.sendTs = LocalDateTime.now(Clock.systemUTC());
		this.fileName = NO_FILE_NAME;
		this.flow = entity.flow;
		this.regHubId = entity.regHubId;
		this.stream = entity.stream;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("RawOutboundEntity [_id=").append(_id)
		.append(", regHubId=").append(regHubId)
		.append(", correlationId="+ correlationId)
		.append(", stream=").append(stream)
		.append(", flow=").append(flow)
		.append(", sendTs=").append(sendTs)
		.append(", sendTo=").append(sendTo)
		.append(", reportedMessageType=").append(reportedMessageType)
		.append(", reportedMessage=").append(reportedMessage)
		.append(", reportStatus=").append(reportStatus)
		.append(", fileName=").append(fileName)
		.append(", msgSeqNum=").append(msgSeqNum)
		.append(", responseMessage=").append(responseMessage)
		.append(", responseStatus=").append(responseStatus)
		.append(", ackId=").append(ackId)
		.append(", responseTs=").append(responseTs)
		.append(", intmdResponse=").append(intmdResponse)
		.append(", intmdResponseTs=").append(intmdResponseTs)
		.append("]");
		
		return sb.toString();
	}		
}
