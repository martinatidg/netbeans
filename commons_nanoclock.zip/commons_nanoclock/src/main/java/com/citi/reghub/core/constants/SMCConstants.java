package com.citi.reghub.core.constants;

/**
 * These constants are defined for values received from the RefData lookup (SMC/OCEAN queries)
 *
 */
public interface SMCConstants {

	// IDENTIFIERS
	public static final String SMC_OCEAN_PRODUCT_ID = "oceanProductId";
	public static final String SMC_OCEAN_ISIN 		= "isin";
	public static final String SMC_OCEAN_CUSIP 		= "cusip";
	public static final String SMC_OCEAN_SMCP 		= "smcp";
	public static final String SMC_OCEAN_SEDOL 		= "sedol";
	public static final String SMC_OCEAN_FII 		= "fii";
	public static final String SMC_OCEAN_REUTERS	= "reut";
	public static final String SMC_OCEAN_RIC 		= "ric";
	public static final String SMC_OCEAN_ETS 		= "ets";
	public static final String SMC_OCEAN_TCKR 		= "tckr";
	public static final String SMC_OCEAN_TKRS 		= "tkrs";

	// CLASSIFICATION
	public static final String SMC_OCEAN_CFI_CODE   					= "cfiCode";
	public static final String SMC_OCEAN_PRODUCT_TYPE  	    			= "productType";
	public static final String SMC_OCEAN_PRODUCT_TYPE_ID    			= "productTypeId";
	public static final String SMC_OCEAN_PRODUCT_SUB_TYPE  				= "productSubType";
	public static final String SMC_OCEAN_SECURITY_TYPE_LEVEL_2  		= "securityTypeLevel2";
	public static final String SMC_OCEAN_SECURITY_TYPE_LEVEL_3  		= "securityTypeLevel3";
	public static final String SMC_OCEAN_SECTOR_CODE			  		= "sectorCd";
	public static final String SMC_OCEAN_MARKET_SEGMENT					= "marketSegment";
	public static final String SMC_OCEAN_IS_GLOBAL_PRIMARY 				= "isGlobalprimary";
	public static final String SMC_OCEAN_INSTRUMENT_LISTING_LEVEL		= "instrumentListingLevel";
	public static final String SMC_OCEAN_PRODUCT_BASE					= "baseProduct";
	public static final String SMC_OCEAN_PRODUCT_SUB					= "subProduct";
	public static final String SMC_OCEAN_PRODUCT_SUB_ADDITIONAL			= "additionalSubProduct";
	public static final String SMC_OCEAN_PRODUCT_OTHER_BASE				= "otherBaseProduct";
	public static final String SMC_OCEAN_PRODUCT_OTHER_SUB				= "otherSubProduct";
	public static final String SMC_OCEAN_PRODUCT_OTHER_SUB_ADDITIONAL	= "otherAdditionalSubProduct";

	// DESCRIPTIVE
	public static final String SMC_OCEAN_CUST1_TXT   				= "cust1Txt";
	public static final String SMC_OCEAN_CUST2_TXT   				= "cust2Txt";
	public static final String SMC_OCEAN_CUST3_TXT   				= "cust3Txt";
	public static final String SMC_OCEAN_PRODUCT_NAME  				= "productNm"; // Short description

	// ISSUER
	public static final String SMC_OCEAN_EXCHANGE_COUNTRY 			= "issuerCntry";
	public static final String SMC_OCEAN_ISSUER_COUNTRY 			= "issuerCntry";
	public static final String SMC_OCEAN_ISSUER_TYPE	 			= "issuerType";
	public static final String SMC_OCEAN_ISSUE_COUNTRY_CODE 		= "issueCntryCd";
	public static final String SMC_OCEAN_ISSUE_CURRENCY_CODE 		= "issueCurrCd";
	public static final String SMC_OCEAN_INCORPORATE_COUNTRY 		= "cntryOfIncorporation";
	public static final String SMC_OCEAN_MIFID_COUNTRY_CODE 		= "mifidCountrycode";
	
	// SECURITY
	public static final String SMC_OCEAN_PRIMARY_EXCHANGE 			= "primaryExng"; 
	public static final String SMC_OCEAN_SIZE_TICK		 			= "tickSize";
	public static final String SMC_OCEAN_CURRENCY_NOTIONAL 			= "notionalCurrencyCode"; 
	public static final String SMC_OCEAN_CURRENCY_BASE 				= "baseCurrency"; 
	public static final String SMC_OCEAN_CURRENCY_DESTINATION 		= "destinationCurrency"; 
	public static final String SMC_OCEAN_TRADE_DATE_LAST			= "lastTradeDate"; 
	
	public static final String SMC_OCEAN_TRADE_VENUE 				= "";
	public static final String SMC_OCEAN_CURRENCY_NOMINAL_VALUE 	= "";
	public static final String SMC_OCEAN_UNDERLYING_INSTRUMENT_NAME = "";

	// MIFID FIELDS
	public static final String SMC_OCEAN_SI_FLAG 					= "citiSystematicInternalizer";
	public static final String SMC_OCEAN_LIQUIDITY 					= "isLiquiditySubClass";

	// UNDERLYING
	public static final String SMC_OCEAN_UNDERLYING_LEI 					= "underlyingLei";
	public static final String SMC_OCEAN_UNDERLYING_ISIN 					= "underlyingIsin";
	public static final String SMC_OCEAN_UNDERLYING_INSTRUMENT_CODE 		= "underlyingIsin";   
	public static final String SMC_OCEAN_UNDERLYING_CREDIT_INDEX_SERIES 	= "underlyingCreditIndexSeries";
	public static final String SMC_OCEAN_UNDERLYING_CREDIT_INDEX_VERSION 	= "underlyingCreditIndexVersion";
	public static final String SMC_OCEAN_UNDERLYING_ISSUER_TYPE 			= "underlyingIssuerType";
	public static final String SMC_OCEAN_UNDERLYING_TERM_UNIT 				= "underlyingTermUnit";
	public static final String SMC_OCEAN_UNDERLYING_TERM_VALUE				= "underlyingTermValue";
	public static final String SMC_OCEAN_U_TOTV 							= "";
	
	public static final String SMC_OCEAN_TAX_STATUS_CODE 					= "";

	// DERIVATIVE INFORMATION
	public static final String SMC_OCEAN_CONTRACT_TYPE						= "contractType";
	public static final String SMC_OCEAN_CONTRACT_SIZE						= "contractSize";
	public static final String SMC_OCEAN_LOT_SIZE_QUOTE						= "quotelotSize";
	public static final String SMC_OCEAN_LOT_SIZE_ROUND						= "roundLotSize";
	public static final String SMC_OCEAN_LOT_SIZE_TRADE						= "tradeLotSize";
	public static final String SMC_OCEAN_UNIT_OF_TRADE						= "unitOfTrade";
	public static final String SMC_OCEAN_PRICE_STRIKE						= "strikePrice";
	public static final String SMC_OCEAN_POINT_VALUE						= "pointvalue";
	public static final String SMC_OCEAN_EXERCISE_TYPE						= "exerciseType";
	public static final String SMC_OCEAN_EXPIRY_DATE 						= "expirationDate";
	public static final String SMC_OCEAN_MATURITY_DATE_CURRENT				= "currentMaturityDate";
	public static final String SMC_OCEAN_MATURITY_DATE_OPT					= "optMaturityDate";
	public static final String SMC_OCEAN_SETTLEMENT_DATE					= "settlementDate";
	public static final String SMC_OCEAN_SETTLEMENT_TYPE					= "settlementType";
	public static final String SMC_OCEAN_TERMINATION_DATE					= "terminationDate";
	public static final String SMC_OCEAN_PRICE_TYPE_FINAL					= "finalPriceType";
	public static final String SMC_OCEAN_DELIVERY_TYPE 						= "deliveryMethod"; 
	
	public static final String SMC_OCEAN_ISO_UNDERLYING						= "isoUnderlying"; 
	public static final String SMC_OCEAN_ISO_LEG_FIRST 						= "isoFirstLeg"; 
	public static final String SMC_OCEAN_ISO_LEG_OTHER 						= "isoOtherLeg"; 
	public static final String SMC_OCEAN_LEG_FIRST_TERM_VALUE				= "firstLegTermValue"; 
	public static final String SMC_OCEAN_LEG_FIRST_REF_RATE					= "firstLegReferenceRate"; 
	public static final String SMC_OCEAN_LEG_FIRST_REF_RATE_UNIT			= "firstLegReferenceRateTermUnit"; 
	public static final String SMC_OCEAN_LEG_OTHER_TERM_VALUE				= "otherLegTermValue"; 
	public static final String SMC_OCEAN_LEG_OTHER_REF_RATE					= "otherLegReferenceRate"; 
	public static final String SMC_OCEAN_LEG_OTHER_REF_RATE_UNIT			= "otherLegReferenceRateTermUnit"; 
	public static final String SMC_OCEAN_IS_PHYSICAL						= "isphysical";
	public static final String SMC_OCEAN_CALL_PUT_INDICATOR                 = "iscallable";
	public static final String SMC_OCEAN_IS_CALLABLE						= "iscallable";
	public static final String SMC_OCEAN_IS_PUTABLE							= "isputable";
	public static final String SMC_OCEAN_IS_CASH							= "iscash";

	public static final String SMC_OCEAN_PRINCIPAL_AMOUNT_ISSUED			= "principalAmountIssued"; 
	public static final String SMC_OCEAN_MINIMUM_PRINCIPAL_DENOMINATION		= "minimumPrincipalDenomination"; 
	public static final String SMC_OCEAN_COUPON_DIVIDEND_RATE				= "couponDividendRate"; 
	public static final String SMC_OCEAN_CURRENT_PERIOD_SPREAD				= "currentPeriodSpread"; 
	public static final String SMC_OCEAN_SENORITY							= "seniority"; 
	public static final String SMC_OCEAN_PRODUCT_DEFINITION_NAME			= "productDefinitionName"; 
	public static final String SMC_OCEAN_RETURN_PAYOUT_TRIGGER				= "returnPayoutTrigger"; 
	public static final String SMC_OCEAN_TRANSACTION_TYPE					= "transactionType"; 
	public static final String SMC_OCEAN_PRICE_UNITS						= "priceUnits"; 
	
	// TOTV (AND EQUIVALENTS)
	public static final String SMC_OCEAN_TOTV 						= "isEeaTrade";
	public static final String SMC_OCEAN_TRADE_EEA_VENUE 			= "isEeaTrade";
	public static final String SMC_OCEAN_LISTED_EEA_REG_MARKET 		= "isEeaTrade";
	
	// POST (SSTI AND LIS)
	public static final String SMC_OCEAN_POST_SSTI_TH_FLOOR 		= "postTradeSstiThresholdFloor";
	public static final String SMC_OCEAN_POST_SSTI_TH_VALUE 		= "postTradeSstiThresholdValue";
	public static final String SMC_OCEAN_POST_LIS_TH_FLOOR  		= "postTradeLisThresholdFloor";
	public static final String SMC_OCEAN_POST_LIS_TH_VALUE  		= "postTradeLisThresholdValue";
	
	// PRE (SSTI AND LIS)
	public static final String SMC_OCEAN_PRE_SSTI_TH_FLOOR 		    = "preTradeSstiThresholdFloor";
	public static final String SMC_OCEAN_PRE_SSTI_TH_VALUE 			= "preTradeSstiThresholdValue";
	public static final String SMC_OCEAN_PRE_LIS_TH_FLOOR  			= "preTradeLisThresholdFloor";
	public static final String SMC_OCEAN_PRE_LIS_TH_VALUE  			= "preTradeLisThresholdValue";
	
	// ADMISSION
	public static final String SMC_OCEAN_ADMISSION_REQUESTED	    = "isRequestAdmissionTrading";
	public static final String SMC_OCEAN_ADMISSION_REQUEST_DATE	    = "requestAdmissionTradingDate";
	public static final String SMC_OCEAN_ADMISSION_FIRST_TRADE_DATE = "requestAdmissionFirstTradeDate";
	public static final String SMC_OCEAN_ADMISSION_APPROVAL_DATE    = "approvalAdmissionTradingDate";
	
}
