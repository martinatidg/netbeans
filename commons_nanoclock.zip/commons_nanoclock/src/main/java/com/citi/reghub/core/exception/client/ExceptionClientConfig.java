package com.citi.reghub.core.exception.client;

import java.util.HashMap;

import com.citi.reghub.core.client.RestClient;

public class ExceptionClientConfig  extends HashMap<String,Object> {
	
	private static final long serialVersionUID = 1L;
	
	public static final String REST_CLIENT = "restClient";
    public static final String XM_SERVICE_URL_KEY = "xm-serviceUrl";
    public static final String XM_SERVICE_URL_VALUE = "http://localhost:8090/exceptions";
    

    public RestClient getRestClient() {
        return (RestClient) get(REST_CLIENT);
    }

    public String getXmServiceUrl() {
        return (String) get(XM_SERVICE_URL_KEY);
    }

    public ExceptionClientConfig setDefaultXmServiceUrl() {
        return set(XM_SERVICE_URL_KEY, XM_SERVICE_URL_VALUE);
    }

    
    public ExceptionClientConfig set(String key, Object value){
        put(key,value);
        return this;
    }
}
