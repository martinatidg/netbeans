package com.citi.reghub.core.constants;

/**
 * This interface defines the internal Entity values used for storing Enriched
 * security and account information.
 * 
 */
public interface EntityInfoMapEnrichmentConstants {

	// ===========================================================================================
	// SMC RELATED CONSTANTS
	public static final String SMC_REF_ISIN 				= "refIsin";
	public static final String SMC_REF_CUSIP 				= "refCusip";
	public static final String SMC_REF_FII 					= "refFii";
	public static final String SMC_REF_SMCP 				= "refSmcp";
	
	public static final String SMC_REF_CUST1_TXT 			= "refCust1Txt"; 
	
	public static final String SMC_REF_CFI_CODE 			= "refCfiCode";
	
	public static final String SMC_REF_ISSUER_COUNTRY 		= "refIssuerCntry";
	public static final String SMC_REF_NOTIONAL_CURRENCY 	= "refNotionalCcy1"; 
	public static final String SMC_REF_EXPIRY_DATE 			= "refExpiryDate"; 
	public static final String SMC_REF_OPTION_TYPE 			= "refOptionType"; 
	public static final String SMC_REF_CALL_PUT_INDICATOR 	= "refIscallable";
	public static final String SMC_REF_DELIVERY_TYPE 		= "refDeliveryType"; 

	// SMC fields not defined in Mongo mapping
	public static final String SMC_REF_UNDERLYING_INSTRUMENT_CODE = "refUnderlyingInstrument"; 
	public static final String SMC_REF_UNDERLYING_INSTRUMENT_NAME = "refUnderlyingInstrumentName";

	public static final String SMC_REF_SI_LIST = "refSIList"; // NOT DEFINED YET IN SMC
	public static final String SMC_REF_SI_FLAG = "refSIFlag";

	// Currently, these 3 fields are all equivalents
	public static final String SMC_REF_TOTV 					= "refTOTVInstrumentFlag";
	public static final String SMC_REF_TRADE_EEA_VENUE 			= "refTradeEEAVenue";
	public static final String SMC_REF_LISTED_EEA_REG_MARKET 	= "refListedEEARegMarket";

	public static final String SMC_REF_U_TOTV 					= "refUTOTVInstrumentFlag";
	public static final String SMC_REF_MARKET_SEGMENT 			= "refMarketSeg";
	public static final String SMC_REF_TAX_STATUS_CODE 			= "refTaxStatusCode";
	public static final String SMC_REF_MIFID_COUNTRY_CODE 		= "refMIFIDCountryCode";
	public static final String SMC_REF_CURRENCY_NOMINAL_VALUE 	= "refCurrencyNominalValue";
	public static final String SMC_REF_TRADE_VENUE 				= "refTradeVenue";
	public static final String SMC_ASSISTED_REPORT 				= "refIsAssistedReport";

	public static final String SMC_EXEC_FIRM_SI 			= "refIsFirmSI";
	public static final String SMC_CPTY_FIRM_SI 			= "refIsCptySI";

	public static final String SMC_REF_LIQUIDITY 			= "refLiquidity";

	// These should NOT be used in favor of the below items
	public static final String SMC_REF_LIS 		 			= "refPostLISValue";
	public static final String SMC_REF_SSTI 	 			= "refPostSSTIValue";

	public static final String SMC_REF_POST_SSTI_TH_FLOOR 	= "refPostSSTIFloor";
	public static final String SMC_REF_POST_SSTI_TH_VALUE 	= "refPostSSTIValue";
	public static final String SMC_REF_POST_LIS_TH_FLOOR 	= "refPostLISFloor";
	public static final String SMC_REF_POST_LIS_TH_VALUE 	= "refPostLISValue";

	public static final String SMC_REF_PRE_SSTI_TH_FLOOR 	= "refPreSSTIFloor";
	public static final String SMC_REF_PRE_SSTI_TH_VALUE 	= "refPreSSTIValue";
	public static final String SMC_REF_PRE_LIS_TH_FLOOR 	= "refPreLISFloor";
	public static final String SMC_REF_PRE_LIS_TH_VALUE 	= "refPreLISValue";
	
	public static final String SMC_REF_EXCHANGE_COUNTRY 	= "refIssuerCntry";

	public static final String SMC_REF_SETTLEMENT_TYPE	 	= "refSettlementType";
	public static final String SMC_REF_SETTLEMENT_DATE	 	= "refSettlementDate";
	
	public static final String SMC_REF_INSTRUMENT_FULL_NAME		="refInstrumentFullName";
	public static final String SMC_REF_MATURITY_DATE			="refMaturityDate";
	public static final String SMC_REF_UNDERLYING_ISSUER_TYPE	="refUnderlyingIssuerType";
	public static final String SMC_REF_FINAL_PRICE_TYPE			="refFinalPriceType";
	public static final String SMC_REF_OCEAN_PRODUCT_ID			="refOceanProductID";
	public static final String SMC_REF_INSTRUMENT_CLASSIFICATION="refInstrumentClassification";
	public static final String SMC_REF_PRODUCT_NAME				="refProductName";
	public static final String SMC_REF_REQUEST_FOR_ADMISSION	="refRequestForAdmission";
	
	public static final String SMC_REF_APPROVAL_ADMISSION_TRADING_DATE		="refApprovalAdmissionTradingDate";
	public static final String SMC_REF_REQUEST_ADMISSION_TRADING_DATE		="refRequestAdmissionTradingDate";
	public static final String SMC_REF_REQUEST_ADMISSION_FIRST_TRADE_DATE	="refRequestAdmissionFirstTradeDate";
	
	public static final String SMC_REF_TERMINATION_DATE			="refTerminationDate";
	public static final String SMC_REF_ISSUED_NOMINAL_AMOUNT	="refIssuedNominalAmount";
	public static final String SMC_REF_OPT_MATURITY_DATE		="refOptMaturityDate";
	public static final String SMC_REF_NOMINAL_VALUE_CCY		="refNominalValueCcy";
	public static final String SMC_REF_MIN_NOMINAL_VALUE		="refMinNominalValue";
	public static final String SMC_REF_COUPON_RATE				="refCouponRate";
	public static final String SMC_REF_UNDERLYING_LEI			="refUnderlyingLei";
	public static final String SMC_REF_STRIKE_PRICE				="refStrikePrice";
	public static final String SMC_REF_STRIKE_PRICE_CURRENCY	="refStrikePriceCurrency";
	public static final String SMC_REF_EXERCISE_STYLE			="refExerciseStyle";
	public static final String SMC_REF_BASE_PRODUCT				="refBaseProduct";
	public static final String SMC_REF_SUB_PRODUCT				="refSubProduct";
	public static final String SMC_REF_FURTHER_SUB_PRODUCT		="refFurtherSubProduct";
	public static final String SMC_REF_CONTRACT_SIZE			="refContractSize";
	public static final String SMC_REF_UNDERLYING_ISIN			="refUnderlyingIsin";
	public static final String SMC_REF_TRANSACTION_TYPE			="refTransactionType";
	public static final String SMC_REF_SENIORITY				="refSeniority";

	// ===========================================================================================
	// AMC RELATED CONSTANTS - FIRM
	
	public static final String AMC_REF_ISSUER_LEI = "refIssuerLei";
	
	public static final String AMC_REF_FIRM_LEI = "refFirmLei";
	public static final String AMC_REF_FIRM_ACCT_MNEMONIC = "refFirmAcctMnemonic";
	public static final String AMC_REF_FIRM_GFCID = "refFirmGfci";

	// AMC fields not defined in Mongo mapping
	public static final String AMC_REF_FIRM_FIRM_CODE = "refFirmFirmCode";

	public static final String AMC_REF_FIRM_COMMODITY_POSITION_FLAG = "refFirmComPositionFlag";
	public static final String AMC_REF_FIRM_FX_EXTND_SPOT_FLG = "refFirmExtndSpotFlag";
	public static final String AMC_REF_FIRM_LGL_ENTITY_CODE = "refFirmLglEntyCd";
	
	public static final String AMC_REF_FIRM_MIC_ID ="refFirmMICID";
	public static final String AMC_REF_FIRM_ASSISTED_REPORTING_FLAG = "refFirmAssistedReportingFlag";
	public static final String AMC_REF_FIRM_EEA_FLAG ="refFirmEEAFlag";
	public static final String AMC_REF_FIRM_TRADING_VENUE_TYPE = "refFirmTradingVenueType";

	// ===========================================================================================
	// AMC RELATED CONSTANTS - COUNTERPARTY
	
	public static final String AMC_REF_CPTY_LEI = "refCptyLei";
	public static final String AMC_REF_CPTY_ACCT_MNEMONIC = "refCptyAcctMnemonic";
	public static final String AMC_REF_CPTY_GFCID = "refCptyGfci";
	public static final String AMC_REF_CPTY_FIRM_CODE = "refCptyFirmCode";
	public static final String AMC_REF_CPTY_MIC_ID = "refCptyMICID";
	public static final String AMC_REF_CPTY_ASSISTED_REPORTING_FLAG = "refCptyAssistedReportingFlag";
	public static final String AMC_REF_CPTY_EEA_CODE = "refCptyEEACode";
	public static final String AMC_REF_CPTY_COMMODITY_POSITION_FLAG = "refCptyComPositionFlag";
	public static final String AMC_REF_CPTY_FX_EXTND_SPOT_FLG = "refCptyExtndSpotFlag";
	public static final String AMC_REF_CPTY_LGL_ENTITY_CODE = "refCptyLglEntyCd";
	public static final String AMC_REF_CPTY_EEA_FLAG = "refCptyEEAFlag";
	public static final String AMC_REF_CPTY_TRADING_VENUE_TYPE = "refCptyTradingVenueType";

}
