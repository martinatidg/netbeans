package com.citi.reghub.core.enrichment.client;

import java.util.ArrayList;
import java.util.List;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.AuditTags;
import com.citi.reghub.core.constants.EventTypes;

public class EnrichmentPlan {

	public String id;
	public String name;
	public String type;
	public String description;
	public String group;
	public List<EnricherConfig> enricherConfigs = new ArrayList<>();
	private String	version;
	public EnrichmentPlan() {
	}

	public EnrichmentPlan(String id, String name, String type, String description, String group,
			List<EnricherConfig> enricherConfigs, String version) {
		this.id = id;
		this.name = name;
		this.type = type;
		this.description = description;
		this.group = group;
		this.enricherConfigs = enricherConfigs;
		this.version = version;
	}
	
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Audit toAudit(Audit audit) {
		String event = EventTypes.ENRICHMENT_PLAN_EXECUTION + " : " + this.name;
		audit.event = event;
		audit.tags.add(AuditTags.ENRICHMENT);
		audit.setVersion(getVersion());		
		return audit;
	}

}

