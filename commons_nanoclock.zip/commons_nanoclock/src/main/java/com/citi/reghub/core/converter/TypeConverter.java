package com.citi.reghub.core.converter;

public interface TypeConverter<K,V> {
	
	public V convert(K obj, String format);

}
