package com.citi.reghub.core.event;

public class EventBuilder {

	private EventEnvelope eventEnvelope;

	public EventBuilder newEvent() {
		this.eventEnvelope = new EventEnvelope();

		return this;
	}

	public EventBuilder ofTypeException() {
		this.eventEnvelope.setEventType(EventType.EXCEPTION);

		return this;
	}

	public EventBuilder withEventName(EventName eventName) {
		this.eventEnvelope.setEventName(eventName);

		return this;
	}

	public EventBuilder withEventSource(EventSource eventSource) {
		this.eventEnvelope.setEventSource(eventSource);

		return this;
	}

	public EventBuilder withEventData(EventData eventData) {
		this.eventEnvelope.setEventData(eventData);

		return this;
	}

	public EventEnvelope build() {
		validate(this.eventEnvelope);
		this.eventEnvelope.setEventTimeToNow();

		return eventEnvelope;
	}

	private void validate(EventEnvelope eventEnvelope2) {

		if (this.eventEnvelope == null) {
			throw new IllegalStateException("No new event was created");
		}

		if (this.eventEnvelope.getEventType() == null) {
			throw new IllegalStateException("EventType was not defined");
		}

		if (this.eventEnvelope.getEventName() == null) {
			throw new IllegalStateException("EventName was not defined");
		}

		if (this.eventEnvelope.getEventVersion() == null) {
			this.eventEnvelope.setEventVersion(EventVersion.V_1);
		}

		if (this.eventEnvelope.getEventSource() == null) {
			throw new IllegalStateException("EventSource was not defined");
		}

		if (this.eventEnvelope.getEventData() == null) {
			throw new IllegalStateException("EventData was not defined");
		}
	}

}
