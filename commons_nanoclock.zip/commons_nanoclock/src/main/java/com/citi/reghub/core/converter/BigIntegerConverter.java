package com.citi.reghub.core.converter;

import java.math.BigInteger;

public class BigIntegerConverter implements TypeConverter<String, BigInteger> {

	public BigInteger convert(String obj, String format) {
		// TODO Auto-generated method stub
		return new BigInteger(obj);
	}

}
