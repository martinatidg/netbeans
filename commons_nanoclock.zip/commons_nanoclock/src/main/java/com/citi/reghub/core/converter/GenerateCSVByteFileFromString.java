package com.citi.reghub.core.converter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;


public class GenerateCSVByteFileFromString implements GenerateByteFileFromString {

	@Override
	public byte[] generateByteArray(String data) throws IOException {
		ByteArrayOutputStream bOutput = new ByteArrayOutputStream(data.length() * 2 + 100);
		bOutput.write(data.getBytes());
		byte b[] = bOutput.toByteArray();
		return b;
	}

}
