package com.citi.reghub.core.response.handler;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.ParsedResponse;
import com.citi.reghub.core.RawOutboundRecord;

public class ParsedResponseBundle {

	private final Entity e;
	private final RawOutboundRecord raw;
	private final ParsedResponse pr;
	private final String m;
	
	public ParsedResponseBundle(Entity entity, RawOutboundRecord rawRecord, ParsedResponse parsedResponse, String message) {
		this.e = entity;
		this.raw = rawRecord;
		this.pr = parsedResponse;
		this.m = message;
	}
	
	public final Entity getEntity() {
		return this.e;
	}
	
	public final RawOutboundRecord getRawOutboundRecord() {
		return this.raw;
	}
	
	public final ParsedResponse getParsedResponse() {
		return this.pr;
	}
	
	
	public final String getMessage() {
		return this.m;
	}
	
}
