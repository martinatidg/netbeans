package com.citi.reghub.core;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;
import com.esotericsoftware.kryo.serializers.FieldSerializer;

public class RawMsgObjectKafkaSerializerDeserializer implements Serializer<RawMsgObject>, Deserializer<RawMsgObject>{
	
	@SuppressWarnings("rawtypes")
	protected ThreadLocal kryos = new ThreadLocal() {
        @Override
		protected Kryo initialValue() {
            Kryo kryo = new Kryo();
            kryo.getFieldSerializerConfig().setCachedFieldNameStrategy(FieldSerializer.CachedFieldNameStrategy.EXTENDED);
            CompatibleFieldSerializer serializer = new CompatibleFieldSerializer(kryo, RawMsgObject.class);
            kryo.register(RawMsgObject.class, serializer);
            return kryo;
        }
    };
    
   @Override
	public byte[] serialize(String arg0, RawMsgObject rawMsgObject) {
		Output output = new ByteBufferOutput(1005760); // Setting buffer size 24KB
		((Kryo) kryos.get()).writeObject(output, rawMsgObject);
		output.flush();
		return output.toBytes();
	}

	@Override
	public RawMsgObject deserialize(String arg0, byte[] bytes) {
		try {
			Input input = new Input(bytes);
			RawMsgObject rawMsgObject = ((Kryo) kryos.get()).readObject(input, RawMsgObject.class);
			input.close();
			return rawMsgObject;
        }
        catch(Exception e) {
            throw new IllegalArgumentException("Error reading bytes",e);
        }
	}
    
	@Override
	public void close() {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}

	@Override
	public void configure(Map<String, ?> arg0, boolean arg1) {
		/**
		 * 	
		 * Auto-generated method stub
		 */
	}

}
