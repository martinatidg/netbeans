package com.citi.reghub.core.constants;

/**
 * These constants are defined for values received from the RefData lookup (AMC/OCEAN queries).
 * 
 * THESE ARE NOT THE VALUES STORED IN THE ENTITY!
 */
public interface AMCConstants {
	
    public static final String AMC_OCEAN_LEI ="lei";
    public static final String AMC_OCEAN_ACCT_MNEMONIC = "acctMnemonic";
	public static final String AMC_OCEAN_GFCID = "gfci";
	public static final String AMC_OCEAN_FIRM_CODE = "sourceFirmCode";
	public static final String AMC_OCEAN_EEA_FLAG = "eeaEntityFlag";
	public static final String AMC_OCEAN_LGL_ENTITY_CODE = "lglEntyCd";
	
	// NOT YET DEFINED BY AMC (ASSUMING NAME FOR NOW) 	
	public static final String AMC_OCEAN_TRADING_VENUE_TYPE = "";
	public static final String AMC_OCEAN_MIC_ID = "micid";
	public static final String AMC_OCEAN_ASSISTED_REPORTING_FLAG = "";
	public static final String AMC_OCEAN_COMMODITY_POSITION_FLAG = "";	
	public static final String AMC_OCEAN_FX_EXTND_SPOT_FLG = "";
	
}
