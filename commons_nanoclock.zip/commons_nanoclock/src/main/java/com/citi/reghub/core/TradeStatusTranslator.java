package com.citi.reghub.core;

import java.io.Serializable;
import java.util.List;

public interface TradeStatusTranslator extends Serializable{
	
	List<Entity> translateTradeStatus(Entity currentEntity, Entity prevEntity);
	
}
