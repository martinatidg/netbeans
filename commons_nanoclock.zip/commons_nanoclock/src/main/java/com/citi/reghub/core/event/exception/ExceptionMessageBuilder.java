package com.citi.reghub.core.event.exception;

import java.util.HashMap;
import java.util.LinkedList;

public class ExceptionMessageBuilder {

	private ExceptionMessage exception;

	public ExceptionMessageBuilder newException() {
		this.exception = new ExceptionMessage();
		this.exception.setNotes(new LinkedList<Note>());
		this.exception.setAttributes(new HashMap<String, Object>());

		return this;
	}

	public ExceptionMessageBuilder withId(String id) {
		this.exception.setId(id);

		return this;
	}

	public ExceptionMessageBuilder withSourceId(String value) {
		this.exception.setSourceId(value);

		return this;
	}

	public ExceptionMessageBuilder withRegHubId(String value) {
		this.exception.setRegHubId(value);

		return this;
	}

	public ExceptionMessageBuilder withRegReportingRef(String value) {
		this.exception.setRegReportingRef(value);

		return this;
	}

	public ExceptionMessageBuilder withStream(String value) {
		this.exception.setStream(value);

		return this;
	}

	public ExceptionMessageBuilder withFlow(String value) {
		this.exception.setFlow(value);

		return this;
	}
	
	public ExceptionMessageBuilder withSourceSystem(String value) {
		this.exception.setSourceSystem(value);

		return this;
	}

	public ExceptionMessageBuilder withReasonCode(String value) {
		this.exception.setReasonCode(value);

		return this;
	}

	public ExceptionMessageBuilder withRuleVersion(String value) {
		this.exception.setRuleVersion(value);

		return this;
	}

	public ExceptionMessageBuilder withDescription(String value) {
		this.exception.setDescription(value);

		return this;
	}
	
	public ExceptionMessageBuilder withDisplayErrorCode(String value) {
		this.exception.setDisplayErrorCode(value);

		return this;
	}
	
	public ExceptionMessageBuilder withNackSource(String value) {
		this.exception.setNackSource(value);

		return this;
	}
	
	public ExceptionMessageBuilder isXstreamEligible(boolean value) {
		this.exception.setXstreamEligible(value);

		return this;
	}

	public ExceptionMessageBuilder addNote(Note note) {
		this.exception.getNotes().add(note);

		return this;
	}

	public ExceptionMessageBuilder addAttribute(String key, Object value) {
		this.exception.getAttributes().put(key, value);

		return this;
	}

	public ExceptionMessageBuilder withUpdatedSource(String value) {
		this.exception.setUpdatedSource(value);

		return this;
	}

	public ExceptionMessageBuilder withStatus(ExceptionStatus value) {
		this.exception.setStatus(value);

		return this;
	}

	public ExceptionMessageBuilder withOwner(FunctionalOwner value) {
		this.exception.setFunctionalOwner(value);

		return this;
	}

	public ExceptionMessageBuilder withType(ExceptionType value) {
		this.exception.setType(value);

		return this;
	}

	public ExceptionMessageBuilder withLevel(ExceptionLevel value) {
		this.exception.setLevel(value);

		return this;
	}

	public ExceptionMessageBuilder withClosedByRegHubId(String value) {
		this.exception.setClosedByRegHubId(value);

		return this;
	}

	public ExceptionMessageBuilder withTradePublishedTs(long value) {
		this.exception.setTradePublishedTs(value);

		return this;
	}

	public ExceptionMessage build() {
		return this.exception;
	}
}