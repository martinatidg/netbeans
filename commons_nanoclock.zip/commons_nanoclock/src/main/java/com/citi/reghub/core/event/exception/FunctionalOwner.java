package com.citi.reghub.core.event.exception;

public enum FunctionalOwner {
	
	BUS("bus"),
	TECH("tech"),
	SMC("smc"),
	AMC("amc"),
	ORC("orc");

	final String value;

	FunctionalOwner(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static FunctionalOwner fromValue(String v) {
		for (FunctionalOwner c : FunctionalOwner.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
