package com.citi.reghub.core.constants;

public interface EntityFlags {
	
	String CANCEL_AND_CORRECT = "CANCEL_AND_CORRECT";
}
