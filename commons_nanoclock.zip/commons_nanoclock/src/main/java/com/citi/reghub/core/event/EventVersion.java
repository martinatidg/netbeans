package com.citi.reghub.core.event;

public enum EventVersion {

	V_1(1);

	private final Integer value;

	EventVersion(Integer v) {
		value = v;
	}

	public int value() {
		return value;
	}

	public static EventVersion fromValue(Integer v) {
		for (EventVersion c : EventVersion.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException("No Value for "+v);
	}

}
