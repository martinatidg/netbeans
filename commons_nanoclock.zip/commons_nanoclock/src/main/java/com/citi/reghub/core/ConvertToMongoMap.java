package com.citi.reghub.core;

import java.util.Map;

public interface ConvertToMongoMap<T extends Object> {

    public Map toMap(T object);
}
