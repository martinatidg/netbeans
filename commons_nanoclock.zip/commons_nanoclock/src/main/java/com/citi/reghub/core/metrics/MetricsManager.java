package com.citi.reghub.core.metrics;

import java.lang.management.ManagementFactory;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gemstone.gemfire.internal.Assert;

/**
 * Singleton MetricsManager, that encapsulates all application management
 * functionality to create, register and publish new metric on JMX MBeanServer
 * 
 * @author Michael Rootman
 *
 */
public class MetricsManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(MetricsManager.class);
	private static MetricsManager instance;
	private Map<String, Metric<? extends Number>> metricMap = new ConcurrentHashMap<>();

	private MetricsManager() {
	}

	/**
	 * Obtain Instance of MetricManager
	 * 
	 * @return Instance of MetrciManager
	 */
	public static synchronized MetricsManager getInstance() {
		if (instance == null) {
			instance = new MetricsManager();

			LOGGER.info("New instance of MetricsManager created.");
		}

		return instance;
	}

	/**
	 * Convenient method that either returns existing or creates and registers
	 * new metric with the given name
	 * 
	 * @param name
	 *            - Name of the Metric
	 * @return Implementation of {@link Metric} interface
	 */
	public synchronized Metric<? extends Number> getOrCreateMetric(String name) {
		if (name ==null || name.isEmpty()){
			throw new IllegalArgumentException("Metric name cannot be null or empty");
		}
		
		Metric<? extends Number> metric = metricMap.get(name);

		if (metric == null) {
			metric = new GenericMetric(name);
			metricMap.put(name, metric);

			LOGGER.info("New application metrics was created and registered: {}", name);
		}

		return metric;
	}

	/**
	 * To register manually created metric
	 * 
	 * @param metric
	 *            - Implementation of Metric Interface
	 */
	public void registerMetric(Metric<? extends Number> metric) {
		if (metric==null || metric.getName()==null || metric.getName().isEmpty()){
			throw new IllegalArgumentException("Metric and/or its name cannot be null or empty");
		}
		
		metricMap.put(metric.getName(), metric);

		LOGGER.info("New application metrics was registered: {}", metric.getName());
	}

	public Metric<? extends Number> getMetric(String name) {
		if (name ==null || name.isEmpty()){
			throw new IllegalArgumentException("Metric name cannot be null or empty");
		}
		
		return metricMap.get(name);
	}

	public Map<String, Metric<? extends Number>> getAllMetrics() {
		return metricMap;
	}

	/**
	 * Convenient method to publish all metric with JMX MBeanServer. Metrics has
	 * to be registered first with MetricsManager before invoking this method.
	 */
	public void registerJMXBeans() {
		MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

		try {
			mbs.registerMBean(new ApplicationMetricsMBean(this),
					new ObjectName("com.citi.reghub:type=ApplicationMetrics"));
		} catch (Exception e) {
			LOGGER.error("Error registering ApplicationMetricsMBean with MBEanServer due to: {}", e.getMessage());
			throw new RuntimeException(e);
		}
	}

}
