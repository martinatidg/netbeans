package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.refdata.client.Refdata.RefdataType;

public class RefdataClient {

	public static Logger LOGGER = LoggerFactory.getLogger(RefdataClient.class);

	public static final String GEMFIRE_CACHE_XML_KEY = "gemfire.cache-xml-file";
	public static final String GEMFIRE_CACHE_XML_VALUE = "gemfire-client-default.xml";

	private RefdataInterface refdataSecurityClient;
	private RefdataInterface refdataAccountClient;
	private OceanGemfireCacheClient oceanGemfireCacheClient;

	private final Map<String, String> refdataClientConfig;

	public RefdataClient() {
		refdataClientConfig = null;
	}

	public RefdataClient(final Map<String, String> refdataClientConfig) {
		this.refdataClientConfig = refdataClientConfig;
		this.oceanGemfireCacheClient = new OceanGemfireCacheClient(refdataClientConfig);
		this.refdataSecurityClient = new RefdataSecurityClient(this.oceanGemfireCacheClient);
		this.refdataAccountClient = new RefdataAccountClient(this.oceanGemfireCacheClient);
	}

	public RefdataInterface getRefdataProductClient() {
		return refdataSecurityClient;
	}

	public void setRefdataProductClient(RefdataSecurityClient refdataProductClient) {
		this.refdataSecurityClient = refdataProductClient;
	}

	public RefdataInterface getRefdataAccountClient() {
		return refdataAccountClient;
	}

	public void setRefdataAccountClient(RefdataAccountClient refdataAccountClient) {
		this.refdataAccountClient = refdataAccountClient;
	}

	public Refdata getDetails(String refdataTypeString, String identifier, Object value) {
		Refdata response;
		try {
			RefdataType refdataType = RefdataType.valueOf(refdataTypeString.toUpperCase());
			if(refdataType == RefdataType.ACCOUNT) {
				response = new Refdata(refdataType, refdataAccountClient.getData(identifier, value));
			} else if (refdataType == RefdataType.SECURITY) {
				response = new Refdata(refdataType, refdataSecurityClient.getData(identifier, value));
			} else {
				response = null;
			}
		} catch (IllegalArgumentException e) {
			response = null;
			LOGGER.error("Invalid refdata type: '{}'", refdataTypeString, e);
			throw new RuntimeException("Invalid refdata type: " + refdataTypeString);
		}
		return response;
	}

}
