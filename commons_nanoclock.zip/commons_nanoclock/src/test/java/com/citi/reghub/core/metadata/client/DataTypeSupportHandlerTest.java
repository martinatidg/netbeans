package com.citi.reghub.core.metadata.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class DataTypeSupportHandlerTest {
	
	@Test
	public void testLocalDateWithoutFormat(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","localDateString","2017-01-01").dataType("LocalDate").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof LocalDate);
		assertEquals(LocalDate.of(2017, 1, 01),obj);
	}
	
	@Test
	public void testLocalDateWithFormat(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","localDateWithFormat","2017-Jan-01").dataType("LocalDate")
				.format("yyyy-MMM-dd").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof LocalDate);
		assertEquals(LocalDate.of(2017, 1, 01),obj);
	}
	
	@Test
	public void testLocalDateTimeWithoutFormat(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","localDateTimeString","2017-01-01T12:30:55").dataType("LocalDateTime").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof LocalDateTime);
		assertEquals(LocalDateTime.of(2017, 1, 01,12,30,55),obj);
	}
	
	@Test
	public void testLocalDateTimeWithFormat(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","localDateTimeWithFormat","2017-Jan-01 12:30:55").dataType("LocalDateTime")
        		.format("yyyy-MMM-dd HH:mm:ss").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof LocalDateTime);
		assertEquals(LocalDateTime.of(2017, 1, 01,12,30,55),obj);
	}
	
	@Test
	public void testInteger(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","integerString","256").dataType("Integer").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof Integer);
		assertEquals(new Integer("256"),obj);
	}
	
	@Test
	public void testLong(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","longString","1256467").dataType("Long").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof Long);
		assertEquals(new Long("1256467"),obj);
	}
	
	@Test
	public void testFloat(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","floatString","155.5678").dataType("Float").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof Float);
		assertEquals(new Float("155.5678"),obj);
	}
	
	@Test
	public void testDouble(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","doubleString","15545678.56786789").dataType("Double").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof Double);
		assertEquals(new Double("15545678.56786789"),obj);
	}
	
	@Test
	public void testBigDecimal(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","bigDecimalString","15545678.56786789").dataType("BigDecimal").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof BigDecimal);
		assertEquals(new BigDecimal("15545678.56786789"),obj);
	}
	
	@Test
	public void testBigInteger(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","bigIntegerString","1554567856786789").dataType("BigInteger").build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof BigInteger);
		assertEquals(new BigInteger("1554567856786789"),obj);
	}
	
	@Test
	public void testSimpleList(){
		Map<String,Object> metadata = new MetadataBuilder("testGroup","simpleList",Arrays.asList("EQUITY","DEBT")).build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof List);
		assertEquals("EQUITY",((List)obj).get(0));
		assertEquals("DEBT",((List)obj).get(1));
	}
	
	@Test
	public void testComplexList(){
		Map<String,Object> testMap = new HashMap<String, Object>();
        testMap.put("date.now", LocalDate.now());
        testMap.put("date.time.now", LocalDateTime.now());
        testMap.put("trade", new Trade());
		Map<String,Object> metadata = new MetadataBuilder("testGroup","complexList",Arrays.asList("EQUITY",LocalDate.now(),LocalDateTime.now(),testMap)).build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof List);
		assertEquals("EQUITY",((List)obj).get(0));
		assertEquals(LocalDate.now(),((List)obj).get(1));
		assertTrue(((List)obj).get(2) instanceof LocalDateTime);
		assertEquals(testMap,((List)obj).get(3));
	}
	
	@Test
	public void testSimpleMap(){
		Map<String,Object> testMap = new HashMap<String, Object>();
        testMap.put("date.now", LocalDate.now());
        testMap.put("date.time.now", LocalDateTime.now());
        testMap.put("trade", new Trade());
		Map<String,Object> metadata = new MetadataBuilder("testGroup","simpleMap",testMap).build();
		Object obj = new MetadataTypeSupportHandler(metadata).getValue();
		assertTrue(obj instanceof Map);
		Map map = (Map) obj;
		assertTrue(map.get("date.now") instanceof LocalDate);
		assertTrue(map.get("date.time.now") instanceof LocalDateTime);
		assertTrue(map.get("trade") instanceof Trade);
	}

}
