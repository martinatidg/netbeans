package com.citi.reghub.core.rules.client;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.citi.reghub.core.metadata.client.Metadata;

public class RuleBuilder {

    private List<Metadata> metadata = new ArrayList<>();

    public RuleBuilder metadata(String name, String key, String cacheName){
        this.metadata.add(new Metadata(name,key,null,cacheName));
        return this;
    }

    public Rule build(String id, String name, String definitionFileName, String resultCode) {
        return new Rule(id, name, definitionAsBase64Encoding(definitionFileName), resultCode, metadata);
    }


    public String definitionAsBase64Encoding(String fileName) {
        try {
            Path resourcePath =  Paths.get(new File("src/test/resources/rules/" + fileName).getAbsoluteFile().toURI());
            byte[] ruleDefinition = Files.readAllBytes(resourcePath);
            byte[] encodedRule = Base64.getEncoder().encode(ruleDefinition);
            return new String(encodedRule);
        } catch (IOException e) {
            throw new RuntimeException("Error loading drools rule file: " + fileName, e);
        }
    }

}
