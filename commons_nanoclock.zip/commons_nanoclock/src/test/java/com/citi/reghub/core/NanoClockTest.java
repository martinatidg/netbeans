package com.citi.reghub.core;

import org.junit.Assert;
import org.junit.Test;


public class NanoClockTest {
	private static final long NANOSECONDS = 1000_000L; 

	@Test
	public void testGetCurrentTimestamp() {
		Long currentMilli = System.currentTimeMillis();
		Long currentnano = NanoClock.currentNanoTimeStamp();
		System.out.println("currentmilli   = " + currentMilli);
		System.out.println("currentnano    = " + currentnano);

		Long convertToNano = NanoClock.convertMilliToNano(currentMilli);
		System.out.println("convertToNano  = " + convertToNano);
		Assert.assertEquals(currentMilli * NANOSECONDS, convertToNano * 1);
	}
}
