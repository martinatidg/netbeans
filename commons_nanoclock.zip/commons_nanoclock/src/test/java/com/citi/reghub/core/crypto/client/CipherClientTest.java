package com.citi.reghub.core.crypto.client;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.citi.reghub.core.cache.client.CacheClient;

//@Ignore
public class CipherClientTest {
	

	CipherClient cipherClient;
	
	CacheClient cacheClient;
	
	String iv = "+++++++#########";
	
	String keyFilePath = "/home/reghub/keystore/test";
	String keyRef = "hrmsTraderKey";
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before
	public void setUp(){
		cacheClient = mock(CacheClient.class);
		Map<String,String> config = new HashMap();
		config.put("cipher.key.store", "file");
		config.put("cipher.filestore.keyFilePath", keyFilePath);
		cipherClient= CipherClientFactory.getInstance(config, cacheClient);

		SecretKey key = generateKey();
        when(cacheClient.get(keyRef,prepareCacheClientConfig()))
        .thenReturn(key);
	}
	
	@Test
	public void testGetKeyNull(){
		assertNull(cipherClient.getKey("abcd"));
	}

	@Test
	public void testGetKeyNotNull(){
		assertNotNull(cipherClient.getKey(keyRef));
	}
	
	@Test
	public void testEncryptDecrypt() {
		String cipherText = cipherClient.encrypt("my test string", keyRef, iv);
		assertEquals(cipherClient.decrypt(cipherText, keyRef, iv), "my test string");
	}

	private SecretKey generateKey() {
		try {
			KeyGenerator keygen = KeyGenerator.getInstance(AbstractCipherClient.ALGO) ;   
			keygen.init(AbstractCipherClient.AES_KEY_SIZE) ;   
			return keygen.generateKey();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private Map prepareCacheClientConfig(){
        Map props = new HashMap<>();
        props.put(CacheClient.CACHE_COLLECTION_NAME, AbstractCipherClient.CACHE_CRYPTO_KEY_COLLECTION);
        props.put(CacheClient.CACHE_COLLECTION_TYPE, AbstractCipherClient.CACHE_CRYPTO_KEY_COLLECTION_TYPE);
        return props;
    }
    
}
