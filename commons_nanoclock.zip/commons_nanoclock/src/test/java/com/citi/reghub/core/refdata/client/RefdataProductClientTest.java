package com.citi.reghub.core.refdata.client;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;

import com.citi.ocean.dataobject.product.OceanProductSummary;

public class RefdataProductClientTest {

	RefdataSecurityClient refdataProductClient;
	OceanGemfireCacheClient oceanGemfireCacheClient;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	
	@Before
	public void setup() {
		oceanGemfireCacheClient = Mockito.mock(OceanGemfireCacheClient.class);
		refdataProductClient = new RefdataSecurityClient(oceanGemfireCacheClient);
	}

	@Test
	//failed 
	public void shouldReturnProductsByFII() {
		OceanProductSummary summary = new OceanProductSummary();
		Long fii = 32408314L;
		summary.setFii(fii);
		summary.setOceanProductId(324083140000L);

		when(oceanGemfireCacheClient.getProductsByFII(fii)).thenReturn(summary);

		Map<String, Object> result = refdataProductClient.getData(SecurityIdentifier.FII.name(), fii);
		assertEquals(result.get("fii"), fii);
	}

	@Test
	//failed 
	public void shouldReturnProductsByISIN() {
		OceanProductSummary oceanInfo = new OceanProductSummary();
		oceanInfo.setIsin("DE0007236101");
		oceanInfo.setCusip("D69671218");
		oceanInfo.setOceanProductId(10106678L);

		when(oceanGemfireCacheClient.getProductsByISIN("DE0007236101")).thenReturn(oceanInfo);

		Map<String, Object> result = refdataProductClient.getData(SecurityIdentifier.ISIN.name(), "DE0007236101");
		assertEquals(result.get("isin"), "DE0007236101");
		assertEquals(result.get("cusip"), "D69671218");
	}

	@Test
	//failed 
	public void shouldReturnProductsByCUSIP() {
		OceanProductSummary info = new OceanProductSummary();
		info.setCusip("D69671218");
		//info.setSmcp("64616");
		info.setOceanProductId(10106678L);

		when(oceanGemfireCacheClient.getProductsByCUSIP("D69671218")).thenReturn(info);

		Map<String, Object> result = refdataProductClient.getData(SecurityIdentifier.CUSIP.name(), "D69671218");
		assertEquals(result.get("cusip"), "D69671218");
		//assertEquals(result.get("smcp"), "64616");
	}

	@Test
	//failed 
	public void shouldReturnProductBySMCP() {
		OceanProductSummary prodSummary = new OceanProductSummary();
		prodSummary.setCusip("D69671218");
		prodSummary.setOceanProductId(10106678L);

		when(oceanGemfireCacheClient.getProductsBySMCP("64616")).thenReturn(prodSummary);

		Map<String, Object> result = refdataProductClient.getData(SecurityIdentifier.SMCP.name(), "64616");
		assertEquals(result.get("cusip"), "D69671218");
	}

	@Test
	//failed
	public void shouldReturnProductByOceanId() {
		OceanProductSummary summary = new OceanProductSummary();
		Long oceanId = 10106677L;
		summary.setOceanProductId(10106677L);
		summary.setFii(32408313L);
		summary.setIsin("DE0007236101");
		summary.setCusip("D69671218");
		summary.setSedol("5727973");

		when(oceanGemfireCacheClient.getByOceanProductId(oceanId)).thenReturn(summary);

		Map<String, Object> result = refdataProductClient.getData(SecurityIdentifier.OCEAN_ID.name(), oceanId);
		assertEquals(result.get("oceanProductId"), oceanId);
		assertEquals(result.get("fii"), 32408313L);
		assertEquals(result.get("isin"), "DE0007236101");
		assertEquals(result.get("cusip"), "D69671218");
		assertEquals(result.get("sedol"), "5727973");

	}
	
	@Test
	public void shouldThrowErrorWhenInvalidSecurityIdentifier() {
		expectedEx.expect(RuntimeException.class);
		expectedEx.expectMessage("Invalid input Security Identifier: ISN");
		refdataProductClient.getData("ISN", null);
	}
}
