package com.citi.reghub.core.cache.client;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Trade {
	
	public Long tradeId = 12345L;
	
	public LocalDate tradeDate = LocalDate.now();
	
	public BigDecimal tradePrice = new BigDecimal("1200.25");
	
	@Override
	public boolean equals(Object arg){
		if(arg instanceof Trade){
			Trade that = (Trade) arg;
			if(this.tradeId.equals(that.tradeId)
					&& this.tradeDate.equals(that.tradeDate)
					&& this.tradePrice.equals(that.tradePrice)){
				return true;
			}
		}
		return false;
	}

}
