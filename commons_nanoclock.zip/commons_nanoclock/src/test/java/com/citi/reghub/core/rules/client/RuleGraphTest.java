package com.citi.reghub.core.rules.client;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;

@Ignore
public class RuleGraphTest {

	RestClient restClient;
	RulesClientConfig rulesClientConfig;
	MetadataClientConfig metadataConfig;
	RulesClient rulesClient;
	CacheClient cacheClient;

	@Before
	public void setUp() throws Exception {

		restClient = new RestClient(createDefault());
		String rulesURL = "http://localhost:9081/reghub-api/rules-service/rule-graphs/%s/details";

		cacheClient = mock(CacheClient.class);
		Map metadetaMap = new HashMap();
		when(cacheClient.get(Mockito.anyObject(), Mockito.anyMap())).thenReturn(metadetaMap);
		rulesClientConfig = new RulesClientConfig().set(RulesClientConfig.REST_CLIENT, restClient)
				.set(RulesClientConfig.CACHE_CLIENT, cacheClient).set(RulesClientConfig.RULE_GRAPH_URL_KEY, rulesURL);
		metadataConfig = new MetadataClientConfig().set(MetadataClientConfig.REST_CLIENT, restClient)
				.set(MetadataClientConfig.CACHE_CLIENT, cacheClient).setDefaultMetadataUrl()
				.set(MetadataClientConfig.FLOW_CODE, "FLOW1");
		rulesClient = new RulesClient(rulesClientConfig);
		SingletonMetadataClient.setInstance(metadataConfig);
	}

	private HttpClient createDefault() {
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		CloseableHttpClient client = builder.build();
		return client;
	}

	/**
	 * This test case is for integration testing , it cannot run stand alone as
	 * unit test case, it need the rules service running in the local and the
	 * test rules seeded, uncomment  @test and run it manual 
	 **/
	@SuppressWarnings("unchecked")
	@Test
	public void testRuleGraph_getExceptionDetails() {

		String ruleGraphName = "rule_frame_work_test_grp";
		RuleGraph ruleGraph = rulesClient.load(ruleGraphName);
		RuleGraphResult response = ruleGraph.execute(null, new HashMap(), false);
		assertEquals(EntityStatus.BIZ_EXCEPTION, response.getStatus());
	}

}
