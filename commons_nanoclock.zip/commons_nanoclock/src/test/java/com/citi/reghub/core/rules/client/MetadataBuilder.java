package com.citi.reghub.core.rules.client;


import java.util.HashMap;
import java.util.Map;

public class MetadataBuilder {

    private Object value;

    public MetadataBuilder value(String key, Object value){
        if (this.value instanceof HashMap)
            ((Map)this.value).put(key,value);
        else
            this.value = new HashMap<String,Object>(){{ put(key,value);}};
        return this;
    }

    public MetadataBuilder value(Object value){
        this.value = value;
        return this;
    }

    public Map<String,Object> buildAsMap() {
        return new HashMap<String,Object>(){{
            if (value != null) put("value",value);
        }};
    }

}
