package com.citi.reghub.core;

import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;

public class RawMsgObjectKafkaSerializerDeserializerTest {

	private StreamFactory sf;
	private Kryo kryo;
	RawMsgObjectKafkaSerializerDeserializer serde;
	String lineMsg="This|is|Test|Message|To|Verify";
	String header="Hder1|Hder2|Hder3|Hder4|Hder5|Hder6";
	
	@Before
	public void setup() {
		kryo = new Kryo();
		serde = new RawMsgObjectKafkaSerializerDeserializer();
		
		sf = new StreamFactory() {
			public Output createOutput(OutputStream os) {
				return new Output(os);
			}

			public Output createOutput(OutputStream os, int size) {
				return new Output(os, size);
			}

			public Output createOutput(int size, int limit) {
				return new Output(size, limit);
			}

			public Input createInput(InputStream os, int size) {
				return new Input(os, size);
			}

			public Input createInput(byte[] buffer) {
				return new Input(buffer);
			}
		};
	}

	@Test
	public void testSerializationDeserialization() {

		String sourceID = "M2MUREX0111231";
		RawMsgObject rawRecord = new RawMsgObject(sourceID,lineMsg);
		
		byte[] serBytes = serde.serialize("test_topic", rawRecord);
		RawMsgObject deserRawRecord = serde.deserialize("test_topic", serBytes);
		assertEquals(rawRecord.getRegHubId(), deserRawRecord.getRegHubId());
		assertEquals(rawRecord.getMessage(), deserRawRecord.getMessage());
	}

	@Test
	public void testRawOutboundRecordBackwardCompatibility() {
		CompatibleFieldSerializer<RawMsgObject> serializer = new CompatibleFieldSerializer<RawMsgObject>(kryo, RawMsgObject.class);

		String sourceID = "M2MUREX0121311";
		RawMsgObject rawRecord = new RawMsgObject(sourceID,lineMsg);
		kryo.register(RawMsgObject.class, serializer);

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		Output output = sf.createOutput(outStream, 4096);
		kryo.writeClassAndObject(output, rawRecord);
		output.flush();

		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		RawMsgObject deserRawRecord = (RawMsgObject) kryo.readClassAndObject(input);

		assertEquals(rawRecord.getRegHubId(), deserRawRecord.getRegHubId());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRawOutboundRecordDeserilizationException() {
		
		String sourceUID = "M2MUREX0121311";
		RawMsgObject rawRecord = new RawMsgObject(sourceUID,lineMsg);		

		byte[] serBytes = serde.serialize("test_topic", rawRecord);
		serBytes = new byte[4096];
		RawMsgObject deserRawRecord = serde.deserialize("test_topic",  serBytes);
		assertEquals(rawRecord.getRegHubId(), deserRawRecord.getRegHubId());
	}

	static interface StreamFactory {
		public Output createOutput(OutputStream os);

		public Output createOutput(OutputStream os, int size);

		public Output createOutput(int size, int limit);

		public Input createInput(InputStream os, int size);

		public Input createInput(byte[] buffer);
	}
}
