package com.citi.reghub.core;

import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;

public class RawOutboundRecordKafkaSerdeTest {

	private StreamFactory sf;
	private Kryo kryo;
	RawOutboundRecordSerializerDeserializer serde;
	
	@Before
	public void setup() {
		kryo = new Kryo();
		serde = new RawOutboundRecordSerializerDeserializer();
		
		sf = new StreamFactory() {
			public Output createOutput(OutputStream os) {
				return new Output(os);
			}

			public Output createOutput(OutputStream os, int size) {
				return new Output(os, size);
			}

			public Output createOutput(int size, int limit) {
				return new Output(size, limit);
			}

			public Input createInput(InputStream os, int size) {
				return new Input(os, size);
			}

			public Input createInput(byte[] buffer) {
				return new Input(buffer);
			}
		};
	}

	@Test
	public void testSerializationDeserialization() {
		RawOutboundRecord rawRecord = new RawOutboundRecord(new EntityBuilder().build());
		rawRecord.regHubId = "M2TRCSHEQ110789";

		byte[] serBytes = serde.serialize("test_topic", rawRecord);
		RawOutboundRecord deserRawRecord = serde.deserialize("test_topic", serBytes);
		assertEquals(rawRecord.regHubId, deserRawRecord.regHubId);
	}

	@Test
	public void testRawOutboundRecordBackwardCompatibility() {
		CompatibleFieldSerializer<RawOutboundRecord> serializer = new CompatibleFieldSerializer<RawOutboundRecord>(kryo, RawOutboundRecord.class);

		RawOutboundRecord rawRecord = new RawOutboundRecord(new EntityBuilder().build());
		serializer.removeField("regHubId");
		kryo.register(RawOutboundRecord.class, serializer);

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		Output output = sf.createOutput(outStream, 4096);
		kryo.writeClassAndObject(output, rawRecord);
		output.flush();

		byte[] out = outStream.toByteArray();
		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		RawOutboundRecord deserRawRecord = (RawOutboundRecord) kryo.readClassAndObject(input);

		assertThat(rawRecord.regHubId, not(deserRawRecord.regHubId));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRawOutboundRecordDeserilizationException() {
		RawOutboundRecord rawRecord = new RawOutboundRecord(new EntityBuilder().build());
		rawRecord.regHubId = "M2TRCSHEQ110789";

		byte[] serBytes = serde.serialize("test_topic", rawRecord);
		serBytes = new byte[4096];
		RawOutboundRecord deserRawRecord = serde.deserialize("test_topic",  serBytes);
		assertEquals(rawRecord.regHubId, deserRawRecord.regHubId);
	}

	static interface StreamFactory {
		public Output createOutput(OutputStream os);

		public Output createOutput(OutputStream os, int size);

		public Output createOutput(int size, int limit);

		public Input createInput(InputStream os, int size);

		public Input createInput(byte[] buffer);
	}
}
