package com.citi.reghub.core.entity.client;

import org.junit.Test;

public class EntityClientTest {

	// Disabled. The test case is useful only when the Entity service is available.

	@Test
	public void testGetLatestEntityBySourceId2() {

//		String ENTITY_URL_VALUE = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
//		EntityClientConfig entityClientConfig = new EntityClientConfig();
//		RestClient restClient = new RestClient(HttpClients.createDefault());
//		entityClientConfig.set(EntityClientConfig.REST_CLIENT, restClient);
//		entityClientConfig.set(EntityClientConfig.ENTITY_URL_KEY, ENTITY_URL_VALUE);
//
//		EntityClient entityClient = new EntityClient(entityClientConfig);
//		Entity entity = entityClient.getLatestEntityBySourceId("03550600LDN822356267");
//		
//		Assert.assertNotNull("The entity is null", entity);

	}
}
