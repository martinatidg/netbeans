package com.citi.reghub.core.metadata.client;

import java.util.HashMap;
import java.util.Map;

public class MetadataBuilder {
	
	private Map<String,Object> map = new HashMap<String,Object>();
	
	public MetadataBuilder(String group,String name,Object value) {
		map.put("group", group);
		map.put("name", name);
		map.put("value", value);
	}
	
	public MetadataBuilder dataType(String dataType){
		map.put("dataType", dataType);
		return this;
	}
	
	public MetadataBuilder format(String format){
		map.put("format", format);
		return this;
	}
	
	public Map build(){
		return map;
	}
	

}
