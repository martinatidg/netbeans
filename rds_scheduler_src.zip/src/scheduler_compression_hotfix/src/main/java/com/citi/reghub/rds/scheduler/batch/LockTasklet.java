package com.citi.reghub.rds.scheduler.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.citi.reghub.rds.scheduler.export.ExportRequest;
import com.citi.reghub.rds.scheduler.service.ExportLock;
import com.citi.reghub.rds.scheduler.service.LockException;
import com.citi.reghub.rds.scheduler.service.ZooKeeperService;

public class LockTasklet implements Tasklet {
	private static final Logger LOGGER = LoggerFactory.getLogger(LockTasklet.class);
	@Autowired
	ZooKeeperService zkService;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Step 2: Start Lock tasklet.");
		ExportRequest request = (ExportRequest) chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext().get("request");
		ExportLock lock = null;
		try {
			lock = zkService.acquireExportLock(request.getDatabase(), request.getCollection());

			if (lock != null) {
				LOGGER.trace("Step 2: Export lock: {}.", lock);
				request.setLock(lock);
				// TODO: assignFrom TS
				// TODO: assignTo TS
			}
		} catch (LockException le) {
			LOGGER.warn("Step2: Could not obtain the lock due to {}", le.getMessage());
			return RepeatStatus.FINISHED;
		}

		LOGGER.trace("Step 2: Export request: {}.", request);

		LOGGER.info("Step 2: Lock tasklet was finished.");

		return RepeatStatus.FINISHED;
	}
}
