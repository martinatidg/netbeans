package com.citi.reghub.rds.scheduler.compression;

import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Before;
//import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.citi.reghub.rds.scheduler.compression.Compressor;
import com.citi.reghub.rds.scheduler.compression.Compressors;

@SpringBootTest
public class ZipCompressorTest {
	String inputDirPath = "C:\\temp\\compressorTest\\dirPath";
	String zipDirPath = "C:\\temp\\compressorTest\\dirPath.zip";

	@Before
	public void init() throws IOException {
		Files.deleteIfExists(Paths.get(zipDirPath));
	}

	@Test
	public void testZip1() throws IOException {
		Compressor compressor = Compressors.zipCompressor();

		compressor.compress(inputDirPath, zipDirPath);
		
		assertTrue("File not zipped.", Files.exists(Paths.get(zipDirPath)));
	}
}
