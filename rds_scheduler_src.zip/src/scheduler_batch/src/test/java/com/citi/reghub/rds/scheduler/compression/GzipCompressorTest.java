package com.citi.reghub.rds.scheduler.compression;

import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Before;
//import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.citi.reghub.rds.scheduler.compression.Compressor;
import com.citi.reghub.rds.scheduler.compression.Compressors;

@SpringBootTest
public class GzipCompressorTest {
	String inputFilePath = "C:\\temp\\compressorTest\\scanservice.log";
	String zipFilePath = "C:\\temp\\compressorTest\\scanservice.log.gzip";
	
	@Before
	public void init() throws IOException {
		Files.deleteIfExists(Paths.get(zipFilePath));
	}

	@Test
	public void testZip1() throws IOException {
		Compressor compressor = Compressors.gzipCompressor();

		compressor.compress(inputFilePath, zipFilePath);
		
		assertTrue("File not zipped.", Files.exists(Paths.get(zipFilePath)));
	}
}
