package com.citi.reghub.rds.scheduler.compression;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZipCompressor implements Compressor {
	@Override
	public void compress(String fileName) throws IOException {
		String zipFileName = fileName + ".zip";
		compress(fileName, zipFileName);
	}

	@Override
	public void compress(String fileName, String zipFileName) throws IOException {
		zipFileName += (zipFileName.endsWith(".zip") ? "" : ".zip");
		Path filePath = Paths.get(fileName);
		Path zipFilePath = Paths.get(zipFileName);

		Files.deleteIfExists(zipFilePath);

		if (Files.isDirectory(filePath)) {
			compress(filePath.toFile(), zipFilePath.toFile());
		} else {
			zipFile(fileName, zipFileName);
		}
	}

	public void zipFile(String filePath, String zipFilePath) throws IOException {
		byte[] buffer = new byte[1024];

		try (FileInputStream inputFile = new FileInputStream(filePath);
				ZipOutputStream zoutStream = new ZipOutputStream(new FileOutputStream(zipFilePath))) {
			int len;
			while ((len = inputFile.read(buffer)) > 0) {
				zoutStream.write(buffer, 0, len);
			}

			zoutStream.finish();
		}
	}

	@Override
	public void decompress(String zipFilePath) throws IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public void decompress(String zipFilePath, String filePath) throws IOException {
		// TODO Auto-generated method stub

	}

	public void compress(File dir, File toFile) throws IOException {
		System.out.println("compress(), AbsolutePath(), toFile = " + toFile.getAbsolutePath() + ", dir = "
				+ dir.getAbsolutePath());
		System.out.println("compress(), CanonicalPath(), toFile = " + toFile.getCanonicalPath() + ", dir = "
				+ dir.getCanonicalPath());
		try {
			if (dir == null || !dir.exists() || !dir.isDirectory()) {
				throw new IOException("Invalid input directory: " + dir);
			}

			FileOutputStream fos = new FileOutputStream(toFile);
			ZipOutputStream outs = new ZipOutputStream(fos);

			// FileSystem fs = new FileSystem(dir);
			Path dirPath = dir.toPath();
			Iterator<Path> allFiles = dirPath.iterator();
			System.out.println("compress(),dirPath = " + dirPath.toAbsolutePath());

			while (allFiles.hasNext()) {
				// File srcFile = (File) allFiles.next();
				Path srcFile = allFiles.next();
				System.out.println("compress(), while toString, srcFile = " + srcFile.toString());
				System.out.println("compress(), while CanonicalPath(), srcFile = " + srcFile.toAbsolutePath());

				String filepath = srcFile.toString();
				String dirpath = dir.getAbsolutePath();
				String entryName = filepath.substring(dirpath.length() + 1).replace('\\', '/');

				ZipEntry zipEntry = new ZipEntry(entryName);
				zipEntry.setTime(srcFile.toFile().lastModified());
				FileInputStream ins = new FileInputStream(srcFile.toFile());
				outs.putNextEntry(zipEntry);
				pipe(ins, outs);
				outs.closeEntry();
				ins.close();
			}

			outs.close();

		} catch (Exception e) {
			throw new IOException("Unable to compress zip file: " + toFile, e);
		}
	}

	private void zipDir(File directoryToZip, List<File> fileList) {

		try {
			FileOutputStream fos = new FileOutputStream(directoryToZip.getName() + ".zip");
			ZipOutputStream zos = new ZipOutputStream(fos);

			for (File file : fileList) {
				if (!file.isDirectory()) { // we only zip files, not directories
					addToZip(directoryToZip, file, zos);
				}
			}

			zos.close();
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void addToZip(File directoryToZip, File file, ZipOutputStream zos)
			throws FileNotFoundException, IOException {

		FileInputStream fis = new FileInputStream(file);

		// we want the zipEntry's path to be a relative path that is relative
		// to the directory being zipped, so chop off the rest of the path
		String zipFilePath = file.getCanonicalPath().substring(directoryToZip.getCanonicalPath().length() + 1,
				file.getCanonicalPath().length());
		System.out.println("Writing '" + zipFilePath + "' to zip file");
		ZipEntry zipEntry = new ZipEntry(zipFilePath);
		zos.putNextEntry(zipEntry);

		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zos.write(bytes, 0, length);
		}

		zos.closeEntry();
		fis.close();
	}

	public void unzip(String zipFilename) throws Exception {
		try (FileInputStream fis = new FileInputStream(zipFilename);
				ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis))) {
			ZipEntry entry;

			while ((entry = zis.getNextEntry()) != null) {
				System.out.println("Unzipping: " + entry.getName());

				int size;
				byte[] buffer = new byte[2048];

				FileOutputStream fos = new FileOutputStream(entry.getName());
				BufferedOutputStream bos = new BufferedOutputStream(fos, buffer.length);

				while ((size = zis.read(buffer, 0, buffer.length)) != -1) {
					bos.write(buffer, 0, size);
				}
				bos.flush();
				bos.close();
			}
//			zis.close();
//			fis.close();
		}
	}

	public static void pipe(InputStream ins, OutputStream out) throws IOException {
		byte[] buffer = new byte[512];

		int len = ins.read(buffer);
		while (len != -1) {
			out.write(buffer, 0, len);
			len = ins.read(buffer);
		}
		out.flush();
	}
}
