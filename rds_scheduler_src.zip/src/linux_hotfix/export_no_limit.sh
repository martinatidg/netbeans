HOST=$1
PORT=$2
AUTH_DB=$3
AUTH_MSM=$4
DB=$5
COLLECTION=$6
FROM_DT=$7
TO_DT=$8
OUTPATH=$9
USERNAME=$10
PASSWORD=$11
/tmp/scheduler/mongoUtils/mongoexport  --host $HOST --port $PORT --ssl  --sslAllowInvalidCertificates  --authenticationDatabase $AUTH_DB --authenticationMechanism $AUTH_MSM --db $DB --collection $COLLECTION --query "{lastUpdatedTs : {'$gte' : new Date($FROM_DT), '$lte': new Date($TO_DT)}}" --jsonArray  --out $OUTPATH --username $USERNAME --password $PASSWORD