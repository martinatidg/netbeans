# Remote Data Store Scheduler Service 

## MicroService Built using Spring Boot

RDS scheduler provides functionality of scheduled data export from MongoDB and pushing it into Hadoop cluster 

Main settings are available in application.properties. User should set parameters for MongoDb and ZooKeeper either in application.properties files, environment variables or in command line. Following are the settings should be provided:

	--rds.scheduler.mongo.username			# username for MongoDB
	--rds.scheduler.mongo.password			# password for MongoDB
	--rds.scheduler.mongo.binaryPath		# MongoDB binary path
	--rds.scheduler.mongo.host				# MongoDB host
	--rds.scheduler.mongo.port				# MongoDB port
	--rds.scheduler.zk.nodes					# Zookeeper node
	

