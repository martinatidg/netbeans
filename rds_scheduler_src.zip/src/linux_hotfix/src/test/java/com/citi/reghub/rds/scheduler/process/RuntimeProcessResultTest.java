package com.citi.reghub.rds.scheduler.process;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RuntimeProcessResultTest {
	private RuntimeProcessResult result;

	@Before
	public void init() {
		result = new RuntimeProcessResult();
	}

	@Test
	public void testIsCompleteSuccessfully() {
		result.setCompleteSuccessfully(true);
		Assert.assertTrue("The result should be true but it is false.", result.isCompleteSuccessfully());
	}

	@Test
	public void testGetOutput() {
		Collection<String> expected = new ArrayList<>();
		expected.add("output01");
		expected.add("output02");
		expected.add("output03");

		result.setOutput(expected);
		Collection<String> actual = result.getOutput();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testGetError() {
		Collection<String> expected = new ArrayList<>();
		expected.add("error01");
		expected.add("error02");
		expected.add("error03");

		result.setOutput(expected);
		Collection<String> actual = result.getOutput();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}
}
