package com.citi.reghub.rds.scheduler;

import org.junit.Before;
import org.junit.Test;

public class ValidateListenerTest {
	private ValidateListener validateListener;

	@Before
	public void init() {
		validateListener = new ValidateListener();
	}
	
	@Test(expected = Exception.class)
	public void testOnApplicationEvent() {
		validateListener.onApplicationEvent(null);
	}
}
