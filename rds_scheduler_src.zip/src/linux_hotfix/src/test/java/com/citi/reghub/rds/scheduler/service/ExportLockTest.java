package com.citi.reghub.rds.scheduler.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ExportLockTest {
	private ExportLock lock;

	@Before
	public void init() {
		lock = new ExportLock();
	}

	@Test
	public void testDb() {
		String expected = "db";
		lock.setDb(expected);
		String actual = lock.getDb();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testCollection() {
		String expected = "collection";
		lock.setCollection(expected);
		String actual = lock.getCollection();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testLastExportTimestamp() {
		long expected = 1497891600000l;
		lock.setLastExportTimestamp(expected);
		long actual = lock.getLastExportTimestamp();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testNewExportTimestamp() {
		long expected = 1497891600000l;
		lock.setNewExportTimestamp(expected);
		long actual = lock.getNewExportTimestamp();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testToString() {
		String db = "db";
		String collection = "collection";
		long lastExportTimestamp = 1249376400000l;
		long newExportTimestamp = 1249376400000l;

		lock.setDb(db);
		lock.setCollection(collection);
		lock.setLastExportTimestamp(lastExportTimestamp);
		lock.setNewExportTimestamp(newExportTimestamp);

		String expected = "ExportLock [db=" + db + ", collection=" + collection + ", lastExportTimestamp="
				+ lastExportTimestamp + ", newExportTimestamp=" + newExportTimestamp + "]";
		String actual = lock.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testHashCode() {
		String db = "db";
		String collection = "collection";
		long lastExportTimestamp = 1249376400000l;
		long newExportTimestamp = 1249376400000l;

		lock.setDb(db);
		lock.setCollection(collection);
		lock.setLastExportTimestamp(lastExportTimestamp);
		lock.setNewExportTimestamp(newExportTimestamp);

		ExportLock lock2 = new ExportLock();
		lock2.setDb(db);
		lock2.setCollection(collection);
		lock2.setLastExportTimestamp(lastExportTimestamp);
		lock2.setNewExportTimestamp(newExportTimestamp);

		Assert.assertEquals("The 2 objects should have the same hashcode but they do not.", lock, lock2);
	}

	@Test
	public void testEquals() {
		String db = "db";
		String collection = "collection";
		long lastExportTimestamp = 1249376400000l;
		long newExportTimestamp = 1249376400000l;

		lock.setDb(db);
		lock.setCollection(collection);
		lock.setLastExportTimestamp(lastExportTimestamp);
		lock.setNewExportTimestamp(newExportTimestamp);

		ExportLock lock2 = new ExportLock();
		lock2.setDb(db);
		lock2.setCollection(collection);
		lock2.setLastExportTimestamp(lastExportTimestamp);
		lock2.setNewExportTimestamp(newExportTimestamp);

		boolean actual = lock.equals(lock2);
		Assert.assertTrue("The 2 objects should be equal but they are not.", actual);

		db = "db2";
		lock2.setDb(db);
		actual = lock.equals(lock2);
		Assert.assertFalse("The 2 objects should not be equal but but they are.", actual);
	}
}
