package com.citi.reghub.rds.scheduler.service;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@TestPropertySource(locations="classpath:test.properties")
public class MetadataServiceTest {
	@Autowired
	private MetadataService metadataService;

	@Test
	public void testGetDatabase() {
		String resultDb = metadataService.getDatabase();
		Assert.assertNotNull("Database name is null", resultDb);

		boolean emptyDb = resultDb.trim().isEmpty();
		Assert.assertFalse("Database name is empty.", emptyDb);
	}

	@Test
	public void testGetCollection() {
		String resultCollection = metadataService.getCollection();
		Assert.assertNotNull("Collection name is null.", resultCollection);
		boolean emptyCollection = resultCollection.trim().isEmpty();
		Assert.assertFalse("Collection name is empty.", emptyCollection);
	}

	@Test
	public void testGetDatabases() {
		Map<String, List<String>> dbs = metadataService.getDatabases();
		Assert.assertNotNull(dbs);
	}
}
