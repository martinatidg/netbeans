package com.citi.reghub.rds.scheduler.export;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ExportResponseTest {
	private ExportResponse response;

	@Before
	public void init() {
		response = new ExportResponse();
	}

	@Test
	public void testSuccessful() {
		boolean expected = true;
		response.setSuccessful(expected);
		boolean actual = response.isSuccessful();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testRecords() {
		String expected = "records";
		response.setRecords(expected);
		String actual = response.getRecords();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testLastMessage() {
		String expected = "lastMessage";
		response.setLastMessage(expected);
		String actual = response.getLastMessage();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testExportPath() {
		String expected = "/test/path/export";
		response.setExportPath(expected);
		String actual = response.getExportPath();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testToString() {
		boolean successful = true;
		String records = "records";
		String lastMessage = "last message";
		String exportPath = "/test/path/export";

		response.setSuccessful(successful);
		response.setRecords(records);
		response.setLastMessage(lastMessage);
		response.setExportPath(exportPath);

		String expected = "ExportResponse [successful=" + successful + ", records=" + records + ", lastMessage="
				+ lastMessage + ", exportPath=" + exportPath + "]";
		String actual = response.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}
}
