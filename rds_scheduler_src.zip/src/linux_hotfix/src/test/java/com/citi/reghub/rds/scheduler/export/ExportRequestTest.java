package com.citi.reghub.rds.scheduler.export;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.rds.scheduler.service.ExportLock;
import com.citi.reghub.rds.scheduler.util.Util;

public class ExportRequestTest {
	private ExportRequest request;

	@Before
	public void init() {
		request = new ExportRequest();
	}

	@Test
	public void testRequestId() {
		String expected = "requestId";
		request.setRequestId(expected);
		String actual = request.getRequestId();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testHostname() {
		String expected = "hostname";
		request.setHostname(expected);
		String actual = request.getHostname();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testPort() {
		int expected = 27017;
		request.setPort(expected);
		int actual = request.getPort();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testDatabase() {
		String expected = "Database";
		request.setDatabase(expected);
		String actual = request.getDatabase();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testCollection() {
		String expected = "Collection";
		request.setCollection(expected);
		String actual = request.getCollection();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testLock() {
		ExportLock expected = new ExportLock();
		request.setLock(expected);
		ExportLock actual = request.getLock();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testLimit() {
		int expected = 10;
		request.setLimit(expected);
		int actual = request.getLimit();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testGetFromTimeStamp() {
		ExportLock lock = new ExportLock();
		long expected = 1249376400000l;
		lock.setLastExportTimestamp(expected);
		request.setLock(lock);
		long actual = request.getFromTimeStamp();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testGetToTimeStamp() {
		ExportLock lock = new ExportLock();
		long expected = 1249376400000l;
		lock.setNewExportTimestamp(expected);
		request.setLock(lock);
		long actual = request.getToTimeStamp();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test
	public void testToString() {
		String requestId = "1";
		String hostname = "localhost";
		int port = 27017;
		String database = "database";
		String collection = "colleaction";
		ExportLock lock = new ExportLock();
		long from = 1249376400000l;
		long to = 1497891600000l;
		lock.setLastExportTimestamp(from);
		lock.setNewExportTimestamp(to);

		request.setRequestId(requestId);
		request.setHostname(hostname);
		request.setPort(port);
		request.setDatabase(database);
		request.setCollection(collection);
		request.setLock(lock);

		String expected = "ExportRequest [requestId=" + requestId + ", hostname=" + hostname + ", port=" + port
				+ ", database=" + database + ", collection=" + collection + ", fromTimeStamp=" + Util.formatDate(from)
				+ "," + " toTimeStamp=" + Util.formatDate(to) + "]";
		String actual = request.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		lock = null;
		request.setLock(lock);
		expected = "ExportRequest [requestId=" + requestId + ", hostname=" + hostname + ", port=" + port + ", database="
				+ database + ", collection=" + collection + ", fromTimeStamp=" + "" + ", toTimeStamp=" + "" + "]";
		actual = request.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}
}
