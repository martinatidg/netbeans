package com.citi.reghub.rds.scheduler.compression;

import java.lang.reflect.Constructor;

import org.junit.Assert;
import org.junit.Test;

public class CompressorsTest {
	@Test(expected = Exception.class)
	public void testConstructor() throws Exception {
		Constructor<Compressors> constructor = Compressors.class.getDeclaredConstructor();
		constructor.newInstance();
	}

	@Test
	public void testGzipCompressor() {
		Compressor result = Compressors.gzipCompressor();
		Assert.assertNotNull("The result is null.", result);
	}

	@Test
	public void testZipCompressor() {
		Compressor result = Compressors.zipCompressor();
		Assert.assertNotNull("The result is null.", result);
	}
}
