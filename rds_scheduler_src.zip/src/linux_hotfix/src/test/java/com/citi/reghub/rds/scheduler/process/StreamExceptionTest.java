package com.citi.reghub.rds.scheduler.process;

import org.junit.Assert;
import org.junit.Test;

public class StreamExceptionTest {
	@Test
	public void testConstructor1() {
		StreamException se = new StreamException(new Exception());
		Assert.assertNotNull("The result is null.", se);

		se = new StreamException("Message");
		Assert.assertNotNull("The result is null.", se);
	}
}
