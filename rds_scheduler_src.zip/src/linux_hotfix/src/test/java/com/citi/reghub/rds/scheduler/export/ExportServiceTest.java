package com.citi.reghub.rds.scheduler.export;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;

public class ExportServiceTest {
	ExportService service;;

	@Before
	public void init() {
		service = new ExportService();
	}

	@Test(expected = Exception.class)
	public void testSubmitRequest() throws InterruptedException, ExecutionException {
		ExportRequest request = new ExportRequest();
		Future<ExportResponse> future = service.submitRequest(request);
		future.get();
	}
}
