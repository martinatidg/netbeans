package com.citi.reghub.rds.scheduler.export;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MongoExportTest {
	private MongoExport export;

	@Before
	public void init() {
		export = new MongoExport();
	}

	@Test
	public void testEnum() {
		boolean isLinux = !System.getProperty("os.name").toLowerCase().contains("win");
		String OS_KEY_PREFIX = isLinux ? " --" : " /";

		String expected = OS_KEY_PREFIX + "host" + " ";
		String actual = MongoExport.Keys.HOST.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "port" + " ";
		actual = MongoExport.Keys.PORT.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "ssl" + " ";
		actual = MongoExport.Keys.SSL.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "sslAllowInvalidCertificates" + " ";
		actual = MongoExport.Keys.SAIC.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "authenticationDatabase" + " ";
		actual = MongoExport.Keys.AUTH_DB.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "authenticationMechanism" + " ";
		actual = MongoExport.Keys.AUTH_MSM.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "db" + " ";
		actual = MongoExport.Keys.DB.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "collection" + " ";
		actual = MongoExport.Keys.COLLECTION.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "query" + " ";
		actual = MongoExport.Keys.QUERY.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "jsonArray" + " ";
		actual = MongoExport.Keys.JSON_ARRAY.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "out" + " ";
		actual = MongoExport.Keys.OUT.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "username" + " ";
		actual = MongoExport.Keys.USERNAME.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "password" + " ";
		actual = MongoExport.Keys.PASSWORD.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);

		expected = OS_KEY_PREFIX + "limit" + " ";
		actual = MongoExport.Keys.LIMIT.toString();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSetRequestNullDB() {
		ExportRequest request = new ExportRequest();
		request.setDatabase(null);
		request.setCollection("collection");
		request.setHostname("host");
		request.setRequestId("1");

		export.setRequest(request);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSetRequestNullCollection() {
		ExportRequest request = new ExportRequest();
		request.setDatabase("db");
		request.setCollection(null);
		request.setHostname("host");
		request.setRequestId("1");

		export.setRequest(request);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSetRequestNullHostname() {
		ExportRequest request = new ExportRequest();
		request.setDatabase("db");
		request.setCollection("collection");
		request.setHostname(null);
		request.setRequestId("1");

		export.setRequest(request);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSetRequestNullRequestId() {
		ExportRequest request = new ExportRequest();
		request.setDatabase("db");
		request.setCollection("collection");
		request.setHostname("host");
		request.setRequestId(null);

		export.setRequest(request);
	}
}
