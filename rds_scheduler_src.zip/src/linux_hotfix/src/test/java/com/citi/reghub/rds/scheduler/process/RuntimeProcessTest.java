package com.citi.reghub.rds.scheduler.process;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RuntimeProcessTest {
	@Before
	public void inti() {
	}

	@Test
	public void testConstructor() {
		RuntimeProcess process = new RuntimeProcess("processName");
		Assert.assertNotNull("The result is null.", process);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testExecute() throws ProcessException {
		RuntimeProcess process = new RuntimeProcess(null);
		process.execute();
	}
}
