package com.citi.reghub.rds.scheduler.process;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class StreamGobblerTest {
	private StreamGobbler streamGobbler;
	private File file;

	@Before
	public void init() {
		file = new File(System.getProperty("java.io.tmpdir") + File.separator + "test");
		try {
			file.createNewFile();
			InputStream input = new FileInputStream(file);
			String type = "type";
			streamGobbler = new StreamGobbler(input, type);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetContents() {
		List<String> result = streamGobbler.getContents();
		Assert.assertNotNull("The result is null.", result);

		String expected = "type";
		String actual = streamGobbler.getType();
		Assert.assertEquals("The result is not expected.", expected, actual);
	}

	@After
	public void clean() {
		if (file != null && file.exists()) {
			file.delete();
		}
	}
}
