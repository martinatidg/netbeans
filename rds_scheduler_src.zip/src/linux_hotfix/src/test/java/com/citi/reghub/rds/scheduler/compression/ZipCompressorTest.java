package com.citi.reghub.rds.scheduler.compression;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.After;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ZipCompressorTest {
	private String sourceDirname = TestZip.TESTPATH + File.separator + "dirTest";
	private String destDirnameZip = TestZip.TESTPATH + File.separator + "dirTest.zip";
	private String sourceFilename = TestZip.TESTPATH + File.separator + "fileTest";
	private String destFilename = TestZip.TESTPATH + File.separator + "fileTestNoExt";
	private String destFilenameZip = TestZip.TESTPATH + File.separator + "fileTest.zip";
	private String testdecompression = TestZip.TESTPATH + File.separator + "testdecompression";

	private TestZipDirectory testDir;
	private TestZipFile testFile;

	@Test
	public void testZipDirectoryWithDest() throws IOException {
		testDir = new TestZipDirectory(sourceDirname, destDirnameZip);
		testDir.initialize();

		Compressor compressor = Compressors.zipCompressor();
		compressor.compress(sourceDirname, destDirnameZip);
		assertTrue("File not zipped.", Files.exists(Paths.get(destDirnameZip)));
	}

	@Test
	public void testZipDirectoryNoDest() throws IOException {
		testDir = new TestZipDirectory(sourceDirname);
		testDir.initialize();

		Compressor compressor = Compressors.zipCompressor();
		compressor.compress(sourceDirname);
		assertTrue("File not zipped.", Files.exists(Paths.get(destDirnameZip)));
	}

	@Test
	public void testZipFileWithDestZipExt() throws IOException {
		testFile = new TestZipFile();
		testFile.createTextFile(sourceFilename);

		Compressor compressor = Compressors.zipCompressor();
		Path zipPath = compressor.compress(sourceFilename, destFilenameZip);
		testFile.setDestZipPath(zipPath);

		assertTrue("File not zipped.", zipPath.toFile().exists());
	}

	@Test
	public void testZipFileWithDestNoExt() throws IOException {
		testFile = new TestZipFile();
		testFile.createTextFile(sourceFilename);

		Compressor compressor = Compressors.zipCompressor();
		Path zipPath = compressor.compress(sourceFilename, destFilename);
		testFile.setDestZipPath(zipPath);

		assertTrue("File not zipped.", zipPath.toFile().exists());
	}

	@Test
	public void testZipFileNoDest() throws IOException {
		testFile = new TestZipFile();
		testFile.createTextFile(sourceFilename, FileType.ZIP);

		Compressor compressor = Compressors.zipCompressor();
		Path zipPath = compressor.compress(sourceFilename);
		assertTrue("File not zipped.", zipPath.toFile().exists());
	}

	@Test
	public void testDecompressFile() throws IOException {
		testFile = new TestZipFile();
		Path zipPath = testFile.createZipFile(testdecompression);

		Compressor compressor = Compressors.zipCompressor();
		Path decompressedPath = compressor.decompress(zipPath.toString());

		assertTrue("File not zipped.", decompressedPath.toFile().exists());
	}

	@After
	public void clean() throws IOException {
		if (testFile != null) {
			testFile.clean();
		}

		if (testDir != null) {
			testDir.clean();
		}
	}
}
