package com.citi.reghub.rds.scheduler.compression;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GzipCompressorTest {
	String sourceFile = TestZip.TESTPATH + File.separator + "gzipFileTest";
	String destZipFile = TestZip.TESTPATH + File.separator + "gzipFileTest.gzip";
	TestZipFile testFile;

	private Compressor compressor;

	@Before
	public void init() {
		compressor = Compressors.gzipCompressor();
	}

	@Test
	public void testCompressWithDest() throws IOException {
		testFile = new TestZipFile();
		testFile.createTextFile(sourceFile);

		Path zipPath = compressor.compress(sourceFile, destZipFile);
		testFile.setDestZipPath(zipPath);

		assertTrue("File not zipped.", zipPath.toFile().exists());
	}

	@Test
	public void testCompressNoDest() throws IOException {
		testFile = new TestZipFile();
		testFile.createTextFile(sourceFile, FileType.GZIP);

		Path zipPath = compressor.compress(sourceFile);

		assertTrue("File not zipped.", zipPath.toFile().exists());
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testDecompress() throws IOException {
		compressor.decompress(sourceFile);
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testDecompressWithDest() throws IOException {
		compressor.decompress(sourceFile, destZipFile);
	}

	@After
	public void clean() throws IOException {
		if (testFile != null) {
			testFile.clean();
		}
	}
}
