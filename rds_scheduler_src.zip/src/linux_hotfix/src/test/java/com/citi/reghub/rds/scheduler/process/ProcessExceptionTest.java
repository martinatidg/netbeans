package com.citi.reghub.rds.scheduler.process;

import org.junit.Assert;
import org.junit.Test;

public class ProcessExceptionTest {
	@Test
	public void testConstructor() {
		ProcessException ex = new ProcessException();
		Assert.assertNotNull("The result is null.", ex);
	}
}
