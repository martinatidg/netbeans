package com.citi.reghub.rds.scheduler.service;

@SuppressWarnings("serial")
public class LockException extends Exception {

	public LockException(Throwable cause) {
		super(cause);
	}

	public LockException(String message) {
		super(message);
	}

}
