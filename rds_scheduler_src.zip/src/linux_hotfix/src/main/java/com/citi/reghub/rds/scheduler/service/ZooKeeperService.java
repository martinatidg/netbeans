package com.citi.reghub.rds.scheduler.service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.locks.InterProcessSemaphoreMutex;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.KeeperException.NoNodeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.primitives.Longs;

@Service
public class ZooKeeperService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ZooKeeperService.class);
	private Map<String, InterProcessSemaphoreMutex> mutexMap = new HashMap<>();

	@Value("${rds.scheduler.zk.nodes}")
	private String server;
	@Value("${rds.scheduler.zk.lockpath}")
	private String lockPath;
	@Value("${rds.scheduler.zk.tstamppath}")
	private String tstampPath;

	private CuratorFramework client;

	@PostConstruct
	private void init() {
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		client = CuratorFrameworkFactory.newClient(server, retryPolicy);
		client.start();
	}

	private String getPath(String db, String collection, String prefix) {
		String del = "/";
		return prefix + del + db + del + collection;
	}

	private synchronized InterProcessSemaphoreMutex getMutex(String db, String collection) {
		String fullPath = getPath(db, collection, this.lockPath);

		InterProcessSemaphoreMutex mutex = mutexMap.get(fullPath);
		if (mutex == null) {
			mutex = new InterProcessSemaphoreMutex(client, fullPath);
			mutexMap.put(fullPath, mutex);
		}

		return mutex;
	}

	private synchronized boolean acquireLock(String db, String collection) throws LockException {
		try {
			return getMutex(db, collection).acquire(10, TimeUnit.SECONDS);
		} catch (Exception e) {
			throw new LockException(e);
		}
	}

	private synchronized void releaseLock(String db, String collection) throws LockException {
		try {
			getMutex(db, collection).release();
		} catch (Exception e) {
			throw new LockException(e);
		}
	}

	public synchronized ExportLock acquireExportLock(String db, String collection) throws LockException {
		try {
			if (acquireLock(db, collection)) {
				long lastTimestamp = retriveTimestamp(db, collection);

				ExportLock exportLock = new ExportLock();
				exportLock.setDb(db);
				exportLock.setCollection(collection);
				exportLock.setLastExportTimestamp(lastTimestamp);
				exportLock.setNewExportTimestamp(Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTimeInMillis());

				return exportLock;
			} else {
				throw new LockException("Lock is already taken by another process.");
			}
		} catch (Exception e) {
			LockException le = new LockException("Failed to obtain lock gor DB=" + db + " and Collection=" + collection
					+ " due to: " + e.getMessage());
			le.addSuppressed(e);

			throw le;
		}
	}

	private long retriveTimestamp(String db, String collection) throws LockException {
		String fullPath = getPath(db, collection, this.tstampPath);

		try {
			byte[] data = client.getData().watched().forPath(fullPath);

			return Longs.fromByteArray(data);
		} catch (NoNodeException nne) {
			// no export was handled for this collection
			LOGGER.warn("Path {} does not exist: {}", fullPath, nne);

			long defaultValue = getDefaultTimestamp();
			LOGGER.warn("Creating path {} with default value {}", fullPath, defaultValue);

			try {
				client.create().creatingParentContainersIfNeeded().forPath(fullPath, Longs.toByteArray(defaultValue));
			} catch (Exception e) {
				throw new LockException(e);
			}

			return defaultValue;
		}
		catch (Exception e) {
			LOGGER.error("Failed to retrive data for path {} due to: {}", fullPath, e.getMessage());
			throw new LockException(e);
		}
	}

	public synchronized void releaseExportLock(ExportLock lock) throws LockException {
		String fullPath = getPath(lock.getDb(), lock.getCollection(), this.tstampPath);

		try {
			client.setData().forPath(fullPath, Longs.toByteArray(lock.getNewExportTimestamp()));
			releaseLock(lock.getDb(), lock.getCollection());
		} catch (Exception e) {
			LockException le = new LockException("Cannot release distributed lock for DB=" + lock.getDb()
					+ " and Collection=" + lock.getCollection());
			le.addSuppressed(e);
			throw le;
		}

	}

	private long getDefaultTimestamp() {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		calendar.set(2017, 01, 01, 0, 0, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTimeInMillis();
	}

}