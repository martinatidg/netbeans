package com.citi.reghub.rds.scheduler.export;

import com.citi.reghub.rds.scheduler.service.ExportLock;
import com.citi.reghub.rds.scheduler.service.LockException;
import com.citi.reghub.rds.scheduler.util.Util;

/**
 * @author Michael Rootman
 *
 */
public class ExportRequest {
	private String requestId;
	private String hostname;
	private int port;
	private String database;
	private String collection;
	private ExportLock lock;
	private int limit;

	public ExportLock getLock() {
		return lock;
	}

	public void setLock(ExportLock lock) {
		this.lock = lock;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getCollection() {
		return collection;
	}

	public void setCollection(String collection) {
		this.collection = collection;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public long getFromTimeStamp() {
		return lock.getLastExportTimestamp();
	}

	public long getToTimeStamp() {
		return lock.getNewExportTimestamp();
	}

	@Override
	public String toString() {
		String fromTimeStamp = lock == null ? "" : Util.formatDate(lock.getLastExportTimestamp());
		String toTimeStamp = lock == null ? "" : Util.formatDate(lock.getNewExportTimestamp());

		return "ExportRequest [requestId=" + requestId + ", hostname=" + hostname + ", port=" + port + ", database="
				+ database + ", collection=" + collection + ", fromTimeStamp=" + fromTimeStamp + ", toTimeStamp=" + toTimeStamp
				+ "]";
	}
}
