HOST=$1
FROM_DT=$2
TO_DT=$3
/tmp/scheduler/mongoUtils/mongoexport  --host $HOST --port 37017 --ssl  --sslAllowInvalidCertificates  --authenticationDatabase admin --authenticationMechanism SCRAM-SHA-1 --db entities-dev --collection entities_rds --limit 1 --query "{lastUpdatedTs : {'$gte' : new Date($FROM_DT), '$lte': new Date($TO_DT)}}" --jsonArray  --out /tmp/scheduler/rdsout/validate/validate.entities-dev.entities_rds