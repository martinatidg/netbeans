package com.citi.reghub.core.xm.handler;

import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.xstream.jms.XmMessageException;
import com.citi.reghub.core.xm.xstream.schema.RegHubMsg;

@Component
public class OutboundHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(OutboundHandler.class);
	@Autowired
	@Qualifier("outboundQueue")
	private BlockingQueue<RegHubMsg> outboundQueue;

	public void send(RegHubMsg msg) throws XmMessageException {
		LOGGER.info("OutboundHandler.send(), sending message:\n{}", msg);
		try {
			outboundQueue.put(msg);
		} catch (InterruptedException e) {
			LOGGER.error("OutboundHandler.send(), failed to send data. ", e);
			throw new XmMessageException(e);
		}
	}
}
