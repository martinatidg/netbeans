package com.citi.reghub.core.xm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.citi.reghub.core.xm.source.DataStore;

@SpringBootApplication
public class XmApplication implements CommandLineRunner {
	@Autowired
	private DataStore dataStore;

	public static void main(String[] args) {
		SpringApplication.run(XmApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		dataStore.startQueues();
	}
}
