package com.citi.reghub.core.xm.xstream.rio;

import javax.jms.Message;
import javax.jms.MessageListener;

import com.citi.reghub.core.xm.xstream.XmProcessor;
import com.citi.reghub.core.xm.xstream.jms.XmMessageException;

public class RioProcessor  implements XmProcessor {
	@Override
	public void startSender() throws XmMessageException {
		// TODO Auto-generated method stub
		
	}

	public void listen(Message message) throws XmMessageException {
		// TODO Auto-generated method stub
		
	}

}
