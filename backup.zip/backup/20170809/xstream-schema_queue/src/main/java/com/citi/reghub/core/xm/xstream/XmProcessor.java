package com.citi.reghub.core.xm.xstream;

import javax.jms.Message;

import com.citi.reghub.core.xm.xstream.jms.XmMessageException;

public interface XmProcessor {
	void startSender()  throws XmMessageException;
	void listen(Message message) throws XmMessageException;
}
