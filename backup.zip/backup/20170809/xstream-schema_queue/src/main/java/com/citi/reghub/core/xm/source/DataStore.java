package com.citi.reghub.core.xm.source;

import java.util.Scanner;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.handler.InboundHandler;
import com.citi.reghub.core.xm.handler.OutboundHandler;
import com.citi.reghub.core.xm.message.RequestMessage;
import com.citi.reghub.core.xm.xstream.XmProcessor;
import com.citi.reghub.core.xm.xstream.jms.XmMessageException;

@Component
public class DataStore {
	private static final Logger LOGGER = LoggerFactory.getLogger(DataStore.class);
	@Autowired
	private AsyncTaskExecutor taskExecutor;

	@Autowired
	InboundHandler inboundHandler;
	@Autowired
	private OutboundHandler outboundHandler;
	@Autowired
	XmProcessor processor;

	public void startQueues() {
		taskExecutor.submit(() -> {
			try {
				inboundHandler.startInboundHandler();
			} catch (XmMessageException e) {
				LOGGER.error("InboundHandler stopped.", e);
			}
		});

		taskExecutor.submit(() -> {
			try {
				processor.startSender();
			} catch (XmMessageException e) {
				LOGGER.error("InboundHandler stopped.", e);
			}
		});
		
		taskExecutor.submit(() -> {
			try {
				startOutboundHandler();
			} catch (XmMessageException e) {
				LOGGER.error("InboundHandler stopped.", e);
			}
		});
	}

	public void startOutboundHandler() throws XmMessageException {
		try (Scanner scanner = new Scanner(System.in)) {
			RequestMessage requestMessage = new RequestMessage();

			while (true) {
				LOGGER.info("Type in message ID to send an XM message:");
				String mid = scanner.nextLine();
				if (mid == null || mid.trim().isEmpty()) {
					break;
				}

				requestMessage.setMessageId(mid);
				String msg = requestMessage.marshal();

				LOGGER.info("sending message:\n{}", msg);
				outboundHandler.send(requestMessage.getMessageObj());
			}
		} catch (JAXBException e) {
			LOGGER.error("OutboundHandler, failed to send data. ", e);
			throw new XmMessageException(e);
		}
	}
}
