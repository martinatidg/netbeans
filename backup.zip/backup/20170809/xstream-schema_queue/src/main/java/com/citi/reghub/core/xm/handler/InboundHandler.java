package com.citi.reghub.core.xm.handler;

import java.util.concurrent.BlockingQueue;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.message.XmMarshaller;
import com.citi.reghub.core.xm.xstream.jms.XmMessageException;
import com.citi.reghub.core.xm.xstream.schema.ReghubNotificationMsg;

@Component
public class InboundHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(InboundHandler.class);
	@Autowired
	@Qualifier("inboundQueue")
	private BlockingQueue<ReghubNotificationMsg> inboundQueue;

	public void startInboundHandler() throws XmMessageException {

		while (true) {
			ReghubNotificationMsg msg;
			try {
				msg = inboundQueue.take();
				if (msg == null) {
					break;
				}
				String xml = XmMarshaller.marshal(msg);
				LOGGER.info("InboundHandler, inbound msg:\n{}", xml);

			} catch (JAXBException | InterruptedException e) {
				LOGGER.info("InboundHandler, error when processing response:\n{}", e);
				throw new XmMessageException(e);
			}
		}
	}
}
