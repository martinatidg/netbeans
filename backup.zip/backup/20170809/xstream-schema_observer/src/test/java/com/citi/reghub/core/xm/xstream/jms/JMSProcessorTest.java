/**
 * 
 */
package com.citi.reghub.core.xm.xstream.jms;

import static com.citi.reghub.core.xm.jms.server.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.xm.jms.server.Key.PROVIDER;
import static com.citi.reghub.core.xm.jms.server.Key.PROVIDER_URL;
import static com.citi.reghub.core.xm.jms.server.Key.QUEUE_REQUEST;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.xm.jms.server.Key;
import com.citi.reghub.core.xm.jms.server.XMProducer;
import com.citi.reghub.core.xm.message.RequestMessage;
import com.citi.reghub.core.xm.xstream.jms.JMSProcessor;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

import javax.jms.Message;
import javax.jms.TextMessage;

@RunWith(JUnit4.class)
public class JMSProcessorTest {
	private JMSProcessor processor;

	@Before
	public void setUp() {
		processor = new JMSProcessor();
	}

	 @Test
	 public void testSend() {

	 }

	 @Test
	 public void testListen() {
//		 TextMessage msg = new TextMessage();
	 }
	/**
	 * Test method for
	 * {@link com.citi.reghub.core.jms.XMMessageProducer#initConnection()}.
	 * 
	 * @throws Exception
	 */
	// @Test(expected=Test.None.class)
	// public void testInitConnection() throws Exception {
	// setUp();
	// jmsClient=new XMMessageProducer(config);
	// jmsClient.initConnection();
	// }

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.xm.jms.client.XMMessageProcessor#sendMessage(java.lang.String)}.
	 * 
	 * @throws Exception
	 */
	// @Test // (expected=Exception.class)
	// public void testSendMessage() throws Exception {
	// jmsClient = new XMProducer(config);
	// //jmsClient.initConnection();
	// RequestMessage xmhandler = new RequestMessage();
	// String actual = xmhandler.marshal();
	// System.out.println("testSendMessage(), actual = " + actual);
	// jmsClient.sendMessage(actual);
	// }

}
