package com.citi.reghub.core.xm.jms.server;

import static com.citi.reghub.core.xm.jms.server.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.xm.jms.server.Key.PROVIDER_URL;
import static com.citi.reghub.core.xm.jms.server.Key.QUEUE_REQUEST;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class XMConsumer {
	private static final Logger LOGGER = LoggerFactory.getLogger(XMConsumer.class);
	private Map<Key, String> config = null;
	private Properties env = null;
	@Resource(lookup = "citi.cibtech.na.gicapbpm_153176.XAQueueCF") // 2
	private static ConnectionFactory connectionFactory;
	@Resource(lookup = "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue") // 2

	private String factoryName = TibjmsInitialContextFactory.class.getName();
	private static Queue queue;

	public XMConsumer(Map<Key, String> config) {
		this.config = config;
		initJMS();
	}

	public XMConsumer() {
		config = new HashMap<>();
		config.put(QUEUE_REQUEST, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
		//config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");

		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		initJMS();
	}

	public void startQueue(MessageListener listener) throws NamingException {
		try {
			InitialContext jndi = new InitialContext(env);
			connectionFactory = (QueueConnectionFactory) jndi.lookup(config.get(CONNECTION_JNDI));

			Connection connection = connectionFactory.createConnection(); // 3
			queue = (Queue) jndi.lookup(this.config.get(QUEUE_REQUEST));
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(queue);
			consumer.setMessageListener(listener);

			connection.start();
		} catch (JMSException e) {
			e.printStackTrace();
		} // 5
	}

	private void initJMS() {
		env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		env.put(Context.PROVIDER_URL, this.config.get(PROVIDER_URL));
	}
}
