package com.citi.reghub.core.xm.handler;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.xm.message.RequestMessage;

public class XMHandlerTest {
	private RequestMessage xmhandler;
	@Before
	public void init() {
		xmhandler = new RequestMessage();

//		Map<String, String> xmMap = new HashMap<>();
//		xmMap.put(PAC.key(), "pac");
//		xmMap.put(SFOS.key(), "sfos");
//		xmMap.put(TYPE.key(), "type");
//		xmMap.put(UITI.key(), "uiti");
//
//		xmhandler = new XMHandler(xmMap);
	}

	@Test
	public void testMarshal() throws JAXBException {
		String expected = "";
		String actual = xmhandler.marshal();
		System.out.println("estMarshal(), actual = " + actual);
		Assert.assertNotNull("result is null", actual);
	}
}
