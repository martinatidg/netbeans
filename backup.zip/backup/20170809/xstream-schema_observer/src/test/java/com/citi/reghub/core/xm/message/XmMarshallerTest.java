package com.citi.reghub.core.xm.message;

public class XmMarshallerTest {

}
