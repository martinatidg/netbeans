package com.citi.reghub.core.xm.xstream.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.citi.reghub.core.xm.message.XmMarshaller;

public class ResponseConverter implements MessageConverter {
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseConverter.class);
	@Override
	public Message toMessage(Object object, Session session) throws JMSException, MessageConversionException {
		String xml;
		try {
			xml = XmMarshaller.marshal(object);
		} catch (JAXBException e) {
			LOGGER.error("Failed to convert object to message: {}", e);
			throw new MessageConversionException("Failed to convert object to message: {}", e);
		}
		return session.createTextMessage(xml);
	}

	@Override
	public Object fromMessage(Message message) throws JMSException, MessageConversionException {
		String xmlmsg = ((TextMessage) message).getText();
		Object obj;
		try {
			obj = XmMarshaller.unmarshal(xmlmsg);
		} catch (JAXBException e) {
			LOGGER.error("Failed to convert message to object: {}", e);
			throw new MessageConversionException("Failed to convert message to object: ", e);
		}
		
		return obj;
	}

}
