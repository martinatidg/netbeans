package com.citi.reghub.core.xm.message;

import javax.xml.bind.JAXBException;

import com.citi.reghub.core.xm.xstream.schema.ObjectFactory;
import com.citi.reghub.core.xm.xstream.schema.RegHubMsg;
import com.citi.reghub.core.xm.xstream.schema.Status;

public class RequestMessage {
	RegHubMsg msg;

	public RequestMessage() {
		ObjectFactory obj = new ObjectFactory();
		msg = obj.createRegHubMsg();
		
		long ct = System.currentTimeMillis();
		msg.setUITI("035506000021863338876");
		msg.setProductType("ForeignExchange:NDF");
		msg.setSourceFrontOfficeSystem("FXLMREG");
		msg.setPrimaryAssetClass("FOREIGNEXCHANGE");
		msg.setParty1ID("1000242191");
		msg.setParty1GFCIDDescription("CITIGROUP GLOBAL MARKETS LTD");
		msg.setParty1GFCID("1000242191");
		msg.setParty2ID("1000019751");
		msg.setParty2GFCIDDescription("BNP PARIBAS SA-PARIS HEAD OFFICE");
		msg.setParty2GFCID("1000019751");
		msg.setOriginatingEvent("CONFIRMATIONAGREEMENT");
		msg.setReportingPurpose("Confirm");
		msg.setReportingObligation("ESMA");
		msg.setOnBehalfOf("Party1");
		msg.setMessageID("936140070");
		msg.setMessageType("PET");
		msg.setExceptionID("555555555555");
		msg.setExceptionClass("NACK");
		msg.setStatus(Status.OPEN.name());
		msg.setCreationTimestamp(ct);
		msg.setExecutionDateTime(ct);
	}

	public RegHubMsg getMessageObj() {
		return msg;
	}

	public String marshal() throws JAXBException {
		return XmMarshaller.marshal(msg);
	}

	public void setMessageId(String mid) {
		msg.setMessageID(mid);
		msg.setExceptionID(mid);
	}
}
