package com.citi.reghub.core.xm.xstream.jms;

import java.util.Observable;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;

import com.citi.reghub.core.xm.message.XmMarshaller;
import com.citi.reghub.core.xm.xstream.XmProcessor;

public class JMSProcessor extends Observable implements XmProcessor {
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSProcessor.class);
	@Value("${xm.jms.queue.response}")
	private String queueResponse;
	@Autowired
	private JmsTemplate jmsTemplate;
	@Autowired
	@Qualifier("requestDestination")
	private Destination requestDestination;
	@Autowired
	@Qualifier("responseDestination")
	private Destination respnseDstination;
	@Autowired
	@Qualifier("requestMeaasgeConverter")
	private RequestConverter requestMeaasgeConverter;
	@Autowired
	@Qualifier("responseMeaasgeConverter")
	private ResponseConverter responseMeaasgeConverter;

	private Object changedObj;

	@Override
	public void send(Object obj) throws XmMessageException {
		jmsTemplate.setMessageConverter(requestMeaasgeConverter);
		jmsTemplate.convertAndSend(requestDestination, obj);
	}

	@JmsListener(destination = "${xm.jms.queue.response}")
	public void listen(Message message) throws XmMessageException {
		try {
			String xmlmsg = ((TextMessage) message).getText();
			LOGGER.info("in listen,  Response received:\n{}", xmlmsg);

			changedObj = XmMarshaller.unmarshal(xmlmsg);
			this.setChanged();
			this.notifyObservers();
		} catch (JMSException | JAXBException e) {
			LOGGER.error("Failed to process response", e);
			throw new XmMessageException(e);
		}
	}

	@Override
	public Object receive() {
		return changedObj;
	}
}