package com.citi.reghub.core.xm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmApplication  {
	public static void main(String[] args) {
		SpringApplication.run(XmApplication.class, args);
	}
}
