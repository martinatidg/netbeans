package com.citi.reghub.core.xm.jms.integration.test;

import java.util.Scanner;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.test.context.junit4.SpringRunner;

import com.citi.reghub.core.xm.handler.InboundHandler;
import com.citi.reghub.core.xm.handler.OutboundHandler;
import com.citi.reghub.core.xm.message.RequestMessage;
import com.citi.reghub.core.xm.xstream.XmProcessor;
import com.citi.reghub.core.xm.xstream.jms.XmMessageException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class XmClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(XmClient.class);
	public static final int DATASIZE = 1000;
	public static long starttime;
	@Autowired
	private AsyncTaskExecutor taskExecutor;

	@Autowired
	InboundHandler inboundHandler;
	@Autowired
	private OutboundHandler outboundHandler;
	@Autowired
	XmProcessor processor;

	@Test
	public void startQueues() throws InterruptedException {
		taskExecutor.submit(() -> {
			try {
				inboundHandler.startInboundHandler();
			} catch (XmMessageException e) {
				LOGGER.error("InboundHandler stopped.", e);
			}
		});

		taskExecutor.submit(() -> {
			try {
				processor.startSender();
			} catch (XmMessageException e) {
				LOGGER.error("InboundHandler stopped.", e);
			}
		});

		sendDataOneByOne();
		// sendBigData();

	}

	public void sendBigData() throws InterruptedException {
		try (Scanner scanner = new Scanner(System.in)) {
			LOGGER.info("Ready to send {} messages. Press enter key to start.", DATASIZE);
			scanner.nextLine();
		}
		starttime = System.currentTimeMillis();
		for (int i = 0; i < DATASIZE; i++) {
			RequestMessage requestMessage = new RequestMessage();
			requestMessage.setMessageId(String.format("%09d", i));
			outboundHandler.send(requestMessage.getMessageObj());
		}

	}

	public void sendDataOneByOne() throws InterruptedException {
		try (Scanner scanner = new Scanner(System.in)) {
			RequestMessage requestMessage = new RequestMessage();

			while (true) {
				LOGGER.info("Type in message ID to send an XM message:");
				String mid = scanner.nextLine();
				if (mid == null || mid.trim().isEmpty()) {
					break;
				}

				requestMessage.setMessageId(mid);
				outboundHandler.send(requestMessage.getMessageObj());
			}
		}
	}

	public static String convertLongToTime(long time) {
		long milli = time % 1000;
		long seconds = time / 1000;
		long sec = seconds % 60;
		long minutes = seconds / 60;
		long min = minutes % 60;
		long hours = minutes / 60;

		return hours + ":" + min + ":" + sec + ":" + milli;
	}
}
