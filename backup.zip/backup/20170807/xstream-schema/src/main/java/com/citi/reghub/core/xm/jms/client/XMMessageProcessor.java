package com.citi.reghub.core.xm.jms.client;

import static com.citi.reghub.core.xm.constants.Key.*;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.constants.Key;
import com.citi.reghub.core.xm.jms.XMProducer;
import com.citi.reghub.core.xm.message.RequestMessage;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

@Component
public class XMMessageProcessor implements MessageListener, Serializable {
	@Value("${xm.jms.queue.request}")
	String queueRequest;
	@Value("${xm.jms.queue.response}")
	String queueResponse;
	@Value("${xm.jms.jndi}")
	String connectionFactory;
	@Value("${xm.jms.provider}")
	String provider;
	@Value("${xm.jms.provider.url}")
	String url;

//	XMProducer producer;
	private static String factoryName = TibjmsInitialContextFactory.class.getName();

	private static final long serialVersionUID = -8055624586639876364L;

	private static final Logger LOGGER = LoggerFactory.getLogger(XMMessageProcessor.class);

	private transient Map<Key, String> config = null;

	public XMMessageProcessor() {
	}
	
	public void setProperties() {
		LOGGER.info("XMMessageProcessor(), inject values,  queueRequest = {}, queueResponse = {}, connectionFactory = {}, url = {}, provider = {}",
				queueRequest, queueResponse, connectionFactory, url, provider);
		config = new HashMap<>();
		config.put(QUEUE_REQUEST, queueRequest);
		config.put(QUEUE_RESPONSE, queueResponse);
		config.put(CONNECTION_JNDI, connectionFactory);
		config.put(PROVIDER_URL, url);
		config.put(PROVIDER, provider);
	}

	public XMMessageProcessor(Map<Key, String> config) {
		this.config = config;
	}

	public void startRequestProcessor() throws XmMessageException {
		try (Scanner scanner = new Scanner(System.in)) {
			XMProducer producer = new XMProducer(config);
			RequestMessage requestMessage = new RequestMessage();

			while (true) {
				System.out.println("Type in message ID to send an XM message:");
				String mid = scanner.nextLine();
				if (mid == null || mid.trim().isEmpty()) {
					break;
				}

				requestMessage.setMessageId(mid);
				String msg = requestMessage.marshal();

				LOGGER.info("sending message:\n{}", msg);
				producer.sendMessage(msg);
			}
		}
		catch (JMSException | JAXBException e) {
			throw new XmMessageException(e);
		}
	}

	public static void main(String[] args) throws XmMessageException {
		Map<Key, String> config = new HashMap<>();
		config.put(QUEUE_REQUEST, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
		config.put(QUEUE_RESPONSE, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		config.put(PROVIDER, factoryName);


		XMMessageProcessor processor = new XMMessageProcessor(config);
		processor.startResponseProcessor();
		processor.startRequestProcessor();
	}

	@Override
	public void onMessage(Message message) {
		try {
			String xml = ((TextMessage) message).getText();
			LOGGER.info("Response received:\n{}", xml);

		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	public void startResponseProcessor() throws XmMessageException {
		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, factoryName);
		env.put(Context.PROVIDER_URL, this.config.get(PROVIDER_URL));
//		env.put(Context.PROVIDER, this.config.get(PROVIDER));

		try {
			InitialContext jndi = new InitialContext(env);
			QueueConnectionFactory connectionFactory = (QueueConnectionFactory) jndi.lookup(config.get(CONNECTION_JNDI));
			//config.put(QUEUE_REQUEST, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");
			Connection connection = connectionFactory.createConnection(); // 3
			Queue queue = (Queue) jndi.lookup(this.config.get(QUEUE_RESPONSE));
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(queue);
			consumer.setMessageListener(this); // 4

			connection.start();
		} catch (JMSException | NamingException e) {
			throw new XmMessageException(e);
		}
	}
}