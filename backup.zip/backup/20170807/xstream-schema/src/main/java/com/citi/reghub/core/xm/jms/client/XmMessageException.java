package com.citi.reghub.core.xm.jms.client;

public class XmMessageException extends Exception{
	private static final long serialVersionUID = 1L;

	public XmMessageException(Throwable cause) {
		super(cause);
	}
}
