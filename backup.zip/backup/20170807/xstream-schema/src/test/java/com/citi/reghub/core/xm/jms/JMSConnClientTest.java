/**
 * 
 */
package com.citi.reghub.core.xm.jms;

import static com.citi.reghub.core.xm.constants.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.xm.constants.Key.PROVIDER;
import static com.citi.reghub.core.xm.constants.Key.PROVIDER_URL;
import static com.citi.reghub.core.xm.constants.Key.QUEUE_REQUEST;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.xm.constants.Key;
import com.citi.reghub.core.xm.message.RequestMessage;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

/**
 * @author sc54933
 *
 */
@RunWith(JUnit4.class)
public class JMSConnClientTest {
	private Map<Key, String> config = new HashMap<>();
	private XMProducer jmsClient;
	private String factoryName = TibjmsInitialContextFactory.class.getName();

	@Before
	public void setUp() {
		// QueueConnectionFactory = citi.cibtech.na.gicapbpm_153176.XAQueueCF
		// JNDIContextURL = tibjmsnaming://icgesbint.nam.nsroot.net:7222
		//
		// Reghub to X-Stream:
		// citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue
		// X-Stream to Rehub:
		// citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue

		config.put(QUEUE_REQUEST, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		//config.put(PROVIDER, "TibjmsInitialContextFactory");
		config.put(PROVIDER, factoryName);
		System.out.println("factoryName:\nTibjmsInitialContextFactory\n" + factoryName);
	}

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.jms.XMMessageProcessor#JMSConnectionClient(java.util.Map)}.
	 * @throws JMSException 
	 */
//	@Test
//	public void testJMSConnectionClient() throws JMSException {
//		setUp();
//		jmsClient = new MessageProducer(config);
//		String providerUrl = jmsClient.getConfig().get(PROVIDER_URL);
//		assertTrue(providerUrl.equals(PROVIDER_URL));
//	}

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.jms.XMMessageProducer#initConnection()}.
	 * 
	 * @throws Exception
	 */
	// @Test(expected=Test.None.class)
	// public void testInitConnection() throws Exception {
	// setUp();
	// jmsClient=new XMMessageProducer(config);
	// jmsClient.initConnection();
	// }

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.xm.jms.client.XMMessageProcessor#sendMessage(java.lang.String)}.
	 * 
	 * @throws Exception
	 */
	@Test // (expected=Exception.class)
	public void testSendMessage() throws Exception {
		jmsClient = new XMProducer(config);
		//jmsClient.initConnection();
		RequestMessage xmhandler = new RequestMessage();
		String actual = xmhandler.marshal();
		System.out.println("testSendMessage(), actual = " + actual);
		jmsClient.sendMessage(actual);
	}

}
