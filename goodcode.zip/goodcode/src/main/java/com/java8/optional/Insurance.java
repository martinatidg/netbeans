package com.java8.optional;

public class Insurance {

    private String name;

    public Insurance(String name) {
    	this.name = name;
    }

    public String getName() {
        return name;
    }
}
