package com.java8.optional;

import java.util.*;

public class Person {

    private Car car;

    public Person(Car car) {
    	this.car = car;
    }

    public Optional<Car> getCar() {
        return Optional.ofNullable(car);
    }
}
