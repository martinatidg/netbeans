package com.java8.optional;

import java.util.*;

public class Car {

    private Insurance insurance;

    public Car(Insurance insurance) {
    	this.insurance = insurance;
    }

    public Optional<Insurance> getInsurance() {
        return Optional.ofNullable(insurance);
    }
}
