package com.java8.optional;

public class ValidateContain {

}
