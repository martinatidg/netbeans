package hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citi.reghub.domain.Employee;

@RestController
public class HelloController {
	String myUserName = "yuan";
	String myPassword = "ribi";
	//MongoClient mongoClient;
	@Autowired
	MongoOperations mongoOps;
	
//	@Autowired
//	ProfileRepository profileRepository;
//	public HelloController(ProfileRepository profileRepository) {
//		this.profileRepository = profileRepository;
//	}

	@RequestMapping("/profile")
	public String index() {
		//String ret = getProfile();
		String ret = getEmployee();
		return ret;
	}
	
//	@Autowired
//	public HelloController(MongoClient mongoClient) {
//		this.mongoClient = mongoClient;
//	}

	@Autowired
//	public HelloController(MongoOperations mongoOps) {
//		this.mongoOps = mongoOps;
//	}

//	public String getProfile() {
//
//		try (MongoClient mongoClient = new MongoClient("localhost", 27017)) {
//
//			// To connect to mongodb server
//			// MongoClient mongoClient = new MongoClient( "localhost" , 27017 );
//
//			// Now connect to your databases
//			MongoDatabase db = mongoClient.getDatabase("foobar");
//			System.out.println("Connect to database successfully");
//			MongoCollection<Document> collection = db.getCollection("employee");
//
//			System.out.println("collection: " + collection);
//
//			// boolean auth = db.authenticate(myUserName, myPassword);
//			// System.out.println("Authentication: "+ auth);
//
//			db.createCollection("mycol");
//			System.out.println("Collection created successfully");
//
//			MongoCollection coll = db.getCollection("mycol");
//			System.out.println("Collection mycol selected successfully. collection size= " + coll.count());
//
//		} catch (Exception e) {
//			System.err.println(e.getClass().getName() + ": " + e.getMessage());
//		}
//
//		return "OK";
//	}

	public String getEmployee() {

		//MongoOperations mongoOps = new MongoTemplate(new MongoClient(), "employee");
		//MongoOperations mongoOps = new MongoTemplate(mongoClient, "employee");

	    mongoOps.insert(new Employee("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803", "90 South Street, Tampa, FL"));

	    Employee emp = mongoOps.findOne(new Query(Criteria.where("firstName").is("Martin")), Employee.class);
	    
	    String retstr = "";
	    if (emp == null) {
	    	retstr = "failed to find";
	    }
	    else {
	    	retstr = emp.toString();
	    }
	    System.out.println(retstr);

	    //mongoOps.dropCollection("person");
		return retstr;
	}
	
//	public String getEmployee() {
//
//		//MongoOperations mongoOps = new MongoTemplate(new MongoClient(), "employee");
//		//MongoOperations mongoOps = new MongoTemplate(mongoClient, "employee");
//
////	    mongoOps.insert(new Employee("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803", "90 South Street, Tampa, FL"));
////
////	    Employee emp = mongoOps.findOne(new Query(Criteria.where("firstName").is("Martin")), Employee.class);
//		Employee employee = new Employee("Martin", "Tan", "Male", "martin.tan@citi.com", "321-502-9803", "90 South Street, Tampa, FL");
//		
//		profileRepository.create(employee);
//
//	    Employee emp = profileRepository.find("Martin");
//
//	    String retstr = "";
//	    if (emp == null) {
//	    	retstr = "failed to find";
//	    }
//	    else {
//	    	retstr = emp.toString();
//	    }
//	    System.out.println(retstr);
//
//	    //mongoOps.dropCollection("person");
//		return retstr;
//	}

}
