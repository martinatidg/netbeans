package com.citi.reghub.client;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import com.citi.reghub.domain.Entity;
import com.citi.reghub.util.EntityConsumer;
import com.citi.reghub.util.EntityProducer;

public class Simulator {

	public static void main(String[] args) {
        //Creating BlockingQueue of size 10
        BlockingQueue<List<Entity>> queue = new ArrayBlockingQueue<>(10);
        EntityProducer producer = new EntityProducer(queue);
        EntityConsumer consumer = new EntityConsumer(queue);

        //starting producer to produce messages in queue
        new Thread(producer).start();
        //starting consumer to consume messages from queue

        new Thread(consumer).start();
        System.out.println("Producer and Consumer has been started");

//		Ocean oc = new Ocean();
//        //System.out.println("Producer and Consumer has been started");
//        //List<Entity> ents = oc.getBatchEntity();
//        Entity ents = oc.getBaseEntity();
//        System.out.println("entity before save:\n" + ents);
//        Entity retent = saveEntity(ents);
//        System.out.println("entity in mongodb:\n" + retent);	}
	}

}
