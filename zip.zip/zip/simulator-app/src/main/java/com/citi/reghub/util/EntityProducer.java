package com.citi.reghub.util;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.springframework.beans.factory.annotation.Autowired;

import com.citi.reghub.db.EntityRepository;
import com.citi.reghub.domain.Entity;

public class EntityProducer implements Runnable {
	private BlockingQueue<List<Entity>> queue;
	private Ocean ocean = new Ocean();

	public EntityProducer(BlockingQueue<List<Entity>> q) {
		this.queue = q;
	}

	@Override
	public void run() {
		List<Entity> entities = new ArrayList<>();
		for (int i = 0; i < ocean.getTotalRecordNum(); i++) {
			entities = ocean.getBatchEntity();

			try {
				queue.put(entities);
				System.out.println("Produced " + entities.size() + " entities. waiting for next ...");
				if (entities.isEmpty()) {
					break;
				}

				Thread.sleep(ocean.getIntervalTime());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		System.out.println("Producing records completed.");
		// send an empty list to tell the consumer it's finished.
		entities.clear();
		try {
			queue.put(entities);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}