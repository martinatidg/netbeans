package com.citi.reghub.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "entity")
public class Entity {
	@Id
	@Field("id")
	public String regHubId;				// reghub generated unique id for each message
	@Indexed
	public String status;				// reghub reporting status e.g. REPORTABLE, NON_REPORTABLE, EXCEPTION, PENDING, REPORTED, REJECTED 
	@Indexed
	public String stream;				// reporting stream (always 4 char) e.g. M2TR, M2PR, M2PO
	@Indexed
	public String flow;					// reporting asset class / product (always 3 char) e.g. CEQ (cash equities), CFI (cash fixed income)
	
	public String sourceUId;			// unique id for a message received from source e.g. OceanId for transaction reporting
	public String sourceId;				// trade/quote/order id
	public String sourceVersion;		// trade/quote/order version
	public String sourceStatus;			// always normalised to NEW, AMEND and CANCEL
	public String sourceSystem;			// upstream source system generated the message e.g. TPS, PRIMO
	public String regReportingRef;		// used as reporting id for trade/quote/order/transaction e.g. stream + flow + sourceId
	@Indexed
//	public LocalDateTime receivedTs;	// Time when entity is received in reghub
//	public LocalDateTime publishedTs;	// trade activity time .i.r when this trade version was created
//	public LocalDateTime executionTs;	// trade origination time
//	public LocalDateTime lastUpdatedTs;	// timestamp of last activity in reghub, classical updated timestamp for reghub
	public String receivedTs;	// Time when entity is received in reghub
	public String publishedTs;	// trade activity time .i.r when this trade version was created
	public String executionTs;	// trade origination time
	public String lastUpdatedTs;	// timestamp of last activity in reghub, classical updated timestamp for reghub

	public List<String> reasonCodes = new ArrayList<String>();
	public List<String> flags = new ArrayList<String>();

	public Entity() {}

	public Entity(String status, String stream, String flow, String sourceUId, String sourceId,
			String sourceVersion, String sourceStatus, String sourceSystem, String regReportingRef, String receivedTs,
			String publishedTs, String executionTs, String lastUpdatedTs, List<String> reasonCodes,
			List<String> flags) {
		super();
		//this.regHubId = regHubId;
		this.status = status;
		this.stream = stream;
		this.flow = flow;
		this.sourceUId = sourceUId;
		this.sourceId = sourceId;
		this.sourceVersion = sourceVersion;
		this.sourceStatus = sourceStatus;
		this.sourceSystem = sourceSystem;
		this.regReportingRef = regReportingRef;
		this.receivedTs = receivedTs;
		this.publishedTs = publishedTs;
		this.executionTs = executionTs;
		this.lastUpdatedTs = lastUpdatedTs;
		this.reasonCodes = reasonCodes;
		this.flags = flags;
	}
	public String getRegHubId() {
		return regHubId;
	}
	public void setRegHubId(String regHubId) {
		this.regHubId = regHubId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getFlow() {
		return flow;
	}
	public void setFlow(String flow) {
		this.flow = flow;
	}
	public String getSourceUId() {
		return sourceUId;
	}
	public void setSourceUId(String sourceUId) {
		this.sourceUId = sourceUId;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public String getSourceVersion() {
		return sourceVersion;
	}
	public void setSourceVersion(String sourceVersion) {
		this.sourceVersion = sourceVersion;
	}
	public String getSourceStatus() {
		return sourceStatus;
	}
	public void setSourceStatus(String sourceStatus) {
		this.sourceStatus = sourceStatus;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getRegReportingRef() {
		return regReportingRef;
	}
	public void setRegReportingRef(String regReportingRef) {
		this.regReportingRef = regReportingRef;
	}
	//public LocalDateTime getReceivedTs() {
	public String getReceivedTs() {
		return receivedTs;
	}
	//public void setReceivedTs(LocalDateTime receivedTs) {
	public void setReceivedTs(String receivedTs) {
		this.receivedTs = receivedTs;
	}
	public String getPublishedTs() {
		return publishedTs;
	}
	public void setPublishedTs(String publishedTs) {
		this.publishedTs = publishedTs;
	}
	public String getExecutionTs() {
		return executionTs;
	}
	public void setExecutionTs(String executionTs) {
		this.executionTs = executionTs;
	}
	public String getLastUpdatedTs() {
		return lastUpdatedTs;
	}
	public void setLastUpdatedTs(String lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}
	public List<String> getReasonCodes() {
		return reasonCodes;
	}
	public void setReasonCodes(List<String> reasonCodes) {
		this.reasonCodes = reasonCodes;
	}
	public List<String> getFlags() {
		return flags;
	}
	public void setFlags(List<String> flags) {
		this.flags = flags;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((regHubId == null) ? 0 : regHubId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Entity other = (Entity) obj;
		if (regHubId == null) {
			if (other.regHubId != null)
				return false;
		} else if (!regHubId.equals(other.regHubId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Entity [regHubId=" + regHubId + ", status=" + status + ", stream=" + stream + ", flow=" + flow
				+ ", sourceUId=" + sourceUId + ", sourceId=" + sourceId + ", sourceVersion=" + sourceVersion
				+ ", sourceStatus=" + sourceStatus + ", sourceSystem=" + sourceSystem + ", regReportingRef="
				+ regReportingRef + ", receivedTs=" + receivedTs + ", publishedTs=" + publishedTs + ", executionTs="
				+ executionTs + ", lastUpdatedTs=" + lastUpdatedTs + ", reasonCodes=" + reasonCodes + ", flags=" + flags
				+ "]";
	}

}