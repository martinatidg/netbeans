package com.citi.reghub.rest;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.citi.reghub.domain.Entity;
import com.citi.reghub.util.EntityConsumer;
import com.citi.reghub.util.EntityProducer;

@SpringBootApplication
@EnableMongoRepositories(basePackages="com.citi.reghub.db")
public class Application implements CommandLineRunner {
    
    public static void main(String[] args) {
        ApplicationContext ctx = SpringApplication.run(Application.class, args);
        
        System.out.println("Let's inspect the beans provided by Spring Boot:");
        
        String[] beanNames = ctx.getBeanDefinitionNames();
        Arrays.sort(beanNames);
        for (String beanName : beanNames) {
            System.out.println("beanName = " + beanName);
        }
        

    }

	@Override
	public void run(String... arg0) throws Exception {
        BlockingQueue<List<Entity>> queue = new ArrayBlockingQueue<>(10);
        EntityProducer producer = new EntityProducer(queue);
        EntityConsumer consumer = new EntityConsumer(queue);

        //starting producer to produce messages in queue
        new Thread(producer).start();
        //starting consumer to consume messages from queue

        new Thread(consumer).start();
        System.out.println("Producer and Consumer has been started");
		
	}

}
