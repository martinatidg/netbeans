package com.citi.reghub.util;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.citi.reghub.domain.Entity;


public class Ocean {
	
	
	@Autowired
	private Environment env;
	
	private static String settingsPath = "settings.properties";

    private Properties prop;
    private Map<String, Integer> streamMap; //    M2TR:30,M2PR:30,M2PO:40,
    private List<String> streamList;
    private List<String> flowList; //CEQ,CFI,F01,F02,F03,F04,F05,F06,F07,F08
    private int timeFrame = 60;		// seconds
    private int totalRecordNum = 100;
	private int batchSize = 10;
	private int intervalTime = 0;

	public Ocean() {
		this(settingsPath);
	}

	// To distribute the insertion operations in a time frame, 
	// get the waiting time for each insertion.
    public long getIntervalTime() {
		return intervalTime;
	}

	public int getTotalRecordNum() {
		return totalRecordNum;
	}

	public Ocean(String url) {
		prop = new Properties();
		streamMap = new HashMap<>();
		streamList = new ArrayList<>();
		flowList = new ArrayList<>();

		
		try(InputStream input = this.getClass().getClassLoader().getResourceAsStream(url)) {
			prop.load(input);
			totalRecordNum = Integer.parseInt(prop.getProperty("record.total"));
			timeFrame = Integer.parseInt(prop.getProperty("timeframe"));
			batchSize = Integer.parseInt(prop.getProperty("batchsize"));
			intervalTime = (timeFrame * 1000) / (totalRecordNum / batchSize);

			String[] streams = prop.getProperty("streams").split(",");
			for (String str : streams) {
				String[] splitStr = str.split(":");
				streamMap.put(splitStr[0], (Integer.parseInt(splitStr[1]) * totalRecordNum) / 100);	// record number for a stream name
				streamList.add(splitStr[0]);
				System.out.println("Stream name: " + splitStr[0] + ", percentage: " + splitStr[1] + "%");
			}

			String flows = prop.getProperty("flows");
			flowList = Arrays.asList(flows.split(","));

			System.out.println("flows: " + flows);
			System.out.println("time frame: " + timeFrame + " seconds.");
			System.out.println("Records Total Number: " + totalRecordNum);
			System.out.println("batchSize: " + batchSize);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public Entity getBaseEntity() {
		List<String> reasonCodes = new ArrayList<>();
		List<String> flags = new ArrayList<>();
		for (int i = 1; i <= 15; i++) {
			reasonCodes.add("reason code " + i);
			reasonCodes.add("flag " + i);
		}

		return new Entity("status", "stream", "flow", "sourceUId", "sourceId",
				"sourceVersion", "sourceStatus", "sourceSystem", "regReportingRef", "receivedTs",
				"publishedTs", "executionTs", "lastUpdatedTs", reasonCodes,
				flags);
	}
	
	public List<Entity> getBatchEntity() {
		List<Entity> entityList = new ArrayList<>();

		for (int i = 0; i < batchSize; i++) {
			Entity entity = getBaseEntity();

			String rstr = getRandomStream();
			if (rstr == null || rstr.trim().isEmpty()) {
				break;
			}

			entity.setStream(getRandomStream());
			entity.setFlow(getRandomFlow());
			entity.setReceivedTs(LocalDateTime.now().toString());
			entityList.add(entity);
		}

//		long objSize = ObjectSizeFetcher.getObjectSize(entity);
//		
//		System.out.println("entity size: " + objSize);
		
		return entityList;
	}

	// Each of the stream names is assigned a percentage of the total record.
	// The percentage is set in the settings properties file.
	// Select a stream from the available stream list and the number of the stream
	// is decreased by one and if it's 0, the the stream name is removed from the list
	private String getRandomStream() {
		int streamSize = streamList.size();
		if (streamSize < 1) {
			return "";			// finished creating all records
		}

		int selectedIndex = getRandomIndex(streamSize);

		String strm = streamList.get(selectedIndex);

		int remainStream = streamMap.get(strm);
		remainStream--;
		if (remainStream < 1) {
			streamList.remove(strm);
			streamMap.remove(strm);
		}
		else {
			streamMap.put(strm, remainStream);
		}

		return strm;
	}
	
	private String getRandomFlow() {
		int selectedIndex = getRandomIndex(flowList.size());
		return flowList.get(selectedIndex);
	}
	
	private int getRandomIndex(int max) {
		int rindex = (int) Math.round(Math.random() * max);
		rindex = rindex >= max ? max - 1 : rindex;

		System.out.println("random index: " + rindex);

		return rindex;
	}

	public static void main(String[] args) {
		Ocean ocean = new Ocean();
		//Ocean ocean = new Ocean();
		// Collection<Entity> ent = ocean.getData();
		//Entity ent = ocean.getOneData();

		//System.out.println(ent);
	}
}
