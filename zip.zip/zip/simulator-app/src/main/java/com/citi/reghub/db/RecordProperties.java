package com.citi.reghub.db;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("settings")
public class RecordProperties {
    @Autowired
    private Environment env;
    
    

//	private String streams; //=M2TR:30,M2PR:30,M2PO:40
//	private String flows; //=CEQ,CFI,F01,F02,F03,F04,F05,F06,F07,F08
//	@Value("${record.total}")
//	private int recordTotal; //=10
//	private int timeframe; //=1
//	private int batchsize; //=1
//
//	public String getStreams() {
//		return streams;
//	}
//	public void setStreams(String streams) {
//		this.streams = streams;
//	}
	public String getFlows() {
		return env.getProperty("flows");
	}
//	public void setFlows(String flows) {
//		this.flows = flows;
//	}
//	public int getRecordTotal() {
//		return recordTotal;
//	}
//	public void setRecordTotal(int recordTotal) {
//		this.recordTotal = recordTotal;
//	}
//	public int getTimeframe() {
//		return timeframe;
//	}
//	public void setTimeframe(int timeframe) {
//		this.timeframe = timeframe;
//	}
//	public int getBatchsize() {
//		return batchsize;
//	}
//	public void setBatchsize(int batchsize) {
//		this.batchsize = batchsize;
//	}
//	
//	
}
