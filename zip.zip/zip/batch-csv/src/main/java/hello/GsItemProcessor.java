package hello;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;

public class GsItemProcessor implements ItemProcessor<Object, Object> {

    private static final Logger log = LoggerFactory.getLogger(GsItemProcessor.class);

    @Override
    public Object process(final Object person) throws Exception {
    	System.out.println("GsItemProcessor: ...............");
        return null;
    }

}
